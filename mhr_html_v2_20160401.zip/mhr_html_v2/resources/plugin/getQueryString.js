/**
 * Created by sg009 on 15/六月/24.
 */
define(function(require, exports) {
    //获取QueryString
    function getQueryString(name, url,noDecode) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var locationSearch = window.location.search || '';
        if(url)
            locationSearch = url;
        if (locationSearch.length > 0) {
            var r = locationSearch.substr(1).match(reg);
            if (r != null){
                if(noDecode)
                    return r[2];
                else
                    return decodeURI(r[2]);
            }
            return '';
        }
        else
            return '';
    }
    return getQueryString
});