define(function(require, exports){
  require('jquery');
  var Validate = require('plugin/validate.el');
  var $ = jQuery;

  var sub = function(action_form_btn, before_fn, after_fn, on_error, val_item, before_send){
    var sub_btn = $(action_form_btn);
    var form = sub_btn.parents('[formtype="form"]').eq(0);
    var url = form.attr('action');
    var method = form.attr('method');
    method = typeof method == 'undefined' ? 'POST' : method;
    //console.log(method);
    var ob = {};
    var val_item = val_item || '[formtype="val_item"]';
    var ipts = $(val_item, form);
    var ipt = null;
    var is_full = true;
    ipts.each(function(){
      var _this = $(this);
      var name = _this.attr('name');
      var phl = _this.attr('placeholders') || _this.attr('placeholder');
      var info = _this.attr('info') ;
      var val = _this.val();
      ob['stamp'] = new Date().getTime();
      ob[name] = val;
      //console.log(ob);
      if(_this.attr('empty') == 'true'){
        return;
      }
      if(!val && is_full){

        var error_info = info || (phl + '不能为空!');
        if(on_error && typeof on_error == 'function'){
          on_error.call(form, error_info, _this);
        }
        if(is_full)
          ipt = this;
        is_full = false;
      }
      var res = Validate.checkformat(_this);
      if(!res.res && is_full){
        var error_info = info || (phl + '  必须为  ' + res.msg);
        if(on_error && typeof on_error == 'function'){
          on_error.call(form, error_info, _this);
        }
        if(is_full)
          ipt = this;
        is_full = false;
      }

    })
    if(!is_full){
      if(ipt) {
        ipt = $(ipt);
        if(ipt.is(':hidden') && ipt.parent().hasClass('dropdown')){
          ipt.siblings('.btn').addClass('active');
        }else{
          ipt.focus();
        }
      }
      return false;
    }

    if(typeof before_fn == 'function'){
      var bf = before_fn.call(form, ob);
      if(!bf && typeof bf == 'boolean'){
        return false;
      }
    }

    var async = true;
    if(before_send && typeof before_send == 'function'){
      async = before_send.call(form, ob);
    }
    if(!async){
      return ;
    }
    $.ajax({
      'url': url,
      'data': ob,
      'dataType': 'json',
      'type': method,
      'cache': false,
      'success': function(data){
          if(typeof after_fn == 'function'){
            after_fn.call(form, data);
          }
      },
      'error': function(err){
        if(on_error && typeof on_error == 'function'){
          on_error.call(form, err);
        }
      }
    })

  }

  return sub;

})