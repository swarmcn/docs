define(function(require, exports){
    var circle = require('plugin/circle');
    require('jquery');
    var $ = jQuery;
    // 
    var UploadFile = function(el, after_fn){
        $(el).each(function () {
            var el = $(this);
            var _f = $('form', el);
            var upload_btn = $('.upload_btn', el);
            var upload_label = $('.upload_label', _f);
            var _this = this;
            var pics = [];
            var uploading = false;

            upload_btn.hover(function () {
                upload_label.addClass('hover')
            }, function () {
                upload_label.removeClass('hover')
            }).change(function () {
                var _this = this;
                var val = $(_this).val();
                if(!val){
                    return ;
                }
                if(uploading){
                    pics.push(val);
                }
                uploading = true;
                var _f = $(_this).parents('form').eq(0);

                /**正在上传动态效果**/
                $(_this).hide();

                var upload_text = $('.upload_text',_f).text();
                var upload_loading = upload_label.data('loading') || '正在上传';
                var glyphicon = $('.fa',upload_label);
                function uploading_label() {
                    if($(_this).is(':hidden')) {
                        //glyphicons-cloud
                        glyphicon.attr('class','fa fa-cloud');
                        window.setTimeout(function () {
                            //glyphicons-cloud-upload
                            glyphicon.attr('class','fa fa-cloud-upload');
                        },400)
                        window.setTimeout(function () {
                            uploading_label();
                        }, 800);
                    }
                    else{
                        //glyphicons-cloud-upload
                        glyphicon.attr('class','fa fa-cloud-upload');
                    }
                }
                uploading_label();
                $('.upload_text',_f).text(upload_loading);
                /**正在上传动态效果**/

                var target = _f.attr('target');
                if(!target){
                    target = 'J_' + new Date().getTime();
                    _f.attr('target', target);
                }
                var ifm = $('#' + target).get(0);
                if(!ifm){
                    ifm = $('<iframe class="hide" id="' + target + '" name = "' + target+ '" ></iframe>');
                    ifm.appendTo(document.body);
                    ifm = ifm.get(0);
                }
                var doc = null;
                doc = ifm.contentDocument || ifm.document;
                $(doc.body).html('');
                _f.submit();
                circle({
                    'always': true,
                    'fn': function(param){
                        var doc = ifm.contentDocument || ifm.document;
                        var res = $(doc.body).text();
                        uploading = false;
                        if(res){
                            if( after_fn && typeof after_fn == 'function'){
                                after_fn.call(_this, res, el);

                                $(_this).show();
                                $('.upload_text',_f).text(upload_text);//上传完毕
                            }
                            param.always = false;
                        }
                        if(pics.length > 0){
                            target.val(pics[0]);
                            pics.split(0, 1);
                        }
                    }
                })
            })
        })
    }

    return UploadFile;
})