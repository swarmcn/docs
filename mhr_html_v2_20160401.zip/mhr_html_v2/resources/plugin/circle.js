define(function(require, exports){
    /*
    fn[function]
    times[int]
    always[boolean]
    mg
    afterfn[function]
    */
    var circle = function(param){
        
        var check_param = function(){
            if(!param.times && !param.always){
                if(param.times == 0){
                    if(param.afterfn && typeof param.afterfn == 'function'){
                        param.afterfn.call(param, param);
                    }   
                }
                return false;
            }
            if(param.always){
                param.times = 1;
            }
            return true;
        }

        var me = arguments.callee;

        param.times -- ;
        setTimeout(function(){

            if(param.fn && typeof param.fn == 'function'){
                param.fn.call(param, param);
            }
            if(check_param()){
                me(param);
            }
        }, param.mg || 1000)
    }
    
    return circle;
})