/**
 * Created by sg009 on 15/五月/19.
 */
define(function(require, exports) {
    require('jquery');

    var Alert = function (text, state, container, autoclose, animate_time, set_style) {
        var _this = this;
        var text = text || '';
        if(!text) return;//没内容不弹窗

        var autoclose = autoclose === false ? false : true;
        var animate_time = animate_time || 3000;
        var state = state || 'danger';//success//info//warning
        if(state.indexOf('alert-') == -1)
            state = 'alert-'+state;
        var is_container = container ? true: false;
        var container = container ? $(container) : ($('.container-fluid')[0] ? $('.container-fluid') : $('body'));

        var glyphicon = '';
        switch (state){
            case 'alert-danger':
            case 'alert-error':
                state = 'alert-danger';
                glyphicon = 'fa fa-frown-o';
                break;
            case 'alert-success':
                glyphicon = 'fa fa-smile-o';
                break;
            case 'alert-info':
                glyphicon = 'fa fa-info-circle';
                break;
            default :
            case 'alert-warning':
                glyphicon = 'fa fa-exclamation-circle';
                break;
        }
        var el = $('<div class="alert fade in"></div>').addClass(state).html('<span class="'+glyphicon+'"></span> ' + text);
        container.prepend(el);
        if(set_style)
            el.css(set_style);
        else
        {
            if(!is_container) {
                el.css({
                    'max-width': 400
                });

                var sidebar_width = 0;
                if($('.sidebar')[0] && !$('.modal')[0]){
                    sidebar_width = $('.sidebar').width();
                }
                el.css({
                    'left':'50%',
                    'margin-left': - el.width() / 2 + sidebar_width / 2,
                    'top': 60
                });
            }
        }

        _this.close = function(at){
            var at = at || animate_time;
            setTimeout(function(){
                el.alert('close');
            }, at)
        };

        var hasclose = true;
        if(autoclose){
            _this.close();
        }else{
            if($('[data-dismiss]',el)[0])//非自动时，若有关闭按钮则不增加
                hasclose = false;
        }

        if(hasclose) {
            el.prepend('<a class="close" data-dismiss="alert" aria-hidden="true">&times;</a>');
        }
    };

    return Alert;
});