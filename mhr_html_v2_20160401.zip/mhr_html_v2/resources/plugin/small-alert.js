define(function (require) {
    require('jquery');

    function smallAlert(title, timer, callback) {
        timer = timer || 2500;
        var alert = $('<div class="small-alert-mask"><div class="small-alert">' + title + '</div></div>' +
            '<div style="z-index: 1030;background-color: rgba(0,0,0,.4);" class="modal-backdrop small-alert-backdrop" style="opacity: .3;"></div>');
        $('.small-loading').remove();
        $(document.body).append(alert);
        $('.small-alert-backdrop').click(function () {
            $('.small-alert-mask,.small-alert-backdrop').remove();
            if(typeof callback == 'function')
                callback.call();
        });
        setTimeout(function () {
            alert.fadeOut(1000, function () {
                $(this).remove();
                if(typeof callback == 'function')
                    callback.call();
            })
        }, timer - 1000);
    }
    return smallAlert;
});