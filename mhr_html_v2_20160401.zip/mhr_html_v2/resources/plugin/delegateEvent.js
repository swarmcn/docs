define(function(require, exports){
    require('jquery');

    //事件的委托处理动态插入的元素
    var delegateEvent = function(el, events){
        var el = el ? el : document.body;

        for(var i in events){

            ;(function(key){

                $(document.body).delegate(el, key, function(e){
                    events[key].call(this, e);
                });

            })(i)

        }

    }

    return delegateEvent;
})