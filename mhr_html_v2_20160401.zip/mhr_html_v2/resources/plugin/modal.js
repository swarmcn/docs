/**
 * Created by bandon on 15/4/1.
 */
define(function(require, exports){
    require('jquery');

    var Modal = function (btn,options) {
        //设置插件的默认属性
        var defaults = {
            id: 'myModal',
            title: '标题',
            body: null,
            footer:null,
            size: 'md',//lg//sm
            width: null,
            btnText: '确认',
            hasClose: true,
            marginTop:null
        }
        var options = $.extend(defaults, options);

        var myModal = $('<div class="modal" id="' + options.id + '" tabindex="-1" role="dialog" aria-labelledby="' + options.id + 'Label"></div>');
        var box = '<div class="modal-dialog" style = "min-height:200px;';
        if(options.width) {
            var width = parseInt(options.width)
            if(!isNaN(width))
                options.width = options.width + 'px';
            box += 'width:' + options.width + ';';
        }

        box += '"><div class="modal-content"><div class="modal-header">'

        box += '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>';
        if (options.hasClose) {

        }
        else {
            myModal.data('backdrop', 'static');
        }

        //title
        box += '<h4 class="modal-title" id="' + options.id + 'Label">' + options.title + '</h4></div>';

        //body
        if (options.body) {
            box += '<div class="modal-body" style="min-height: 50px;">' + options.body + '</div>'
        }
        box += '<div class="modal-footer">';

        //footer
        if(options.footer) {
            box += options.footer;
        }else{
            box += '<a class="btn btn-default" data-dismiss="modal">取消</a> ' +
                '<a class="btn btn-primary">' + options.btnText + '</a>';
        }
        box += '</div></div></div>';

        myModal.html(box);

        if(options.size){
            switch(options.size){
                case 'lg':
                    $('.modal-dialog',myModal).addClass('modal-lg')
                    break;
                case 'sm':
                    $('.modal-dialog',myModal).addClass('modal-sm')
                    break;
            }
        }

        $('#' + options.id).remove();
        $('body').append(myModal);

        //设定触发按钮
        if(btn) {
            $(btn).attr({'data-toggle': 'modal', 'data-target': '#' + options.id});
        }

        //设定范围(垂直居中)
        if(options.marginTop) {
            $('.modal-dialog', myModal).css({
                'margin-top': (options.marginTop - 50) + 'px'
            });
        }

        return myModal;
    }


    return Modal;
})