define(function (require) {
    require('jquery');
    var smallTimeout = require('plugin/small-timeout');

    function smallLoading() {
        var loading = $('<div class="small-alert-mask small-loading" style="bottom:49%">' +
            '<span class="fa-stack" style="font-size:20px">' +
            '<i class="fa fa-circle fa-stack-2x"></i>' +
            '<i class="fa fa-circle-o-notch fa-spin fa-stack-1x fa-inverse" style="-webkit-animation:fa-spin 1s infinite linear;animation:fa-spin 1s infinite linear"></i>' +
            '</span></div>' +
            '<div class="modal-backdrop small-alert-backdrop small-loading" style="opacity:0;"></div>');
        $(document.body).prepend(loading);

        //30秒后响应超时
        setTimeout(function () {
            if($('.small-loading')[0])
            {
                $('.small-loading').remove();
                smallTimeout();
            }
           // location.reload(true);
        },30000);
    }
    return smallLoading;
});