define(function (require, exports) {

    Array.prototype.each = function (fn) {
        var _this = this;
        for (var i = 0, j = _this.length; i < j; i++) {
            if (typeof fn == 'function') {
                fn.call(_this, _this[i], i);
            }
        }
    }
    // 针对字符串的验证
    var validate = {

        'is_num': function (val) {
            if (val == 0) {
                return true;
            }
            if (!val) {
                return false;
            }
            var r = val * 1;
            if (r && typeof r == 'number') {
                return true;
            }
            return false;
        },

        'is_float': function (val) {
            var _this = this;
            if (!_this.is_num(val)) {
                return false;
            }
            var r = val + '';
            if (r.split('.').length > 1) {
                return true;
            }
            return false;
        },

        'is_parseint': function (val) {
            var _this = this;
            if (!_this.is_num(val) || _this.is_float(val)) {
                return false;
            }
            return true;
        },

        'is_email': function (val) {
            var _this = this;
            var val = val.replace(/^\s|\s$/g, '');
            if (!val) {
                return false;
            }
            var ve = val.split('@');
            if (ve.length != 2) {
                return false;
            }
            if (ve[1].split('.').length < 2) {
                return false;
            }
            return true;
        },

        'is_phone': function (val) {
            var val = val.replace(/^\s|\s$/g, '');
            if (!val) {
                return;
            }
            var isPhone = /^([0-9]{3,4}(-)?)?[0-9]{7,8}$/;
            var isMob = /^((\+?86)|(\(\+86\)))?(1[3-8][0-9]{9})$/;
            if (!isMob.test(val) && !isPhone.test(val)) {
                return false;
            }
            return true;
        },

        'is_datetime': function (val) {
            var val = val.replace(/^\s|\s$/g, '');
            if (!val) {
                return;
            }
            var res = !!val.match(/^([1-2]\d{3})[\/|\-](0?[1-9]|10|11|12)[\/|\-]([1-2]?[0-9]|0[1-9]|30|31)$/ig);
            if (!res) {
                return false;
            }
            return true;
        },

        'is_url': function (val) {
            var val = val.replace(/^\s|\s$/g, '');
            if (!val) {
                return;
            }
            //var strRegex = "^((https|http|ftp|rtsp|mms)?://)"
            //    + "?(([0-9a-z_!~*'().&=+$%-]+: )?[0-9a-z_!~*'().&=+$%-]+@)?" //ftp的user@
            //    + "(([0-9]{1,3}\\.){3}[0-9]{1,3}" // IP形式的URL- 199.194.52.184
            //    + "|" // 允许IP和DOMAIN（域名）
            //    + "([0-9a-z_!~*'()-]+\\.)*" // 域名- www.
            //    + "([0-9a-z][0-9a-z-]{0,61})?[0-9a-z]\\." // 二级域名
            //    + "[a-z]{2,6})" // first level domain- .com or .museum
            //    + "(:[0-9]{1,4})?" // 端口- :80
            //    + "((/?)|" // a slash isn't required if there is no file name
            //    + "(/[0-9a-z_!~*'().;?:@&=+$,%#-]+)+/?)$";
            //
            var strRegex = "^[A-Za-z]+://[A-Za-z0-9-_]+\\.[A-Za-z0-9-_%&\?\/.=]+$";
            var re = new RegExp(strRegex);

            var res = !!val.match(re);
            if (!res) {
                return false;
            }
            return true;
        },
        'is_idCard': function (val) {
            var num = val.toUpperCase();
            //身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X。
            if (!(/(^\d{15}$)|(^\d{17}([0-9]|X)$)/.test(num))) {
                //console.log('输入的身份证号长度不对，或者号码不符合规定！18位号码末位可以为数字或X。');
                return false;

            }
            //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
            //下面分别分析出生日期和校验位
            var len, re;
            len = num.length;
            if (len == 18) {
                re = new RegExp(/^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/);
                var arrSplit = num.match(re);
                //检查生日日期是否正确
                var dtmBirth = new Date(arrSplit[2] + "/" + arrSplit[3] + "/" + arrSplit[4]);
                var bGoodDay;
                bGoodDay = (dtmBirth.getFullYear() == Number(arrSplit[2])) && ((dtmBirth.getMonth() + 1) == Number(arrSplit[3])) && (dtmBirth.getDate() == Number(arrSplit[4]));
                if (!bGoodDay) {
                    //console.log(dtmBirth.getYear());
                    //console.log(arrSplit[2]);
                    //console.log('输入的身份证号里出生日期不对！');
                    return false;
                }

                else {
                    //检验18位身份证的校验码是否正确。
                    //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
                    var valnum;
                    var arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
                    var arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
                    var nTemp = 0, i;
                    for (i = 0; i < 17; i++) {
                        nTemp += num.substr(i, 1) * arrInt[i];
                    }
                    valnum = arrCh[nTemp % 11];
                    if (valnum != num.substr(17, 1)) {
                        //console.log('18位身份证的校验码不正确！应该为：' + valnum);
                        return false;
                    }
                    return num;
                }
            }
            return false;
        },
        'checkformat': function (el, format_key) {//针对元素设置验证
            var el = $(el);
            var _this = this;
            var format_key = format_key || 'format';
            var format = (el.attr(format_key) || format_key).split(';');
            var val = el.val() || el.text();
            var res = {'res': true};
            format.each(function (format_str) {
                if (!res.res) {
                    return;
                }

                if (format_str == 'idCard') {
                    if (!_this.is_idCard(val)) {
                        res = {
                            'type': 'idCard',
                            'res': false,
                            'msg': '身份证格式'
                        }
                        return;
                    }
                }

                if (format_str == 'email') {
                    if (!_this.is_email(val)) {
                        res = {
                            'type': 'email',
                            'res': false,
                            'msg': '邮箱格式'
                        }
                        return;
                    }
                }

                if (format_str == 'phone') {
                    if (!_this.is_phone(val)) {
                        res = {
                            'type': 'phone',
                            'res': false,
                            'msg': '电话格式'
                        }
                        return;
                    }
                }

                if (format_str == 'number' || format_str == 'money') {
                    if (!_this.is_num(val)) {
                        res = {
                            'type': 'number',
                            'res': false,
                            'msg': '数字'
                        }
                        return;
                    }
                }

                if (format_str == 'float') {
                    if (!_this.is_float(val)) {
                        res = {
                            'type': 'float',
                            'res': false,
                            'msg': '小数'
                        }
                        return;
                    }
                }

                if (format_str == 'parseint') {
                    if (!_this.is_parseint(val)) {
                        res = {
                            'type': 'parseint',
                            'res': false,
                            'msg': '整数'
                        }
                        return;
                    }
                }

                if (format_str == 'datetime') {
                    if (!_this.is_datetime(val)) {
                        res = {
                            'type': 'datetime',
                            'res': false,
                            'msg': '时间格式'
                        }
                        return;
                    }
                }

                if (format_str == 'url') {
                    if (!_this.is_url(val)) {
                        res = {
                            'type': 'url',
                            'res': false,
                            'msg': '有效网址'
                        }
                        return;
                    }
                }

            })
            return res;
        }
    }

    var $delegate = require('plugin/delegateEvent');

    $delegate('[format="number"]', {
        'keyup': function () {
            var val = $(this).val();
            if (!validate.is_num(val)) {
                var nVal = '';
                $.each(val.split(''), function (n, v) {
                    if (validate.is_num(v) || (v == '.' && nVal.indexOf('.') == -1))
                        nVal += v;
                });
                $(this).val(nVal);
            }
            $(this).val($(this).val().trim());
        }
    });

    $delegate('[format="money"]', {
        'keyup': function () {
            var val = $(this).val();
            if (!validate.is_num(val)) {
                var nVal = '';
                $.each(val.split(''), function (n, v) {
                    if (validate.is_num(v) || (v == '.' && nVal.indexOf('.') == -1))
                        nVal += v;
                });
                $(this).val(nVal);
            }
            val = parseFloat(val) || 0;
            var decimal = val.toString().split('.');
            if (decimal.length > 1) {
                if (decimal[1].length > 2) {
                    $(this).val(decimal[0] + '.' + decimal[1].substr(0, 2));
                }
            }
            $(this).val($(this).val().trim());
        }
    });

    $delegate('[format="kg"]', {
        'keyup': function () {
            var val = $(this).val();
            if (!validate.is_num(val)) {
                var nVal = '';
                $.each(val.split(''), function (n, v) {
                    if (validate.is_num(v) || (v == '.' && nVal.indexOf('.') == -1))
                        nVal += v;
                });
                $(this).val(nVal);
            }
            val = parseFloat(val) || 0;
            var decimal = val.toString().split('.');
            if (decimal.length > 1) {
                if (decimal[1].length > 3) {
                    $(this).val(decimal[0] + '.' + decimal[1].substr(0, 3));
                }
            }
            $(this).val($(this).val().trim());
        }
    });

    $delegate('[format="float"]', {
        'keyup': function () {
            var val = $(this).val();
            if (!validate.is_float(val)) {
                var nVal = '';
                $.each(val.split(''), function (n, v) {
                    if (validate.is_num(v) || (v == '.' && nVal.indexOf('.') == -1))
                        nVal += v;
                });
                $(this).val(nVal);
            }
            $(this).val($(this).val().trim());
        }
    });

    $delegate('[format="parseint"]', {
        'keyup': function () {
            var val = $(this).val();
            if (!validate.is_parseint(val)) {
                var nVal = '';
                $.each(val.split(''), function (n, v) {
                    if (validate.is_num(v))
                        nVal += v;
                });
                $(this).val(nVal);
            }
            $(this).val($(this).val().trim());
        }
    });

    return validate;
})