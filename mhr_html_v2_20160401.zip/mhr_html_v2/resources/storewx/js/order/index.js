define(function (require, exports, module) {
    require('storewx');
    $.base64 = require('plugin/encrypt/base64');

    $.myApp.controller('orderCtrl', function ($scope, $http, $timeout) {

        //订单状态
        $scope.getStatus = function (order) {
            var statusContent = '';
            if (order.expired)
                statusContent = '超期未支付';
            else {
                if (order.orderStatus == "cancelled")
                    statusContent = '交易关闭';
                else if (order.paymentStatus == "unpaid") {
                    statusContent = '等待付款';
                }
                else {
                    statusContent = '交易成功';
                    if (order.shippingStatus == "unshipped")
                        statusContent = '等待发货';
                    if (['shipped', 'applyReturn', 'partialReturns'].indexOf(order.shippingStatus) > -1 && !order.receiveDate)
                        statusContent = '卖家已发货';
                    if (order.isCommented)
                        statusContent = '交易完成';//已评价
                }
            }
            return statusContent;
        };

        $scope.userId = null;
        try {
            var word = $.base64.decode($.getQueryString('b').toString()).split('|');
            $scope.userId = parseInt(word[1]);
            if ($scope.userId <= 0 || !$scope.userId || word[0] != word[1]) {
                location.replace('/storewx/clerk/index.html#/index');
            }
        }
        catch (ex) {
            location.replace('/storewx/clerk/index.html#/index');
            return;
        }

        var $pageSize = 15;
        $scope.canBeLoaded = false;
        var cookiePageNumber = parseInt(sessionStorage.getItem("order-page") || 1);
        $scope.getList = function () {
            $scope.orderList = [];
            $scope.pageSize = $pageSize;
            $scope.currentPage = 0;
            var pageSize = $scope.pageSize * cookiePageNumber || $pageSize;

            if ($scope.keyword)
                pageSize = $pageSize;

            var params = {
                userId: $scope.userId,
                keyword: $scope.keyword,
                pageNumber: $scope.currentPage + 1,
                pageSize: pageSize,
                stamp: $.timestamp()
            };

            if ($userInfo && $userInfo.isManager)
                delete params.userId;//店长看全部订单

            $http({
                method: 'get',
                url: '/store/order/getList.json',
                params: params
            }).success(function (response) {
                if (response.success && response.data && response.data.length > 0) {
                    $scope.orderList = response.data || null;

                    $scope.canBeLoaded = true;
                    if (pageSize > $pageSize)
                        $scope.currentPage += pageSize / $pageSize;
                    else
                        $scope.currentPage++;

                    if ($scope.orderList.length < $pageSize)
                        $scope.canBeLoaded = false;
                    else
                        sessionStorage.setItem("order-page", $scope.currentPage);
                }
            })
        };

        var $userInfo = window.sessionStorage.getItem("userInfo");
        if ($userInfo) {
            $userInfo = JSON.parse($userInfo);
            $scope.getList();
        }
        else {
            $scope.checkWXLogin(function (response) {
                if (response.register) {
                    $userInfo = $.userInfo;
                    $scope.getList();
                }
            }, false);
        }

        //静态下拉刷新
        $scope.$on('doRefresh', function () {
            $scope.keyword = null;
            cookiePageNumber = 1;
            $scope.getList();
        });

        //滚动加载
        $scope.loadMore = function () {
            if (!$scope.canBeLoaded || !$scope.orderList) {
                $scope.$broadcast('scroll.infiniteScrollComplete');
                return;
            }

            var pageSize = $scope.pageSize;
            var params = {
                userId: $scope.userId,
                keyword: $scope.keyword,
                pageNumber: $scope.currentPage + 1,
                pageSize: pageSize,
                stamp: $.timestamp()
            };

            if ($userInfo && $userInfo.isManager)
                delete params.userId;//店长看全部订单

            $http({
                method: 'get',
                url: '/store/order/getList.json',
                params: params
            }).success(function (response) {
                if (response.success && response.data && response.data.length > 0) {
                    if ($scope.orderList.length == 0) {
                        $timeout(function () {
                            $scope.$emit('scrollTo', pageSize > $pageSize);
                        }, 100);
                    }
                    $.each(response.data, function (n, x) {
                        if(!$('#order'+ x.orderId)[0])
                            $scope.orderList.push(x);
                        else
                            $scope.canBeLoaded = false;
                    });
                    if (pageSize > $pageSize)
                        $scope.currentPage += pageSize / $pageSize;
                    else
                        $scope.currentPage++;

                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    sessionStorage.setItem("order-page", $scope.currentPage);
                } else {
                    if (response.totalCount == 0 || !response.data) {
                        $scope.canBeLoaded = false;
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    }
                }
            });
        };
    })
});