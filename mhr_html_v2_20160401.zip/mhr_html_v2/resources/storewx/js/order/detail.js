define(function (require, exports, module) {
    require('storewx');
    var status = require('store/js/order/status');

    $.myApp.controller('detailCtrl', function ($scope, $http, $timeout){

        $scope.id = $.getQueryString('id');

        //订单状态
        $scope.getStatus = function (order) {
            if (order.expired)
                $scope.order.statusContent = '超期未支付';
            else {
                if (order.orderStatus == "cancelled")
                    $scope.order. statusContent = '交易关闭';
                else if (order.paymentStatus == "unpaid") {
                    $scope.order.statusContent = '等待付款';
                }
                else {
                    $scope.order.statusContent = '交易成功';
                    if (order.shippingStatus == "unshipped")
                        $scope.order.statusContent = '等待发货';
                    if (['shipped', 'applyReturn', 'partialReturns'].indexOf(order.shippingStatus) > -1 && !order.receiveDate)
                        $scope.order.statusContent = '卖家已发货';
                    if (order.isCommented)
                        $scope.order.statusContent = '交易完成';//已评价
                }
            }
        };

        $scope.getDetail = function () {
            $http({
                method: 'get',
                url: '/store/order/getDetail.json',
                params: {
                    id: $scope.id,
                    stamp: $.timestamp()
                },
                headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
            }).success(function (response) {
                if (response.success) {
                    $scope.order = response.data;
                    $scope.getStatus($scope.order);
                    $scope.status = status;
                }
            });
        };
        $scope.getDetail();

        //静态下拉刷新
        $scope.$on('doRefresh', function () {
            $scope.getDetail();
        });
    })
});