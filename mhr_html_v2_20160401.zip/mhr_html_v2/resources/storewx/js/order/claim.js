define(function (require, exports, module) {
    require('storewx');
    var status = require('store/js/order/status');
    $.base64 = require('plugin/encrypt/base64');

    $.myApp.controller('claimCtrl', function ($scope, $http, $timeout) {
        //订单解密
        try {
            $scope.orderId = $.getQueryString('o');
            $scope.orderId = $.base64.decode($scope.orderId);
            var orderIds = $scope.orderId.split('@');
            $scope.orderId = orderIds[0];
            if(orderIds[0] != orderIds[1]){
                location.replace('/storewx/clerk/index.html#/index');
                return;
            }
        }
        catch(ex){
            location.replace('/storewx/clerk/index.html#/index');
            return;
        }

        var url = '/store/order/getClaim.json';
        if ($.isTest)
            url = '/storewx/order/getClaim.json';

        //alert('orderId'+$scope.orderId);
        $scope.claim = {
            isClaimed:false
        };
        $scope.getClaim = function () {
            $http.get(url + '?id=' + $scope.orderId).success(function (response) {
                if(response.success) {
                    $scope.claim = response.data;
                    $scope.claim.isClaimed = false;
                }
            }).error(function (error) {
                //alert('claim/error:' + JSON.stringify(error));
            });
        };

        var $userInfo = window.sessionStorage.getItem("userInfo");
        if ($userInfo) {
            $userInfo = JSON.parse($userInfo);
            $scope.getClaim();
        }
        else {
            $scope.checkWXLogin(function (response) {
                if (response.register) {
                    $userInfo = $.userInfo;
                    $scope.getClaim();
                }
            }, false);
        }


        $scope.apply = function () {
            if ($scope.claim.isClaimed) {
                location.href = '/storewx/clerk/index.html';
            }
            else {
                if($.isTest){
                    $scope.claim.isClaimed = true;
                }
                $http({
                    method: 'POST',
                    url:'/store/order/claim',
                    data: $.param({
                        id: $scope.orderId
                    }),
                    headers: $.headers
                }).success(function (response) {
                    if(response.success)
                        $scope.claim.isClaimed = true;
                    else
                        $.smallAlert(response.data);
                }).error(function (error) {
                    alert('claim/error:' + JSON.stringify(error));
                })
            }
        }
    });
});