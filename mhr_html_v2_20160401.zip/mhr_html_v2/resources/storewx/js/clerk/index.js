define(function (require, exports, module) {
    require('storewx');

    //微信JS-SDK//head里有jweixin.js时才会调用
    require('weixin/js/wx-sdk');

    $.base64 = require('plugin/encrypt/base64');
    var $toggleAmount = $('#toggleAmount');


    $.myApp.factory('$memberInfo', function () {
        return {};
    });

    $.myApp.config(function ($urlRouterProvider, $stateProvider) {
        $urlRouterProvider.when('', '/index');
        $stateProvider
            .state('index', {
                url: '/index',
                controller: 'clerkCtrl',
                templateUrl: 'index'
            })
            .state('setting', {
                url: '/setting',
                templateUrl: 'setting'
            })
            .state('rules', {
                url: '/rules',
                controller: 'clerkCtrl',
                templateUrl: 'rules'
            })
            .state('assets', {
                url: '/assets',
                controller: 'myAmount',
                templateUrl: 'assets'
            })
            .state('withdraw/apply', {
                url: '/withdraw/apply',
                controller: 'balanceAmountCtrl',
                templateUrl: 'withdraw/apply'
            })
    });




    $.myApp.controller('clerkCtrl', function ($scope, $http, $timeout, $ionicLoading) {
        $scope.hostname = location.host;

        var $userInfo = window.sessionStorage.getItem("userInfo");
        if ($userInfo) {
            $.userInfo = JSON.parse($userInfo);
        }

        $scope.getDeatil = function () {
            if ($.userInfo && $.userInfo.userId) {
                var userId = $.userInfo.userId;

                //店员ID64位加密
                $scope.userId = $.base64.encode(userId + '|' + userId);

                //微信二维码
                seajs.use('plugin/jquery/jquery.qrcode.min', function () {
                    //转字符码
                    function utf16to8(str) {
                        var out, i, len, c;
                        out = "";
                        len = str.length;
                        for (i = 0; i < len; i++) {
                            c = str.charCodeAt(i);
                            if ((c >= 0x0001) && (c <= 0x007F)) {
                                out += str.charAt(i);
                            } else if (c > 0x07FF) {
                                out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
                                out += String.fromCharCode(0x80 | ((c >> 6) & 0x3F));
                                out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
                            } else {
                                out += String.fromCharCode(0xC0 | ((c >> 6) & 0x1F));
                                out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
                            }
                        }
                        return out;
                    }

                    //点击时，长按提示
                    $scope.tipTapQR = function () {
                        $.smallAlert('长按保存到手机');
                    };

                    var registerUrl = 'http://' + location.host + "/weixin/auth/register.html?userId=" + $scope.userId + '&n=' + $.userInfo.username;
                    //$('body').addClass('has-wxMenuShare');
                    $('.wx-menuShare').attr({
                        'share-link':registerUrl,
                        'share-imgUrl':'http://365meirihui.com/resources/images/user-logo.png',
                        'share-title':'欢迎注册会员 - 美日惠，家门口的海外药妆店！'
                    });//分享链接
                    $(".qrcode").html('').qrcode({
                        width: $(window).width() * 0.4, //宽度
                        height:$(window).width() * 0.4, //高度
                        text: utf16to8(registerUrl),
                        src: '/resources/images/mi.png',
                        imgWidth: 32,
                        imgHeight: 32
                    });

                    $timeout(function () {
                        var $qrcode = document.getElementById('qrcode');
                        $qrcode.src = $('.qrcode canvas')[0].toDataURL("image/png");
                    },100)
                });

                //拷贝链接
                //$scope.initClipboard = 'http://'+ $scope.hostname +'/weixin/auth/register.html?userId='+$scope.userId;
                
                //开关二维码
                $scope.toggleQR = function () {
                    $timeout(function () {
                        $scope.$emit('scrollBottom');
                    },100);
                };

                //获取详情
                var url = '/store/clerk/getDetail.json';
                if ($.isTest)
                    url = '/storewx/clerk/getDetail.json';
                $http({
                    method: 'get',
                    url: url + '?ts=' + $.timestamp() + '&id=' + userId
                }).success(function (response) {
                    if (response.success) {
                        $scope.clerk = response.data;

                        $timeout(function () {
                            $('html').addClass('success');
                        }, 100)
                    }
                }).error(function (err) {
                    alert('getDetail/err:'+err);
                });
            } else {
                $('html').removeClass('success');
                $timeout(function () {
                    $scope.getDeatil();
                }, 10);
            }
        };
        $scope.getDeatil();

        //金额可见设置
        $scope.toggleAmount = function () {
            $ionicLoading.show();
            $http({
                method: 'POST',
                url: '/store/clerk/toggleAmount',
                data: $.param({
                    isShowAmount: !$scope.clerk.isShowAmount
                }),
                headers: $.headers
            }).success(function (response) {
                $ionicLoading.hide();
                if (response.success) {
                    $scope.clerk.isShowAmount = !$scope.clerk.isShowAmount;
                }
            }).error(function (err) {
                //alert('toggleAmount/err:'+err);
            });

            if ($.isTest) {
                $timeout(function () {
                    $ionicLoading.hide();
                    $scope.clerk.isShowAmount = !$scope.clerk.isShowAmount;
                }, 2000);
            }
        };
    });

    $.myApp.controller('myAmount', function ($scope, $http, $timeout) {
        var url = '/admin/store/myAmount.json';
        if ($.isTest)
            url = '/storewx/clerk/myAmount.json';
        $http({
            method: 'get',
            url: url + '?ts=' + $.timestamp()
        }).success(function (response) {
            //alert('success:'+JSON.stringify(response));
            if (response.success) {
                $scope.balanceAmount = response.data.balanceAmount;
                $scope.withdrawAmount = response.data.withdrawAmount;
            }
        }).error(function (err) {
            // alert('error:'+JSON.stringify(error));
        })
    });

    $.myApp.controller('balanceAmountCtrl', function ($scope, $http, $timeout, $ionicLoading) {
        var url = '/admin/store/myAmount.json';
        if ($.isTest)
            url = '/storewx/clerk/myAmount.json';
        $http({
            method: 'get',
            url: url + '?ts=' + $.timestamp()
        }).success(function (response) {
            if (response.success) {
                $scope.withdrawAmount = response.data.withdrawAmount;
            }
        });

        //校验数字
        $scope.checkAmount = function () {
            if ($scope.withdraw.amount < 1)
                $scope.withdraw.amount = 1;
            if ($scope.withdraw.amount > $scope.withdrawAmount)
                $scope.withdraw.amount = $scope.withdrawAmount;
        };

        //监听变动
        $scope.withdraw = {
            disabled: null
        };
        $scope.watchApply = function () {
            $scope.withdraw.disabled = false;
            if(!$scope.withdraw.amount || !$scope.withdraw.bankcard || !$scope.withdraw.bankname || !$scope.withdraw.bankdeposit) {
                $scope.withdraw.disabled = true;
            }
        };

        //bankcard，bankname，bankdeposit
        $scope.$watch('withdraw.bankcard', function () {
            $scope.watchApply();
        });
        $scope.$watch('withdraw.bankname', function () {
            $scope.watchApply();
        });
        $scope.$watch('withdraw.bankdeposit', function () {
            $scope.watchApply();
        });
        $scope.$watch('withdraw.amount', function () {
            $scope.watchApply();
        });

        //申请提现
        $scope.withdraw_apply = function () {
            if ($scope.withdraw.amount < 0.0001) {
                $.smallAlert('最小提现金额为100元');
                return;
            }
            $ionicLoading.show();
            if ($.isTest) {
                $timeout(function () {
                    $ionicLoading.hide();
                }, 2000);
            }
            $scope.withdraw.bankcard = $('[name="bankcard"]').val();
            $http({
                method: 'POST',
                url: '/store/withdraw/apply',
                data: $.param({
                    bankcard: $scope.withdraw.bankcard,
                    bankname: $scope.withdraw.bankname,
                    bankdeposit: $scope.withdraw.bankdeposit,
                    amount: $scope.withdraw.amount
                }),
                headers: $.headers
            }).success(function (response) {
                $ionicLoading.hide();
                if (response.success) {
                    $.smallAlert(response.data, 1500, function () {
                        location.replace('#/assets');
                    });
                } else
                    $.smallAlert(response.data)
            }).error(function (error) {
                alert('error:'+JSON.stringify(error));
            })
        };
    })

});


