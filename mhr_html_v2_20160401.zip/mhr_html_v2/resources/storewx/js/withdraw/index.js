define(function (require, exports, module) {
    require('storewx');
    var status = require('admin/js/store/status');

    $.myApp.controller('withdrawCtrl', function ($scope, $http, $timeout) {
        $scope.status = status.status;
        var url = '/store/withdraw/getList.json';
        if ($.isTest)
            url = '/storewx/withdraw/getList.json';

        var $pageSize = 15;
        $scope.canBeLoaded = false;
        var cookiePageNumber = parseInt(sessionStorage.getItem("withdraw-page") || 1);
        $scope.getList = function () {
            $scope.withdrawList = [];
            $scope.pageSize = $pageSize;
            $scope.currentPage = 0;
            var pageSize = $scope.pageSize * cookiePageNumber || $pageSize;

            $http({
                method: 'get',
                url: url,
                params: ({
                    pageNumber: $scope.currentPage + 1,
                    pageSize: pageSize,
                    stamp: $.timestamp()
                })
            }).success(function (response) {
                if (response.success && response.data && response.data.length > 0) {
                    $scope.withdrawList = response.data;

                    $scope.canBeLoaded = true;
                    if (pageSize > $pageSize)
                        $scope.currentPage += pageSize / $pageSize;
                    else
                        $scope.currentPage++;

                    if ($scope.withdrawList.length < $pageSize)
                        $scope.canBeLoaded = false;
                    else
                        sessionStorage.setItem("withdraw-page", $scope.currentPage);
                } else
                    $scope.withdrawList = null;
            }).error(function (err) {
                alert('withdraw/err:' + JSON.stringify(err));
            })
        };
        $scope.getList();

        $scope.$on('doRefresh', function () {
            $scope.getList();
        });

        //滚动加载
        $scope.loadMore = function () {
            if (!$scope.canBeLoaded || !$scope.withdrawList) {
                $scope.$broadcast('scroll.infiniteScrollComplete');
                return;
            }

            var pageSize = $scope.pageSize;
            $http({
                method: 'get',
                url: url,
                params: ({
                    pageNumber: $scope.currentPage + 1,
                    pageSize: pageSize,
                    stamp: $.timestamp()
                })
            }).success(function (response) {
                if (response.success && response.data && response.data.length > 0) {
                    if ($scope.withdrawList.length == 0) {
                        $timeout(function () {
                            $scope.$emit('scrollTo', pageSize > $pageSize);
                        }, 100);
                    }
                    $.each(response.data, function (n, x) {
                        if(!$('#withdraw'+ x.id)[0])
                            $scope.withdrawList.push(x);
                        else
                            $scope.canBeLoaded = false;
                    });
                    if (pageSize > $pageSize)
                        $scope.currentPage += pageSize / $pageSize;
                    else
                        $scope.currentPage++;

                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    sessionStorage.setItem("withdraw-page", $scope.currentPage);
                } else {
                    if (response.totalCount == 0 || !response.data) {
                        $scope.canBeLoaded = false;
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    }
                }
            });
        };
    })
});


