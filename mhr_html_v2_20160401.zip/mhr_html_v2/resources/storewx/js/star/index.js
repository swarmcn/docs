define(function (require, exports, module) {
    require('storewx');


    var oneDay = 86400000;//一天毫秒数
    var now = new Date(); //当前日期
    var nowDayOfWeek = now.getDay() - 1; //今天本周的第几天
    var nowDay = now.getDate(); //当前日
    var nowMonth = now.getMonth(); //当前月
    var nowYear = now.getYear(); //当前年
    nowYear += (nowYear < 2000) ? 1900 : 0;

    //默认开始时间
    var EndDate = new Date(now.getTime()).Format('yyyy-MM-dd 23:59:59');
    var weekStartDate = new Date(new Date(nowYear, nowMonth, nowDay - nowDayOfWeek).getTime()).Format('yyyy-MM-dd 00:00:00');
    var monthStartDate = new Date(new Date(nowYear, nowMonth, 1).getTime()).Format('yyyy-MM-dd 00:00:00');


    $.myApp.controller('starCtrl', function ($scope, $http, $timeout, $ionicLoading) {

        //默认排序和本周时间范围
        $scope.type = 'week';
        $scope.beginDate = weekStartDate;
        $scope.endDate = EndDate;

        $scope.getList = function () {
            $scope.starList = [];
            var url = '/store/star/getList.json';
            if ($.isTest)
                url = '/storewx/star/getList.json';

            var params = {
                beginDate: $scope.beginDate,
                endDate: $scope.endDate,
                stamp: $.timestamp()
            };

            //alert('url:' + url + '\r\nparams:' + JSON.stringify(params));

            $http({
                method: 'get',
                url: url,
                params: params
            }).success(function (response) {
                //alert('star/success:' + JSON.stringify(response));
                if (response.success) {
                    $scope.starList = response.data || [];
                    $scope.userInfo.userId = $.userInfo.userId;
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    $scope.userId = $.cookie('upvote');
                }
            }).error(function (err) {
                alert('star/error:' + JSON.stringify(err));
            })
        };
        $scope.getList();

        //静态下拉刷新
        $scope.$on('doRefresh', function () {
            $scope.keyword = null;
            $scope.getList();
        });

        //选项卡
        $scope.setOrderType = function (type) {
            $scope.type = type;
            if ($scope.type == 'week') {
                $scope.beginDate = weekStartDate;
                $scope.endDate = EndDate;
            }
            else if ($scope.type == 'month') {
                $scope.beginDate = monthStartDate;
                $scope.endDate = EndDate;
            }
            else if ($scope.type == 'more') {
                $scope.beginDate = '2015-11-01 00:00:00';
                $scope.endDate = EndDate;
            }
            $scope.getList();
        };

        //排名点赞
        $scope.upvote = function (x) {
            var upvote = $.cookie('upvote');
            if (upvote) {
                $.smallAlert("您今天已经赞过啦！");
                return;
            }
            if ($scope.userInfo.userId == x.userId) {
                //$.smallAlert("不能给自己点赞！");
                return;
            }
            $scope.userId = x.userId;
            $ionicLoading.show();
            if ($.isTest){
                $.cookie('upvote', $scope.userId, {expires: 1, path: '/'});
                $timeout(function () {
                    $ionicLoading.hide();
                }, 2000);
            }
            $http({
                method: 'POST',
                url: '/store/star/upvote',
                data: $.param({
                    userId: $scope.userId
                }),
                headers: $.headers
            }).success(function (response) {
                $ionicLoading.hide();
                if (response.success) {
                    x.upvote = response.data;
                    $.cookie('upvote', $scope.userId, {expires: 1, path: '/'});
                    $.smallAlert(response.data)
                }
                else
                    $.smallAlert(response.data)
            }).error(function (err) {
                $ionicLoading.hide();
            })
        }
    })
});