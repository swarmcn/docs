define(function (require, exports, module) {
    require('storewx');
    var setUrlParam = require('plugin/setUrlParam');
    var status = require('admin/js/store/status');

    $.myApp.controller('clientCtrl', function ($scope, $http, $timeout) {
        var url = '/store/client/getList.json';
        if ($.isTest)
            url = '/storewx/client/getList.json';

        var $pageSize = 15;
        $scope.canBeLoaded = false;
        var cookiePageNumber = parseInt(sessionStorage.getItem("client-page") || 1);
        var cookieType = sessionStorage.getItem("client-type") || $scope.orderType;
        $scope.getList = function (orderType) {
            $scope.clientList = [];
            $scope.pageSize = $pageSize;
            $scope.currentPage = 0;
            var pageSize = $scope.pageSize * cookiePageNumber || $pageSize;

            if (!orderType)
                orderType = 'dateDesc';

            if ($scope.mobile || cookieType != orderType)
                pageSize = $pageSize;

            $scope.orderType = orderType;
            var param = {
                orderType: $scope.orderType,
                mobile: $scope.mobile,
                pageNumber: $scope.currentPage + 1,
                pageSize: pageSize,
                stamp: $.timestamp()
            };
            $http({
                method: 'get',
                url: url,
                params: (param)
            }).success(function (response) {
                if (response.success && response.data && response.data.length > 0) {
                    $scope.clientList = response.data;
                    $scope.canBeLoaded = true;
                    if (pageSize > $pageSize)
                        $scope.currentPage += pageSize / $pageSize;
                    else
                        $scope.currentPage++;

                    if ($scope.clientList.length < $pageSize)
                        $scope.canBeLoaded = false;
                    else {
                        sessionStorage.setItem("client-page", $scope.currentPage);
                        sessionStorage.setItem("client-type", $scope.orderType);
                    }
                } else
                    $scope.clientList = null;
            });
        };
        $scope.getList(cookieType);

        //滚动加载
        $scope.loadMore = function () {
            if (!$scope.canBeLoaded || !$scope.clientList) {
                $scope.$broadcast('scroll.infiniteScrollComplete');
                return;
            }

            var pageSize = $scope.pageSize;
            if (!$scope.orderType)
                $scope.orderType = 'dateDesc';

            var param = {
                orderType: $scope.orderType,
                mobile: $scope.mobile,
                pageNumber: $scope.currentPage + 1,
                pageSize: pageSize,
                stamp: $.timestamp()
            };
            $http({
                method: 'get',
                url: url,
                params: (param)
            }).success(function (response) {
                if (response.success && response.data && response.data.length > 0) {
                    if ($scope.clientList.length == 0) {
                        $timeout(function () {
                            $scope.$emit('scrollTo', pageSize > $pageSize);
                        }, 100);
                    }
                    $.each(response.data, function (n, x) {
                        if(!$('#client'+ x.username)[0])
                            $scope.clientList.push(x);
                        else
                            $scope.canBeLoaded = false;
                    });
                    if (pageSize > $pageSize)
                        $scope.currentPage += pageSize / $pageSize;
                    else
                        $scope.currentPage++;

                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    sessionStorage.setItem("client-page", $scope.currentPage);
                    sessionStorage.setItem("client-type", $scope.orderType);
                } else {
                    if (response.totalCount == 0 || !response.data) {
                        $scope.canBeLoaded = false;
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    }
                }
            });
        };

        //静态下拉刷新
        $scope.$on('doRefresh', function () {
            $scope.mobile = null;
            $scope.getList($scope.orderType);
        });

        //排序
        $scope.setOrderType = function (orderType) {
            $scope.orderType = orderType;
            $scope.getList(orderType);
        };

    })
});


