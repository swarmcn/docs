define(function (require, exports, module) {
    require('storewx');
    var status = require('admin/js/store/status');

    $.myApp.controller('commissionCtrl', function ($scope, $http, $timeout) {
        var url = '/store/order/commission/getList.json';
        if ($.isTest)
            url = '/store/order/getCommissionList.json';

        var $pageSize = 15;
        $scope.canBeLoaded = false;
        var cookiePageNumber = parseInt(sessionStorage.getItem("commission-page") || 1);
        $scope.getList = function () {
            $scope.commissionList = [];
            $scope.pageSize = $pageSize;
            $scope.currentPage = 0;
            var pageSize = $scope.pageSize * cookiePageNumber || $pageSize;

            $http({
                method: 'get',
                url: url,
                params: ({
                    pageNumber: $scope.currentPage + 1,
                    pageSize: pageSize,
                    stamp: $.timestamp()
                })
            }).success(function (response) {
                if (response.success && response.data && response.data.length > 0) {
                    $scope.commissionList = response.data || null;

                    $scope.canBeLoaded = true;
                    if (pageSize > $pageSize)
                        $scope.currentPage += pageSize / $pageSize;
                    else
                        $scope.currentPage++;

                    if ($scope.commissionList.length < $pageSize)
                        $scope.canBeLoaded = false;
                    else
                        sessionStorage.setItem("commission-page", $scope.currentPage);
                }
            }).error(function (err) {
                alert('commission/err:' + err);
            })
        };
        $scope.getList();

        //静态下拉刷新
        $scope.$on('doRefresh', function () {
            $scope.getList();
        });

        //滚动加载
        $scope.loadMore = function () {
            if (!$scope.canBeLoaded || !$scope.commissionList) {
                $scope.$broadcast('scroll.infiniteScrollComplete');
                return;
            }

            var pageSize = $scope.pageSize;
            $http({
                method: 'get',
                url: url,
                params: ({
                    pageNumber: $scope.currentPage + 1,
                    pageSize: pageSize,
                    stamp: $.timestamp()
                })
            }).success(function (response) {
                if (response.success && response.data && response.data.length > 0) {
                    if ($scope.commissionList.length == 0) {
                        $timeout(function () {
                            $scope.$emit('scrollTo', pageSize > $pageSize);
                        }, 100);
                    }
                    $.each(response.data, function (n, x) {
                        if(!$('#order'+ x.orderId)[0])
                            $scope.commissionList.push(x);
                        else
                            $scope.canBeLoaded = false;
                    });
                    if (pageSize > $pageSize)
                        $scope.currentPage += pageSize / $pageSize;
                    else
                        $scope.currentPage++;

                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    sessionStorage.setItem("commission-page", $scope.currentPage);
                } else {
                    if (response.totalCount == 0 || !response.data) {
                        $scope.canBeLoaded = false;
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    }
                }
            });
        };
    })
});


