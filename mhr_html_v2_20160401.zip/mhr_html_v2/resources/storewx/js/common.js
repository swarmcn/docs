define(function (require, exports, module) {
    //判断是否微信浏览器
    function is_weixin() {
        var ua = navigator.userAgent.toLowerCase();
        if (ua.match(/MicroMessenger/i) == "micromessenger") {
            return true;
        } else {
            return false;
        }
    }

    //www重定向
    if (location.host.indexOf('www.') > -1 && is_weixin())
        location.replace(location.href.replace('www.', ''));

    require('jquery');
    require('cookie');
    require('ionic');
    require('token');//令牌，POST时必须调用
    require('share/js/date');//new Date().Format('yyyy-MM-dd hh:mm:ss');

    $.setUrlParam = require('plugin/setUrlParam');
    $.getQueryString = require('plugin/getQueryString');
    $.smallAlert = require('plugin/small-alert');
    $.delegate = require('plugin/delegateEvent');
    $.validate = require('plugin/validate.el');
    $.headers = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'};
    $.timestamp = function () {
        return new Date().getTime();
    };
    $.isTest = location.hostname == 'localhost' || location.hostname.indexOf('192.168.2') > -1 || location.hostname.indexOf('172.') > -1 || location.hostname.indexOf('10.10.') > -1;

    //js获取日期：前天、昨天、今天、明天、后天
    $.GetDateStr = function (AddDayCount, type) {
        var dd = new Date();
        dd.setDate(dd.getDate() + AddDayCount);//获取AddDayCount天后的日期
        var y = dd.getFullYear();
        var m = dd.getMonth() + 1;//获取当前月份的日期
        var d = dd.getDate();
        if (type == 'number')
            return new Date(y + "/" + m + "/" + d + " 00:00:00");
        else
            return y + "/" + m + "/" + d;
    };

    //插入悬浮角标
    var corner = '<ul class="corner" style="display: none;">' +
        '<li class="back-top" ng-click="scrollTop()" style="display:none;">' +
        '<a href="javascript:;"><i class="ion-ios-arrow-up"></i></a></li>' +
        '<li class="back-home"><a href="/storewx/clerk/index.html?ts={{ timestamp }}"><i class="ion-home"></i></a></li>';
    corner += '</ul>';
    $('.has-corner').append(corner);
    $('.has-corner .corner').fadeIn(300);
    if ($('.bar-footer')[0]) {
        $('.corner').css('bottom', 50);
    }

    //appindex
    var appindex = $.getQueryString('appindex');
    if (appindex)
        sessionStorage.setItem("appindex", appindex);

    var myApp = angular.module('myApp', ['ionic']);

    //ajax请求全局配置
    myApp.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.defaults.headers.common['token'] = $.cookie('token') || 0;
        $httpProvider.defaults.headers.common['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
        $httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
    }]);

    //输出的html
    myApp.filter(
        //格式化html标签//ng-bind-html
        'to_trusted', ['$sce', function ($sce) {
            return function (text) {
                return $sce.trustAsHtml(text);
            }
        }]
    );

    //输出的html
    myApp.filter(
        //格式化html标签//ng-bind-html
        'to_break', ['$sce', function ($sce) {
            return function (text) {
                if (text)
                    return $sce.trustAsHtml((text + "").replace(/[\r|\n]/g, "<br>"));
                else
                    return "";
            }
        }]
    );

    //是否本周范围内
    myApp.filter(
        'is_timeSpan', ['$sce', function ($sce) {
            return function (text, param1) {
                param1 = param1 || 'week';
                if (typeof text == "string")
                    text = parseInt(text);

                var onDay = 86400000;//一天毫秒数
                var now = new Date(); //当前日期
                var nowDayOfWeek = now.getDay() - 1; //今天本周的第几天
                var nowDay = now.getDate(); //当前日
                var nowMonth = now.getMonth(); //当前月
                var nowYear = now.getYear(); //当前年
                nowYear += (nowYear < 2000) ? 1900 : 0; //

                if (param1 == 'week') {
                    var weekStartDate = new Date(nowYear, nowMonth, nowDay - nowDayOfWeek).getTime();
                    var weekEndDate = new Date(nowYear, nowMonth, nowDay + (6 - nowDayOfWeek)).getTime();
                    return text > weekStartDate && text <= weekEndDate;
                }
            }
        }]
    );

    //格式化日期//ng-bind-html
    myApp.filter(
        'format_date', ['$sce', function ($sce) {
            return function (text, param1, param2) {
                if (text) {
                    param1 = param1 || '<br>';
                    param2 = param2 || '';
                    if (typeof text == "string")
                        text = parseInt(text);


                    var onDay = 86400000;//一天毫秒数
                    var today = $.GetDateStr(0, 'number').getTime();
                    var yesterday = $.GetDateStr(-1, 'number').getTime();
                    var beforeday = $.GetDateStr(-2, 'number').getTime();

                    //console.log(new Date(text).Format('yyyy-MM-dd hh:mm:ss'));

                    if (text >= today && text < today + onDay)
                        text = '今天' + param1 + new Date(text).Format('hh:mm');
                    else if (text >= yesterday && text < yesterday + onDay)
                        text = '昨天' + param1 + new Date(text).Format('hh:mm');
                    else if (text >= beforeday && text < beforeday + onDay)
                        text = '前天' + param1 + new Date(text).Format('hh:mm');
                    else {
                        var num = new Date(text).getDay();
                        var weeks = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
                        text = weeks[num] + param1 + new Date(text).Format('MM-dd');
                    }
                    return text ? $sce.trustAsHtml(text) : param2;
                }
                return param2;
            }
        }]
    );

    //加载动作配置
    myApp.constant('$ionicLoadingConfig', {
        content: '<ion-spinner icon="android"></ion-spinner>',
        animation: 'fade-in',
        showBackdrop: true,
        maxWidth: 200,
        showDelay: 500,
        duration: 15000
    });

    //总控制器
    myApp.controller("WXCtrl", function ($scope, $http, $timeout, $ionicScrollDelegate, $ionicLoading, $interval) {
        $scope.timestamp = $.timestamp();
        $scope.redirectUrl = encodeURIComponent(location.href);

        //获取session里面的用户信息
        if (window.sessionStorage.getItem('userinfo')) {
            $scope.userInfo = $.userInfo = JSON.parse(window.sessionStorage.getItem('userinfo'));
        }

        //滚动事件
        var wh = $(window).height();
        var $back2top = $('.corner .back-top');
        var scrollTop = $('[scroll-top]').attr('scroll-top');
        $scope.scroll = function () {
            //if (window.sessionStorage && scrollTop)
            //    window.sessionStorage.setItem(scrollTop, $ionicScrollDelegate.getScrollPosition().top);
            //$scope.$broadcast('scroll');

            //显示返回头部
            if ($ionicScrollDelegate.getScrollPosition().top > wh * 2) {
                if ($back2top.is(':hidden'))
                    $back2top.fadeIn(300);
            } else {
                if (!$back2top.is(':hidden'))
                    $back2top.fadeOut(300);
            }
        };

        //回到顶部
        $scope.scrollTop = function () {
            $('.corner .back-top').fadeOut(300);
            $ionicScrollDelegate.scrollTop(true);
        };
        $scope.$on('scrollTop', function (e, b) {
            $scope.scrollTop();
        });

        //回到底部
        $scope.scrollBottom = function () {
            $ionicScrollDelegate.scrollBottom(true);
        };
        $scope.$on('scrollBottom', function () {
            $scope.scrollBottom();
        });

        //定位到指定位置
        $scope.scrollTo = function (b, top) {
            if (!b && top) {
                $ionicScrollDelegate.scrollTo(0, top, true);
            } else {
                $timeout(function () {
                    scrollTop = $('[scroll-top]').attr('scroll-top');
                    if (b && scrollTop && window.sessionStorage && window.sessionStorage.getItem(scrollTop)) {
                        //imgUnveil(window.sessionStorage.getItem(scrollTop));
                        $ionicScrollDelegate.scrollTo(0, window.sessionStorage.getItem(scrollTop), true);
                    } else {
                        //imgUnveil($ionicScrollDelegate.getScrollPosition().top);
                    }
                }, 100);
            }
        };

        //授权登录
        $scope.checkWXLogin = function (callback, isAuth) {
            if (isAuth == null)
                isAuth = true;

            var url = "/storewx/getUserInfo?appindex=" + (sessionStorage.getItem("appindex") || 5);
            if ($.isTest)
                url = "/weixin/getUserInfo2.json?1=1";

            //alert('go url:' + url);

            //授权回调的时候
            var wxAuthState = $.getQueryString('state');
            var wxAuthCode = $.getQueryString('code');
            if (wxAuthState == 'wxAuth') {
                if (wxAuthCode)
                    url += '&wxAuthCode=' + wxAuthCode;
            }
            var isloginPage = $('body').hasClass('loginPage');
            if (!isloginPage) {
                $http.get(url + '&ts=' + $.timestamp()).success(function (response) {

                    //alert('getUserInfo/success:' + JSON.stringify(response));

                    if (response.success) {
                        $.WXUserInfo = response;

                        //重定向
                        function redirectToBind() {
                            if (response.userAuthUrl.indexOf('REDIRECT_URI') > -1) {
                                var url = 'http://' + location.host + location.pathname + location.search;
                                location.replace(response.userAuthUrl.replace('REDIRECT_URI', encodeURIComponent(url)).replace('STATE', 'wxAuth'));
                            }
                        }

                        if (response.userAuthUrl && !response.iswxuser) {
                            redirectToBind();
                        }
                        else if (response.userinfo) {
                            $('html').addClass('success');
                            $scope.userInfo = response.userinfo;
                            $.userInfo = response.userinfo;
                            window.sessionStorage.setItem("userInfo", JSON.stringify(response.userinfo));
                        }

                        if (isAuth) {
                            //alert('iswxuser:' + response.iswxuser);
                            //alert('register:' + response.register);
                            if (response.iswxuser && !response.register) {
                                if (!isloginPage) {
                                    $('html').removeClass('success');
                                    $interval(function () {
                                        location.replace('/storewx/auth/login.html');
                                    }, 200);
                                }
                            }
                            else if (typeof callback == "function") {
                                callback.call(null, response);
                            }
                        }
                        else if (typeof callback == "function") {
                            callback.call(null, response);
                        }
                    }
                }).error(function (error) {
                    alert('getUserInfo/error:' + JSON.stringify(error));
                })
            } else {
                $('html').addClass('success');
            }
        };
        $scope.checkWXLogin(function (response) {
            if (response.register) {
                //已绑定
            }
        }, true);

        //刷新页面
        $scope.doRefresh = function () {
            $scope.$broadcast('scroll.refreshComplete');
            $scope.$broadcast('doRefresh');
        };
    });

    $.myApp = myApp;
});