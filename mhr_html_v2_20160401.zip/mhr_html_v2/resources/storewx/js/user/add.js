define(function (require, exports, module) {
    require('storewx');
    var $mobile = $('[name="mobile"]');

    $.myApp.controller('addCtrl', function ($scope, $http, $timeout, $ionicLoading) {
        $scope.user = [];
        $http({
            method: 'get',
            url: '/store/user/getList.json',
            params: ({
                enabled: true,
                stamp: $.timestamp()
            })
        }).success(function (response) {
            if (response.success) {
                $scope.userList = response.data;
                $.each($scope.userList, function (n, x) {
                    if (x.id == $.getQueryString('id')) {
                        $scope.user = x;
                    }
                })
            }
        });

        //保存修改
        $scope.save = function () {
            if (!$scope.user.username) {
                $.smallAlert('请输入姓名！');
                return;
            }
            if (!$scope.user.mobile) {
                $.smallAlert('请输入手机号！');
                return;
            }
            var resManagerRate = $.validate.checkformat($mobile, 'phone');
            if (!resManagerRate.res || $mobile.val().length != 11) {
                $.smallAlert('手机号码格式不正确！', 1500, function () {
                    $('[name="mobile"]').focus();
                });
                return;
            }
            if (!$scope.user.rePassword && $scope.user.password) {
                $.smallAlert('请再次输入密码！');
                return;
            }
            if ($scope.user.password != $scope.user.rePassword) {
                $.smallAlert('两次密码不相同请重新输入！');
                return;
            }

            var param = {
                username: $scope.user.username,
                mobile: $scope.user.mobile,
                password: $scope.user.password,
                rePassword: $scope.user.rePassword,
                enabled: $scope.user.enabled
            };

            if ($scope.user.id) {
                param['id'] = $scope.user.id;
                param['enabled'] = $scope.user.enabled;
            }
            else {
                param['enabled'] = true;
            }

            $http({
                method: 'POST',
                url: '/store/user/' + ($scope.user.id ? 'update' : 'add'),
                data: $.param(param),
                headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
            }).success(function (response) {
                $ionicLoading.hide();
                if (response.success) {
                    $.smallAlert(response.data, 1500, function () {
                        location.replace('/storewx/user/index.html');
                    });
                } else {
                    $.smallAlert(response.data);
                }
            }).error(function (err) {
                alert('error:' + JSON.stringify(err));
            })
        }
    })
})