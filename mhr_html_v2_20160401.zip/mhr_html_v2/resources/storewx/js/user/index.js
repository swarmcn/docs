define(function (require, exports, module) {
    require('storewx');

    $.myApp.controller('userCtrl', function ($scope, $http, $timeout,$ionicLoading) {

        $scope.getList = function () {
            $scope.isManager = $userInfo.isManager;
            if ($.isTest)
                $scope.isManager = true;

            var params = {
                isWX:true,
                pageNumber: 1,
                pageSize: 20
            };
            if (!$scope.isManager) {
                params.enabled = true;
            }
            $http({
                method: 'get',
                url: '/store/user/getList.json',
                params: (params)
            }).success(function (response) {
                if (response.success) {
                    $scope.userList = response.data;
                }
            });
        };

        var $userInfo = window.sessionStorage.getItem("userInfo");
        if($userInfo) {
            $userInfo = JSON.parse($userInfo);
            $scope.getList();
        }
        else{
            $scope.checkWXLogin(function (response) {
                if (response.register) {
                    $userInfo = $.userInfo;
                    $scope.getList();
                }
            },false);
        }

        //激活和锁定店员
        $scope.toggle = function (x) {
            $ionicLoading.show();
            if ($.isTest){
                $timeout(function () {
                    $ionicLoading.hide();
                }, 2000);
            }
            $http({
                method: 'POST',
                url: '/store/user/toggle',
                data: $.param({
                    id: x.id,
                    enabled: !x.enabled
                }),
                headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
            }).success(function (response) {
                $ionicLoading.hide();
                if (response.success) {
                    x.enabled = !x.enabled;
                    $.smallAlert(response.data);
                }
                else
                    $.smallAlert(response.data);
            });

            if($.isTest)
                x.enabled = !x.enabled;
        };

    })

});


