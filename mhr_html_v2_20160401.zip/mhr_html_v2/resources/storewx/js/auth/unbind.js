define(function (require, exports, module) {
    require('storewx');
    var Guid = require('plugin/guid');
    var captchaId = Guid();//验证码标识
    $('#captchaId').val(captchaId);
    $.myApp.controller('unbindCtrl', function ($scope, $http, $timeout, $ionicLoading) {

        ////更换验证码
        //var $captchaImage = $("#captchaImage");
        //$captchaImage.click(function () {
        //    $(this).removeClass('hide').attr("src", "/common/captcha?captchaId=" + captchaId + "&timestamp=" + new Date().getTime());
        //}).click();//初始化


        //解除绑定
        $scope.unbind = function () {
            if (!$scope.enPassword) {
                $.smallAlert('密码不能为空！', 1500, function () {
                    $('[name="enPassword"]').focus();
                });
                return;
            }

            //if (!$scope.captcha) {
            //    $.smallAlert('验证码不能为空！', 1500, function () {
            //        $('[name="captcha"]').focus();
            //    });
            //    return;
            //}
            $ionicLoading.show();
            if($.isTest){
                $timeout(function () {
                    $ionicLoading.hide();
                },2000);
            }

            //获取公钥
            $http.get('/common/public_key').success(function (response) {

                //调用加密
                seajs.use("plugin/encrypt/secret", function () {
                    var rsaKey = new RSAKey();
                    rsaKey.setPublic(b64tohex(response.modulus), b64tohex(response.exponent));
                    $scope.password = hex2b64(rsaKey.encrypt($scope.enPassword));

                    $http({
                        method: 'POST',
                        url: '/storewx/unbindMember',
                        data: $.param({
                            enPassword: $scope.password
                            //,
                            //captchaId: captchaId,
                            //captcha: $scope.captcha
                        }),
                        headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
                    }).success(function (response) {
                        $ionicLoading.hide();
                        $.smallAlert(response.data);
                        if (response.success)
                            location.replace('login.html');
                        else
                            $captchaImage.click();
                    });
                })
            })
        }


    })
})