define(function (require, exports, module) {
    require('storewx');
    var Guid = require('plugin/guid');
    var $mobile = $('#mobile');
    var $password = $('#password');
    //var Validate = require('plugin/validate.el');

    $.myApp.controller('loginCtrl', function ($scope, $http, $timeout, $ionicLoading) {

        //绑定登录
        $scope.bind = function () {
            if (!$scope.mobile) {
                $.smallAlert('请输入您的手机号码', 1500, function () {
                    $mobile.focus();
                });
                return;
            }

            var resMobile = $.validate.checkformat('#mobile', 'phone');
            if ($scope.mobile.length != 11 || !resMobile.res) {
                $.smallAlert('请输入有效的手机号码', 1500, function () {
                    $mobile.focus();
                });
                return;
            }

            if (!$scope.enPassword) {
                $.smallAlert('请输入您的密码', 1500, function () {
                    $password.focus();
                });
                return;
            }

            $ionicLoading.show();
            if($.isTest){
                $timeout(function () {
                    $ionicLoading.hide();
                },2000);
            }

            //获取公钥
            $http.get('/common/public_key').success(function (response) {

                //alert('public_key:' + JSON.stringify(response));

                //调用加密
                seajs.use("plugin/encrypt/secret", function () {
                    var rsaKey = new RSAKey();
                    rsaKey.setPublic(b64tohex(response.modulus), b64tohex(response.exponent));
                    $scope.password = hex2b64(rsaKey.encrypt($scope.enPassword));

                    //提交绑定
                    $http({
                        method: 'POST',
                        url: '/storewx/bindMember',
                        data: $.param({
                            mobile: $scope.mobile,
                            enPassword: $scope.password
                        }),
                        headers: $.headers
                    }).success(function (response) {
                        $ionicLoading.hide();
                        //alert('bindMember:' + JSON.stringify(response));
                        if (response.success)
                            location.replace('/storewx/clerk/index.html');
                        else
                            $.smallAlert(response.data);
                    }).error(function (err) {
                        $ionicLoading.hide();
                        //alert('error:' + JSON.stringify(err));
                    })

                })
            });
        }
    })
});