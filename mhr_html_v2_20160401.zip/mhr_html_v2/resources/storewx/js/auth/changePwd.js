define(function (require, exports, module) {
    require('storewx');

    var $currentPassword = $('[name="currentPassword"]');
    var $password = $('[name="password"]');
    var $rePassword = $('[name="currentPassword"]');

    $.myApp.controller('changePwdCtrl', function ($scope, $http, $ionicLoading) {
        var delay = 2000;//弹窗显示时间

        $scope.changePwd = function () {
            if (!$scope.currentPassword) {
                $.smallAlert('请输入原密码！',delay, function () {
                    $currentPassword.focus();
                });
                return;
            }
            if (!$scope.password || $scope.password.length < 6) {
                $.smallAlert('新密码不能小于6位！', delay, function () {
                    $password.focus();
                });
                return;
            }
            if (!$scope.rePassword) {
                $.smallAlert('请再次输入密码！',delay, function () {
                    $password.focus();
                });
                return;
            }
            if ($scope.password != $scope.rePassword) {
                $.smallAlert('两次密码不相同！',delay, function () {
                    $rePassword.focus();
                });
                return;
            }
            $ionicLoading.show();

            //提交改密
            $http({
                method: 'POST',
                url: '/store/password/update',
                data: $.param({
                    currentPassword: $scope.currentPassword,
                    password: $scope.password,
                    rePassword: $scope.rePassword
                }),
                headers: $.headers
            }).success(function (response) {
                $ionicLoading.hide();
                if (response.success){
                    $.smallAlert(response.data,delay, function () {
                        location.replace('/storewx/clerk/index.html');
                    });
                }
                else
                    $.smallAlert(response.data);
            });
        }
    })
});