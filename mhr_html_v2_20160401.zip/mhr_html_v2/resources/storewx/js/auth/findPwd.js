define(function (require, exports, module) {
    require('storewx');
    var circle = require('plugin/circle');
    var $sendRandomCode = $("#sendRandomCode");//获取验证码
    var $mobile = $('[name="mobile"]');
    $.myApp.controller('findPwdCtrl', function ($scope, $http, $ionicLoading, $timeout) {
        var delay = 2000;//弹窗显示时间

        //发送验证码
        $sendRandomCode.click(function () {
            if (!$scope.mobile) {
                $.smallAlert('手机号码不能为空！', delay, function () {
                    $mobile.focus();
                });
                return;
            }
            var resManagerRate = $.validate.checkformat($mobile, 'phone');
            if (!resManagerRate.res || $scope.mobile.length != 11) {
                $.smallAlert('手机号码格式不正确！', delay, function () {
                    $mobile.focus();
                });
                return;
            }

            var el = $(this);
            if (el.hasClass('button-positive')) {
                $http({
                    method: 'POST',
                    url: '/store/password/sendRandomCode',
                    data: $.param({
                        mobile: $scope.mobile
                    }),
                    headers: $.headers
                }).success(function (response) {
                    el.removeClass('button-positive');
                    $.smallAlert(response.data);
                    if (response.success) {
                        el.addClass('disabled');
                        circle({
                            'times': 60,
                            'fn': function () {
                                el.text('(' + this.times + ')秒后重试');
                            },
                            'afterfn': function () {
                                el.addClass('button-positive').removeClass('disabled');
                                el.text('获取验证码');
                            }
                        });
                    }
                });
            }
        });

        //找回密码
        $scope.findPwd = function () {
            if (!$scope.mobile) {
                $.smallAlert('手机号码不能为空！', delay, function () {
                    $mobile.focus();
                });
                return;
            }
            var resManagerRate = $.validate.checkformat($mobile, 'phone');
            if (!resManagerRate.res || $scope.mobile.length != 11) {
                $.smallAlert('手机号码格式不正确！', delay, function () {
                    $mobile.focus();
                });
                return;
            }

            if (!$scope.randomCode) {
                $.smallAlert('验证码不能为空！', delay, function () {
                    $('[name="randomCode"]').focus();
                });
                return;
            }
            if (!$scope.newPassword || $scope.newPassword.length < 6) {
                $.smallAlert('密码不能小于6位！', delay, function () {
                    $('[name="newPassword"]').focus();
                });
                return;
            }
            if ($scope.newPassword != $scope.rePassword) {
                $.smallAlert('两次密码不相同！');
                return;
            }
            $ionicLoading.show();
            if ($.isTest) {
                $timeout(function () {
                    $ionicLoading.hide();
                }, 2000);
            }
            $http({
                method: 'POST',
                url: '/store/password/find',
                data: $.param({
                    mobile: $scope.mobile,
                    newPassword: $scope.newPassword,
                    rePassword: $scope.rePassword,
                    randomCode: $scope.randomCode
                }),
                headers: $.headers
            }).success(function (response) {
                $ionicLoading.hide();
                if (response.success) {
                    $.smallAlert(response.data);
                    location.replace('login.html');
                }
                else
                    $.smallAlert(response.data);
            }).error(function (err) {
                alert('findPWD/error:' + JSON.stringify(err));
            })
        }

    })
})