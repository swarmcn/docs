define(function (require, exports, module) {
    require('storewx');
    var status = require('admin/js/store/status');

    $.myApp.controller('assetsCtrl', function ($scope, $http, $timeout) {
        var url = '/store/assets/getHistoryList.json';
        if ($.isTest)
            url = '/storewx/assets/getHistoryList.json';

        var $pageSize = 15;
        $scope.canBeLoaded = false;
        var cookiePageNumber = parseInt(sessionStorage.getItem("assets-page") || 1);
        $scope.getList = function () {
            $scope.assetsList = [];
            $scope.pageSize = $pageSize;
            $scope.currentPage = 0;
            var pageSize = $scope.pageSize * cookiePageNumber || $pageSize;

            $http({
                method: 'get',
                url: url,
                params: ({
                    pageNumber: $scope.currentPage + 1,
                    pageSize: pageSize,
                    stamp: $.timestamp()
                })
            }).success(function (response) {
                if (response.success && response.data && response.data.length > 0) {
                    $scope.assetsList = response.data || null;

                    $scope.canBeLoaded = true;
                    if (pageSize > $pageSize)
                        $scope.currentPage += pageSize / $pageSize;
                    else
                        $scope.currentPage++;

                    if ($scope.assetsList.length < $pageSize)
                        $scope.canBeLoaded = false;
                    else
                        sessionStorage.setItem("assets-page", $scope.currentPage);
                }
                else
                    $scope.assetsList = null;
            })
        };
        $scope.getList();

        $scope.$on('doRefresh', function () {
            $scope.getList();
        });

        //滚动加载
        $scope.loadMore = function () {
            if (!$scope.canBeLoaded || !$scope.assetsList) {
                $scope.$broadcast('scroll.infiniteScrollComplete');
                return;
            }

            var pageSize = $scope.pageSize;
            $http({
                method: 'get',
                url: url,
                params: ({
                    pageNumber: $scope.currentPage + 1,
                    pageSize: pageSize,
                    stamp: $.timestamp()
                })
            }).success(function (response) {
                if (response.success && response.data && response.data.length > 0) {
                    if ($scope.assetsList.length == 0) {
                        $timeout(function () {
                            $scope.$emit('scrollTo', pageSize > $pageSize);
                        }, 100);
                    }
                    $.each(response.data, function (n, x) {
                        if(!$('#assets'+ x.createDate)[0])
                            $scope.assetsList.push(x);
                        else
                            $scope.canBeLoaded = false;
                    });
                    if (pageSize > $pageSize)
                        $scope.currentPage += pageSize / $pageSize;
                    else
                        $scope.currentPage++;

                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    sessionStorage.setItem("assets-page", $scope.currentPage);
                } else {
                    if (response.totalCount == 0 || !response.data) {
                        $scope.canBeLoaded = false;
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    }
                }
            });
        };
    })
});


