define(function (require, exports, module) {
    require('jquery');

    var provinceId = null;
    var provinceName = null;
    var cityId = null;
    var cityName = null;
    var districtId = null;
    var $areaSelect = $('.selectDistrict select');

    //新浪接口
    $.getScript('http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=js', function (_result) {
        if (remote_ip_info.ret == '1') {

            provinceName = remote_ip_info.province;
            cityName = remote_ip_info.city;
            //createProvince($areaSelect);
        } else {
            console.log('错误:没有找到匹配的 IP 地址信息！');
            //createProvince($areaSelect);
        }
    });

    function createDistrict(obj, cid) {
        var el = $(obj).eq(2);
        districtId = el.attr('data');
        var url = '/common/areas/getList.json?parentId=' + cid;
        if (location.host.indexOf('localhost') > -1)
            url = '/member/areas/getDistrict.json';

        $.get(url, function (response) {
            var html = '';
            if (response.success) {
                $.each(response.data, function (n, x) {
                    html += '<option value="' + x.id + '">' + x.name + '</option>';
                });
                el.html(html).show();

                if (districtId)
                    el.val(districtId);
            }else
                el.html('').hide();
        }, 'json');
    }

    function createCity(obj, pid) {
        var el = $(obj).eq(1);
        cityId = el.attr('data');
        var url = '/common/areas/getList.json?parentId=' + pid;
        if (location.host.indexOf('localhost') > -1)
            url = '/member/areas/getCity.json';

        //change事件
        el.unbind('change').bind('change', function () {
            createDistrict(obj, this.value);
            el.attr('data', this.value);
        });

        $.get(url, function (response) {
            var html = '';
            if (response.success) {
                var firstId = 0;
                $.each(response.data, function (n, x) {
                    html += '<option value="' + x.id + '">' + x.name + '</option>';
                    if(n == 0) firstId = x.id;
                    if (!cityId && x.name.indexOf(cityName) > -1)
                        cityId = x.id;
                });
                el.html(html).show();
                if (!cityId)
                    cityId = firstId;

                el.val(cityId);
                createDistrict(obj, cityId);
            }else
                el.html('').hide();
        }, 'json');
    }

    function createProvince(obj) {
        var el = $(obj).eq(0);
        provinceId = el.attr('data');
        var url = '/common/areas/getList.json';
        if (location.host.indexOf('localhost') > -1)
            url = '/member/areas/getList.json';

        //change事件
        el.unbind('change').bind('change', function () {
            $(obj).removeAttr('data');
            createCity(obj, this.value);
        });

        $.get(url, function (response) {
            var html = '';
            if (response.success) {
                var firstId = 0;
                $.each(response.data, function (n, x) {
                    html += '<option value="' + x.id + '">' + x.name + '</option>';

                    if(n == 0) firstId = x.id;
                    if (!provinceId && x.name.indexOf(provinceName) > -1)
                        provinceId = x.id;
                });
                el.html(html).show();
                if (!provinceId)
                    provinceId = firstId;

                el.val(provinceId);
                createCity(obj, provinceId);
            } else
                el.html('').hide();
        }, 'json');
    }

    return createProvince;
});