define(function (require, exports, module) {
    require('jquery');
    require('plugin/message');
    require('cookie');

    var smallLoading = require('plugin/small-loading');
    var smallTimeout = require('plugin/small-timeout');
    var pathname = location.pathname.toLowerCase();
    //有使用POST时，获取token
    //var token = $.cookie("token");

    // 令牌
    $(document).ajaxSend(function(event, request, settings) {
        if (!settings.crossDomain && settings.type != null && settings.type.toLowerCase() == "post") {
            if ($.cookie("token") != null) {
                request.setRequestHeader("token", $.cookie("token"));

                //微信滚动条
                if(pathname.indexOf('/weixin/') > -1){
                    smallLoading();
                }
            }
        }
    });

    // 检测登录
    $.checkLogin = function() {
        var result = false;
        $.ajax({
            url: "/login/check",
            type: "GET",
            dataType: "json",
            cache: false,
            async: false,
            success: function(data) {
                result = data;
            }
        });
        return result;
    };

    // 跳转登录
    $.redirectToLogin = function (redirectUrl, msg) {
        var href = "/auth/login.html";
        if (redirectUrl != null) {
            href += "?redirectUrl=" + encodeURIComponent(redirectUrl);
        }
        if (msg) {
            $.message("warn", msg);
        } else {
            $.message("warn", "请登录后再进行操作");
        }
        setTimeout(function() {
            location.href = href;
        }, 2000);
    };

    $(document).ajaxComplete(function(event, request, settings) {
        var loginStatus = request.getResponseHeader("loginStatus");
        var tokenStatus = request.getResponseHeader("tokenStatus");

        if (loginStatus == "accessDenied") {
            $.redirectToLogin(location.href,"请登录后再进行操作");
        } else if (tokenStatus == "accessDenied") {
            if ($.cookie("token") != null) {
                $.extend(settings, {
                    global: false,
                    headers: {
                        token: $.cookie("token")
                    }
                });
                $.ajax(settings);
            }
        }

        if(pathname.indexOf('/weixin/') > -1) {
            if (settings.type.toLowerCase() == "post")
                $('.small-loading').remove();

            var statusText = request.statusText.toLowerCase();
            if (statusText.indexOf('error') > -1 || statusText.indexOf('network_err') > -1)
                smallTimeout();
        }
    });

    //ajax请求错误
    $(document).ajaxError(function(){
        if(pathname.indexOf('/weixin/') > -1) {
            smallTimeout();
        }
    });

    //表单令牌
    $("form").submit(function() {
        var $this = $(this);
        if ($this.attr("method") != null && $this.attr("method").toLowerCase() == "post" && $this.find("input[name='token']").size() == 0) {
            if ($.cookie("token") != null) {
                $this.append('<input type="hidden" name="token" value="' + $.cookie("token") + '" \/>');
            }
        }
    });

    //post表单传值并跳转
    $.postForm = function (URL, PARAMS, TARGET) {
        var temp = document.createElement("form");
        temp.action = URL;
        temp.method = "post";
        temp.target = TARGET || '_self';
        temp.style.display = "none";
        for (var x in PARAMS) {
            var opt = document.createElement("textarea");
            opt.name = x;
            opt.value = PARAMS[x];
            temp.appendChild(opt);
        }
        document.body.appendChild(temp);
        temp.submit();
        return temp;
    };
});