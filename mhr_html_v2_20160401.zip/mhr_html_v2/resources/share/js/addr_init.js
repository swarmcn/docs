define(function (require, exports) {
    require('jquery');
    var provinceId = null;
    var provinceName = null;
    var cityId = null;
    var cityName = null;
    var districtId = null;
    var $areaSelect = $('.selectDistrict select');

    //新浪接口
    $.getScript('http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=js', function (_result) {
        if (remote_ip_info.ret == '1') {

            provinceName = remote_ip_info.province;
            cityName = remote_ip_info.city;
            createProvince($areaSelect);
            //seajs.use('app/share/js/addr', function (addr) {
            //    for (var pid in addr.province) {
            //        if (addr.province[pid].indexOf(province) != -1) {
            //            provinceId = pid;
            //            for (var cid in addr.city[pid]) {
            //                if (addr.city[pid][cid].indexOf(city) != -1) {
            //                    cityId = cid;
            //                    initSelects();
            //                    break;
            //                }
            //            }
            //        }
            //    }
            //});
        } else {
            console.log('错误:没有找到匹配的 IP 地址信息！');
            createProvince($areaSelect);
        }
    });

    function createDistrict(obj, cid) {
        var el = $(obj).eq(2);
        districtId = el.attr('data');
        var url = '/common/areas/getList.json?parentId=' + cid;
        if (location.host.indexOf('localhost') > -1)
            url = '/member/areas/getDistrict.json';

        $.get(url, function (response) {
            var html = '';
            if (response.success) {
                $.each(response.data, function (n, x) {
                    html += '<option value="' + x.id + '">' + x.name + '</option>';
                });
                el.html(html);
                if (html.length > 0)
                    el.show();
                else
                    el.hide();
                if (districtId)
                    el.val(districtId);
            }
        }, 'json');
    }

    function createCity(obj, pid) {
        var el = $(obj).eq(1);
        cityId = el.attr('data');
        var url = '/common/areas/getList.json?parentId=' + pid;
        if (location.host.indexOf('localhost') > -1)
            url = '/member/areas/getCity.json';

        //change事件
        el.unbind('change').bind('change',function () {
            createDistrict(obj, this.value);
        });

        $.get(url, function (response) {
            var html = '';
            if (response.success) {
                $.each(response.data, function (n, x) {
                    html += '<option value="' + x.id + '">' + x.name + '</option>';

                    if (!cityId && x.name.indexOf(cityName) > -1)
                        cityId = x.id;
                });
                el.html(html);
                if (html.length > 0)
                    el.show();
                else
                    el.hide();
                if (cityId)
                    el.val(cityId);
                createDistrict(obj, el[0].value);
            }
        }, 'json');
    }

    function createProvince(obj) {
        var el = $(obj).eq(0);
        provinceId = el.attr('data');
        var url = '/common/areas/getList.json';
        if (location.host.indexOf('localhost') > -1)
            url = '/member/areas/getList.json';

        //change事件
        el.unbind('change').bind('change',function () {
            createCity(obj, this.value);
        });

        $.get(url, function (response) {
            var html = '';
            if (response.success) {
                $.each(response.data, function (n, x) {
                    html += '<option value="' + x.id + '">' + x.name + '</option>';

                    if (!provinceId && x.name.indexOf(provinceName) > -1)
                        provinceId = x.id;
                });
                el.html(html);
                if (html.length > 0)
                    el.show();
                else
                    el.hide();
                if (provinceId)
                    el.val(provinceId);
                createCity(obj, el[0].value);
            }
        }, 'json');
    }


    function initSelects(obj) {
        //var Selects = require('app/js/selects');
        var addrs = [];
        seajs.use('app/share/js/addr', function (addr) {

            var isHas, firstId, lis, arr;
            var province_id = $('input[name="provinceId"]').val() || $('select.provinceId').val() || provinceId;
            var city_id = $('input[name="cityId"]').val() || $('select.cityId').val() || cityId;
            var district_id = $('input[name="districtId"]').val() || $('select.districtId').val() || districtId;

            if (!city_id) {
                for (var t in addr.city[province_id]) {
                    if (!city_id) {
                        city_id = t;
                    }
                }
                ;
            }

            //系统自带的下拉框
            createProvince('.selectDistrict select');

            //系统自带的下拉框
            //$('.selectDistrict select').each(function () {
            //    var el = $(this);
            //    if (el.attr('name') == 'provinceId' || el.hasClass('provinceId')) {
            //        isHas = false;
            //        firstId = '';
            //        province_id = el.attr('data') || provinceId;
            //
            //        lis = '';
            //        arr = [];
            //        $.each(addr.province, function (n, v) {
            //            arr.push(v + '|' + n);
            //        });
            //        arr.sort(function (a, b) {
            //            return a.localeCompare(b)
            //        });
            //        for (var i = 0; i < arr.length; i++) {
            //            var v = arr[i].split('|')[0];
            //            var n = arr[i].split('|')[1];
            //            if (i == 0)
            //                firstId = n;
            //            if (n == province_id)
            //                isHas = true;
            //            lis += '<option value="' + n + '">' + v + '</option>'
            //        }
            //        el.html(lis);
            //
            //        if (!isHas)
            //            province_id = firstId;
            //        el.val(province_id).attr('data', province_id);
            //        //if(obj != el.next('select'))
            //        //el.next('select').html('').attr('data','');
            //    }
            //    else if (el.attr('name') == 'cityId' || el.hasClass('cityId')) {
            //        city_id = el.attr('data') || cityId;
            //        isHas = false;
            //        firstId = '';
            //
            //        lis = '';
            //        arr = [];
            //        $.each(addr.city[province_id], function (n, v) {
            //            arr.push(v + '|' + n);
            //        });
            //        for (var i = 0; i < arr.length; i++) {
            //            var v = arr[i].split('|')[0];
            //            var n = arr[i].split('|')[1];
            //            if (i == 0)
            //                firstId = n;
            //            if (n == city_id)
            //                isHas = true;
            //            lis += '<option value="' + n + '">' + v + '</option>'
            //        }
            //        el.html(lis);
            //
            //        if (!isHas)
            //            city_id = firstId;
            //        el.val(city_id).attr('data', city_id);
            //        //if(obj != el.next('select') && addr.district[city_id].length == 0)
            //        //el.next('select').html('').attr('data','');
            //    }
            //    else if (el.attr('name') == 'districtId' || el.hasClass('districtId')) {
            //        district_id = el.attr('data') || districtId;
            //        isHas = false;
            //        firstId = '';
            //
            //        lis = '';
            //        arr = [];
            //        $.each(addr.district[city_id], function (n, v) {
            //            arr.push(v + '|' + n);
            //        });
            //        for (var i = 0; i < arr.length; i++) {
            //            var v = arr[i].split('|')[0];
            //            var n = arr[i].split('|')[1];
            //            if (i == 0)
            //                firstId = n;
            //            if (n == district_id)
            //                isHas = true;
            //            lis += '<option value="' + n + '">' + v + '</option>'
            //        }
            //        if (lis.length == 0)
            //            el.hide();
            //        else
            //            el.show();
            //        el.html(lis);
            //
            //        if (!isHas)
            //            district_id = firstId;
            //        el.val(district_id).attr('data', district_id);
            //    }
            //
            //    el.change(function () {
            //        el.attr('data', el.val());
            //        if (el.attr('name') != 'districtId' && !el.hasClass('districtId')) {
            //            initSelects(el);
            //        }
            //    });
            //});

            //bootstrap的下拉框
            $('.dropdownDistrict .dropdown').each(function () {
                var dropdown = $(this);
                var n_k = $('input:hidden', dropdown);
                var button = $('.dropdown-toggle', dropdown);
                var menu = $('.dropdown-menu', dropdown);
                if (n_k.attr('name') == 'provinceId' || n_k.hasClass('provinceId')) {
                    isHas = false;
                    firstId = '';

                    $('li:not(.dropdown-header)', menu).remove();

                    lis = '';
                    arr = [];
                    $.each(addr.province, function (n, v) {
                        arr.push(v + '|' + n);
                    })
                    //arr.sort(function (a,b) {
                    //    return a.localeCompare(b)
                    //});
                    for (var i = 0; i < arr.length; i++) {
                        var v = arr[i].split('|')[0];
                        var n = arr[i].split('|')[1];
                        if (i == 0)
                            firstId = n;
                        if (n == province_id)
                            isHas = true;
                        lis += '<li><a href="javascript:;" tabindex="-1" data="' + n + '">' + v + '</a></li>'
                    }
                    menu.append(lis);

                    if (!isHas)
                        province_id = firstId;
                    n_k.val(province_id);
                }
                else if (n_k.attr('name') == 'cityId' || n_k.hasClass('cityId')) {
                    isHas = false;
                    firstId = '';

                    $('li:not(.dropdown-header)', menu).remove();

                    lis = '';
                    arr = [];
                    $.each(addr.city[province_id], function (n, v) {
                        arr.push(v + '|' + n);
                    })
                    //arr.sort(function (a,b) {
                    //    return a.localeCompare(b)
                    //});
                    for (var i = 0; i < arr.length; i++) {
                        var v = arr[i].split('|')[0];
                        var n = arr[i].split('|')[1];
                        if (i == 0)
                            firstId = n;
                        if (n == city_id)
                            isHas = true;
                        lis += '<li><a href="javascript:;" tabindex="-1" data="' + n + '">' + v + '</a></li>'
                    }
                    menu.append(lis);

                    if (!isHas)
                        city_id = firstId;
                    n_k.val(city_id);
                } else if (n_k.attr('name') == 'districtId' || n_k.hasClass('districtId')) {
                    isHas = false;
                    firstId = '';

                    $('li:not(.dropdown-header)', menu).remove();

                    lis = '';
                    arr = [];
                    $.each(addr.district[city_id], function (n, v) {
                        arr.push(v + '|' + n);
                    })
                    //arr.sort(function (a,b) {
                    //    return a.localeCompare(b)
                    //});
                    for (var i = 0; i < arr.length; i++) {
                        var v = arr[i].split('|')[0];
                        var n = arr[i].split('|')[1];
                        if (i == 0)
                            firstId = n;
                        if (n == district_id)
                            isHas = true;
                        lis += '<li><a href="javascript:;" tabindex="-1" data="' + n + '">' + v + '</a></li>'
                    }
                    menu.append(lis);

                    if (!isHas)
                        district_id = firstId;
                    n_k.val(district_id);
                }

                $('a[data]', dropdown).each(function () {
                    var el = $(this);
                    var data = el.attr('data');
                    var pt = el.parents('.dropdown');

                    var hidden = $('input:hidden', pt);
                    //var name = hidden.attr('name');

                    var btn = $('[data-toggle="dropdown"]', pt);
                    if (data.length > 0 && hidden.val() == data) {
                        btn.html(el.text() + '&nbsp;<span class="caret"></span>');
                        $('.dropdown-menu li', pt).removeClass('active');
                        el.parent().addClass('active');
                    }

                    el.click(function () {
                        //赋值
                        hidden.val(data);
                        //高亮
                        btn.html(el.text() + '&nbsp;<span class="caret"></span>');
                        $('.dropdown-menu li', pt).removeClass('active');
                        el.parent().addClass('active')

                        initSelects();
                    });
                });
            })


            //
            //$('.select_item').each(function () {
            //    var el = $(this);
            //    var n_k = $('[formtype="val_item"]', el);
            //    if (n_k.attr('name') == 'provinceId') {
            //        var d_v = $('[formtype="val_item"]', el).val() || province_id;
            //        var sl = new Selects(this, null, {
            //            'data': addr.province,
            //            'after_fn': function (data) {
            //                if (addrs[1]) {
            //                    addrs[1].render_data(addr.city[data]);
            //                    addrs[1].first();
            //                }
            //            }
            //        });
            //        if (d_v) {
            //            sl.select(d_v)
            //        }
            //        addrs.push(sl);
            //    }
            //    else if (n_k.attr('name') == 'cityId') {
            //        var d_v = $('[formtype="val_item"]', el).val() || city_id;
            //        var sl = new Selects(this, null, {
            //            'data': addr.city[province_id],
            //            'after_fn': function (data) {
            //                if (addrs[2]) {
            //                    addrs[2].render_data(addr.district[data]);
            //                    addrs[2].first();
            //                }
            //            }
            //        });
            //        if (d_v) {
            //            sl.select(d_v);
            //        }
            //        addrs.push(sl);
            //    } else {
            //        var d_v = $('[formtype="val_item"]', el).val() || district_id;
            //        var sl = new Selects(this, null, {
            //            'data': addr.district[city_id],
            //            'after_fn': function () {
            //
            //            }
            //        });
            //        if (d_v) {
            //            sl.select(d_v);
            //        }
            //        addrs.push(sl);
            //    }
            //})
        })
    }
});