/**
 * Created by sg009 on 15/六月/29.
 */
define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('bootstrap');
    require('token');//令牌，POST时必须调用
    require('cookie');

    var Alert = require('plugin/alert');
    var Modal = require('plugin/modal');
    var Guid = require('plugin/guid');
    var $delegate = require('plugin/delegateEvent');
    var captchaId = Guid();//验证码标识

    var formatJson = function (json, options) {
        var reg = null,
            formatted = '',
            pad = 0,
            PADDING = '    '; // one can also use '\t' or a different number of spaces

        // optional settings
        options = options || {};
        // remove newline where '{' or '[' follows ':'
        options.newlineAfterColonIfBeforeBraceOrBracket = (options.newlineAfterColonIfBeforeBraceOrBracket === true) ? true : false;
        // use a space after a colon
        options.spaceAfterColon = (options.spaceAfterColon === false) ? false : true;

        // begin formatting...
        if (typeof json !== 'string') {
            // make sure we start with the JSON as a string
            json = JSON.stringify(json);
        } else {
            // is already a string, so parse and re-stringify in order to remove extra whitespace
            json = JSON.parse(json);
            json = JSON.stringify(json);
        }

        // add newline before and after curly braces
        reg = /([\{\}])/g;
        json = json.replace(reg, '\r\n$1\r\n');

        // add newline before and after square brackets
        reg = /([\[\]])/g;
        json = json.replace(reg, '\r\n$1\r\n');

        // add newline after comma
        reg = /(\,)/g;
        json = json.replace(reg, '$1\r\n');

        // remove multiple newlines
        reg = /(\r\n\r\n)/g;
        json = json.replace(reg, '\r\n');

        // remove newlines before commas
        reg = /\r\n\,/g;
        json = json.replace(reg, ',');

        // optional formatting...
        if (!options.newlineAfterColonIfBeforeBraceOrBracket) {
            reg = /\:\r\n\{/g;
            json = json.replace(reg, ':{');
            reg = /\:\r\n\[/g;
            json = json.replace(reg, ':[');
        }
        if (options.spaceAfterColon) {
            reg = /\:/g;
            json = json.replace(reg, ': ');
        }

        $.each(json.split('\r\n'), function (index, node) {
            var i = 0,
                indent = 0,
                padding = '';

            if (node.match(/\{$/) || node.match(/\[$/)) {
                indent = 1;
            } else if (node.match(/\}/) || node.match(/\]/)) {
                if (pad !== 0) {
                    pad -= 1;
                }
            } else {
                indent = 0;
            }

            for (i = 0; i < pad; i++) {
                padding += PADDING;
            }

            formatted += padding + node + '\r\n';
            pad += indent;
        });

        return formatted;
    };


    //表单序列化为JSON
    $.fn.serializeObject = function () {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };

    //更换验证码
    $delegate('#captchaImage',{
        'click': function () {
            $(this).attr("src", "/common/captcha?captchaId=" + captchaId + "&timestamp=" + new Date().getTime());
        }
    });

    //登录
    $delegate('#btnLogin',{
        'click': function () {
            var $submit = $(this);
            var $username = $('#username');
            var $password = $('#password');
            var $captcha = $("#captcha");

            if ($username.val() == "") {
                $username.focus();
                return false;
            }
            if ($password.val() == "") {
                $password.focus();
                return false;
            }
            if ($captcha.val() == "") {
                $captcha.focus();
                return false;
            }

            //获取公钥
            $.ajax({
                url: "/common/public_key",
                type: "GET",
                dataType: "json",
                cache: false,
                beforeSend: function () {
                    $submit.prop("disabled", true);
                },
                success: function (data) {
                    //调用加密
                    seajs.use("plugin/encrypt/secret", function () {
                            var rsaKey = new RSAKey();
                            rsaKey.setPublic(b64tohex(data.modulus), b64tohex(data.exponent));
                            var enPassword = hex2b64(rsaKey.encrypt($password.val()));

                            //提交表单
                            $.ajax({
                                url: $('.btn.active :radio').val(),
                                type: "POST",
                                data: {
                                    username: $username.val(),
                                    enPassword: enPassword,
                                    captchaId: captchaId,
                                    captcha: $captcha.val()
                                },
                                dataType: "json",
                                cache: false,
                                success: function (message) {
                                    if(message.type) {
                                        if (message.type == "success") {
                                            location.reload();
                                        } else {
                                            alert(message.content);
                                            $('#captchaImage').click();
                                            $submit.prop("disabled", false);
                                        }
                                    }
                                    else {
                                        if(message.success){
                                            location.reload();
                                        }else{
                                            alert(message.data);
                                            $('#captchaImage').click();
                                            $submit.prop("disabled", false);
                                        }
                                    }
                                }
                            });
                        }
                    );
                }
            });
        }
    });

    //单选按钮
    $delegate('.btn-group .btn.btn-default',{
        'click': function () {
            var el = $(this);
            var box = el.parent();
            $('.btn',box).removeClass('active');
            $(':radio',box).removeAttr('checked');

            el.addClass('active');
            $(':radio',el).attr('checked','checked');
        }
    });

    angular.module('myApp', [])
        //ajax请求全局配置
        .config(['$httpProvider', function ($httpProvider) {
            $httpProvider.defaults.headers.common['token'] = $.cookie('token') || 0;
            $httpProvider.defaults.headers.common['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
            $httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
        }])
        .controller('bodyCtrl', function ($scope, $http) {

            $scope.username = $.cookie('adminUsername') || $.cookie('username');
            $scope.locationHost = 'http://' + location.hostname;
            $scope.type = 'GET';
            $scope.url = '';

            //提交表单
            $scope.submit = function () {
                $('#response').html('');
                if ($scope.url.length > 0) {
                    $.ajax({
                        url: $scope.url,
                        type: $scope.type,
                        data: $('#inputForm').serializeObject(),
                        dataType: "json",
                        cache: false,
                        success: function (response) {
                            if ($.isPlainObject(response))
                                $('#response').val(formatJson(response));
                            else
                                $('#response').val(response);
                        },
                        error: function (err) {
                            $('#response').val(formatJson(err));
                        }
                    });
                }
                else {
                    new Alert('URL不能为空','danger','.alert-box');
                }
            };

            //登录弹窗
            $scope.openLogin = function (el) {
                el = el.target;
                var body = '<div class="form-group btn-group">' +
                    '<label class="btn btn-default active"><input type="radio" name="loginUrl" class="hide" checked="checked" value="/login/submit">普通用户</label>' +
                    '<label class="btn btn-default"><input type="radio" name="loginUrl" class="hide" value="/admin/newlogin">管理员用户</label></div>' +
                    '<div class="form-group"><input id="username" type="text" class="form-control" placeholder="请输入用户名"></div>' +
                    '<div class="form-group"><input id="password" type="password" class="form-control" placeholder="请输入密码"></div>' +
                    '<div class="input-group form-group clr" style="margin-bottom: 0;">' +
                    '<input id="captcha" type="text" class="form-control" placeholder="请输入验证码">' +
                    '<span class="input-group-addon" style="padding: 1px 5px;">' +
                    '<img id="captchaImage" title="点击更换验证码" src="/common/captcha?captchaId='+captchaId+'&timestamp=1437016200413">' +
                    '</span>' +
                    '</div>';

                var myModal = new Modal(el,{
                    title: '登录',
                    body: body,
                    size: 'sm',
                    footer:'<a id="btnLogin" class="btn btn-primary btn-block">登录</a>',
                    marginTop:$(window).height()/2-200
                });


            };

            $scope.logout = function () {
                var url = '/logout';
                if($.cookie('adminUsername'))
                    url = '/admin/logout';
                $http.get(url).success(function () {
                    location.reload(true);
                });
            };
        });
});