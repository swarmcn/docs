define(function (require, exports, module) {

    ////关闭页面提示
    //window.onbeforeunload = function () {
    //    var bool = "关闭页面，您输入的数据可能不会被保存？";
    //    if (1 == 1)//出现条件
    //        return bool;
    //};


    require('jquery');
    require('plugin/jquery-ui/jquery-ui.css');
    var $delegate = require('plugin/delegateEvent');

    $.base64 = require('plugin/encrypt/base64');
    $.Validate = require('plugin/validate.el')
    $.circle = require('plugin/circle');
    $.Alert = require('plugin/alert');
    $.headers = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'};

    //关键字搜索商品/jquery-ui/autocomplete
    $delegate('#key-product', {
        'focus': function () {
            var el = $(this);
            var $productId = $('[name="productId"]');
            if (!el.hasClass('ui-autocomplete-input')) {
                seajs.use('plugin/jquery-ui/jquery-ui-1.11.4', function () {
                    el.autocomplete({
                        delay: 200,
                        minLength: 1,
                        source: function (request, response) {
                            var term = request.term;
                            $.getJSON("/product/getProductList.json", {
                                keyword: term,
                                pageNumber: 1,
                                pageSize: 10,
                                stamp: new Date().getTime()
                            }, function (data, status, xhr) {
                                if (data.success && data.totalCount > 0) {
                                    response($.map(data.data, function (item) {
                                        return {
                                            term: term,
                                            label: item.fullName,
                                            value: item.fullName,
                                            id: item.id
                                        }
                                    }));
                                }
                                else {
                                    response([{
                                        term: term,
                                        label: '没有找到与“' + term + '”相关的商品',
                                        disabled: true
                                    }]);
                                }
                            });
                        },
                        open: function (event, ui) {
                            $productId.val('');//打开时清空
                        },
                        select: function (event, ui) {
                            $productId.val(ui.item.id);//选中时赋值
                        },
                        close: function (event, ui) {
                            if (!$productId.val()) {
                                el.val('').focus();//有关键字却没选中时清空
                            }
                        }
                    }).data("ui-autocomplete")._renderItem = function (ul, item) {
                        return $("<li>").addClass(item.disabled ? 'ui-state-disabled' : '')
                            .append("<a>" + (item.label + '').replace(item.term, '<font color="red">' + item.term + '</font>') + "</a>")
                            .appendTo(ul);
                    };
                })
            }
        }
    });

    seajs.use('store', function (ex) {
        //今天的时间戳
        $.timestamp_today = new Date(new Date().Format('yyyy/MM/dd 00:00:00')).getTime();

        var myApp = ex.myApp;

        myApp.factory('$orderInfo', function () {
            return {};
        });

        myApp.config(function ($routeProvider) {
            $routeProvider
                .when('/pos/shopCart', {
                    templateUrl: 'pos/shopCart.html',
                    publicAccess: true,
                    controller: 'shopCartCtrl'
                })

                .when('/pos/receiver/:userId', {
                    templateUrl: 'pos/receiver.html',

                    controller: 'receiverCtrl'
                })

                .when('/pos/submitOrder/:userId', {
                    templateUrl: 'pos/submitOrder.html',
                    publicAccess: true,
                    controller: 'submitOrderCtrl'
                })

                .when('/pos/payment', {
                    templateUrl: 'pos/payment.html',
                    publicAccess: true,
                    controller: 'paymentCtrl'
                })

                .otherwise({
                    redirectTo: '/pos/shopCart'
                });
        });

        //myApp
        $.myApp = myApp;

        //录入商品
        require('store/js/pos/shopCart');

        //收货信息
        require('store/js/pos/receiver');

        //提交订单
        require('store/js/pos/submitOrder');

        //支付订单
        require('store/js/pos/payment');
    });

});