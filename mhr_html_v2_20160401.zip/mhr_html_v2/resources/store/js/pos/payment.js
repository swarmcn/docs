define(function (require, exports, module) {

    //支付订单
    $.myApp.controller('paymentCtrl', function ($scope, $http, $timeout, $location, $orderInfo) {
        $scope.nextBtn = '刷新订单状态';
        $scope.step = 'payment';
        $scope.disabledBtn = false;
        //$scope.step = 'finished';

        //关闭页面提示
        window.onbeforeunload = function () {
            return "关闭页面，您输入的数据可能不会被保存？";
        };


        if ($.isTest) {
            $orderInfo.data = [{
                id: 123,
                sn: "2015123456",
                amount: 20
            }, {
                id: 444,
                sn: "2015122234",
                amount: 22
            }, {
                id: 446,
                sn: "2015122236",
                amount: 22
            }];
        }

        $scope.orderInfo = $orderInfo.data;

        if (!$orderInfo.data)
            $location.path('/pos/shopCart');
        else {
            if($scope.orderInfo.length > 1){
                $scope.orderTip = '因商品通关方式不同，已为您拆单，请分别支付！'
            }

            //订单号条形码
            $timeout(function () {
                seajs.use('plugin/jquery/jquery-barcode', function () {
                    $.each($scope.orderInfo, function (n, x) {
                        $("#barcode" + x.sn).barcode(x.sn, "code128", {
                            barWidth: 2,
                            barHeight: 100,
                            showHRI: true,
                            fontSize: 30
                        });
                        x.isPaid = false;
                    });
                })
            }, 100);

            //获取支付状态
            var times = 0;//循环次数
            $scope.getPayStatus = function (b) {
                var paid = 0;
                console.log(1);
                if(!b && times > 100)
                    return;//自动刷新上限100次
                $.each($scope.orderInfo, function (n, x) {
                    if (!x.isPaid) {
                        if(b) {//手动时
                            $scope.disabledBtn = true;
                            $scope.nextBtn = '正在刷新...';
                        }
                        $http({
                            method: 'POST',
                            url: '/store/order/getPayStatus',
                            data: $.param({
                                orderId: x.id
                            }),
                            headers: $.headers
                        }).success(function (response) {
                            $timeout(function () {
                                $scope.disabledBtn = false;
                            }, 2000);
                            if (!response) {
                                $scope.nextBtn = '刷新订单状态';
                                $scope.step = 'payment';
                            }
                            else {
                                x.isPaid = true;
                                $timeout(function () {
                                    $scope.nextBtn = '完成';
                                    $scope.step = 'finished';
                                },500);
                            }
                        });
                    }
                    else
                        paid++;
                });
                if (!b && paid < $scope.orderInfo.length) {
                    times++;//循环次数
                    $timeout(function () {
                        $scope.getPayStatus();
                    }, 5000);
                }
                if($.isTest){
                    $timeout(function () {
                        $scope.disabledBtn = false;
                        $scope.nextBtn = '刷新订单状态';
                        $scope.step = 'payment';
                    },2000);
                }
            };

            //30秒后开始请求订单状态
            $timeout(function () {
                $scope.getPayStatus();
            }, 30000);
        }

        //下一步
        $scope.nextStep = function () {
            if ($scope.step == 'payment') {
                $scope.getPayStatus(true);
            }
            else {
                $location.path('/pos/shopCart');
                $location.replace();
            }
        }
    });
});