define(function (require, exports, module) {

    //收货信息
    $.myApp.controller('receiverCtrl', function ($scope, $http, $timeout, $location, $routeParams, $orderInfo) {
        $scope.step = 'receiver';
        var $mobile = $('[name="mobile"]');
        var $receiverId = $('[name="receiverId"]');
        var areaSelect = require('share/js/addrSelect');
        var $select = $('.selectArea select');

        //关闭页面提示
        window.onbeforeunload = function () {
            if($receiverId.val().length > 0)
                return "关闭页面，您输入的数据可能不会被保存？";
        };

        //解析加密后的店员ID
        $scope.userId = null;
        try {
            $scope.userId = parseInt($.base64.decode($routeParams.userId)) - $.timestamp_today;
            if ($scope.userId <= 0) {
                $location.path('/pos/shopCart');
                $location.replace();
            }
        }
        catch (ex) {
            $location.path('/pos/shopCart');
            $location.replace();
            return;
        }

        //搜索用户
        $scope.search = function () {
            $scope.mobile = $mobile.val();
            var resPhone = $.Validate.checkformat($mobile, 'phone');
            if ($scope.mobile && $scope.mobile.length == 11 && resPhone.res) {
                $http.get('/store/member/getReceiverList.json?mobile=' + $scope.mobile).success(function (response) {
                    if (response.success) {
                        if (!response.memberId) {
                            new $.Alert('本号码是新会员', 'success');
                        }
                        $scope.memberId = response.memberId;
                        $receiverId.val('');
                        $receiverId.next().find('span:first').text('请选择收货地址');
                        $scope.addr = [];
                        $scope.receiverList = response.data;

                        $scope.receiverList.push({
                            "id": -1
                        });

                        $timeout(function () {
                            $.initDropdown();
                            areaSelect($select);
                        }, 100);
                    } else {
                        new $.Alert(response.data, 'error');
                    }
                });

                if ($.isTest) {
                    $scope.memberId = 1;
                    $receiverId.val('');
                    $receiverId.next().find('span:first').text('请选择收货地址');
                    $scope.addr = [];
                    $scope.receiverList = [{
                        "id": 0,
                        "areaCode1": 926,
                        "areaCode2": 927,
                        "areaCode3": 929,
                        "areaFullname": "浙江省杭州市余杭区",
                        "address": "仓前街道良睦路1288号",
                        "zipCode": "310001"
                    }, {
                        "address": "龙腰路1288号哈哈哈哈哈哈哈哈",
                        "areaCode1": 926,
                        "areaCode2": 927,
                        "areaCode3": 929,
                        "areaFullname": "浙江省杭州市余杭区",
                        "areaId": 935,
                        "consignee": "卡卡",
                        "id": 1009,
                        "idCard": "330102198903291218",
                        "isDefault": true,
                        "phone": "13588241996",
                        "zipCode": "000000"
                    }, {
                        "address": "余杭街道良睦路1288号，12幢3楼，买好车左门",
                        "areaCode1": 3314,
                        "areaCode2": 3315,
                        "areaFullname": "澳门特别行政区澳门半岛",
                        "areaId": 3315,
                        "consignee": "咔咔",
                        "id": 640,
                        "idCard": "330102198903291218",
                        "isDefault": false,
                        "phone": "13588241996",
                        "zipCode": "000000"
                    }, {
                        "address": "仓前街道良睦路1288号梦想小镇",
                        "areaCode1": 2240,
                        "areaCode2": 3324,
                        "areaCode3": 2247,
                        "areaFullname": "重庆市九龙坡区",
                        "areaId": 2247,
                        "consignee": "咔咔",
                        "id": 598,
                        "idCard": "330102198903291218",
                        "isDefault": false,
                        "phone": "13588241996",
                        "zipCode": "000000"
                    }];

                    $scope.receiverList.push({
                        "id": -1
                    });

                    $timeout(function () {
                        $.initDropdown();
                        areaSelect($select);
                    }, 100);
                }
            } else {
                new $.Alert('请输入有效的手机号码', 'error');
                $mobile.focus();
            }
        };

        //获取收货地址
        $scope.getReceiver = function (x) {
            $scope.addr = x;
            $timeout(function () {
                if (x.id == 0) {
                    $('[name="idCard"]').focus();
                    $scope.addr.phone = $mobile.val();
                } else if (x.id == -1) {
                    $scope.addr.areaCode1 = $scope.receiverList[0].areaCode1;
                    $scope.addr.areaCode2 = $scope.receiverList[0].areaCode2;
                    $scope.addr.areaCode3 = $scope.receiverList[0].areaCode3;
                    $('[name="address"]').focus();
                    $scope.addr.phone = $mobile.val();
                    console.log($scope.addr);
                }
                $timeout(function () {
                    areaSelect($select);
                },50);
            }, 100);
        };

        //下一步
        $scope.nextStep = function () {
            var resIdCard = $.Validate.checkformat('[name="idCard"]', 'idCard');
            if (!resIdCard.res) {
                new $.Alert(resIdCard.msg + '不正确', 'error');
                return;
            }
            var resPhone = $.Validate.checkformat('[name="phone"]', 'phone');
            if (!resPhone.res) {
                new $.Alert(resPhone.msg + '不正确', 'error');
                return;
            }

            var param = $scope.addr;
            param.userId = $scope.userId;
            param.memberId = $scope.memberId;
            param.mobile = $scope.mobile;
            param.receiverId = $('[name="receiverId"]').val();
            if (param.receiverId < 0) {
                delete param.receiverId;
                delete param.id;
            }
            param.areaCode1 = $('[name="areaCode1"]').val();
            param.areaCode2 = $('[name="areaCode2"]').val() || 0;
            param.areaCode3 = $('[name="areaCode3"]').val() || 0;
            $http({
                method: 'POST',
                url: '/store/order/submitMemberInfo',
                data: $.param(param),
                headers: $.headers
            }).success(function (response) {
                if (response.success) {
                    $orderInfo.data = response;
                    //$orderInfo.data.memberId = $scope.memberId;
                    $orderInfo.data.mobile = $scope.mobile;
                    $orderInfo.data.consignee = $scope.addr.consignee;
                    $orderInfo.data.areaFullname = $scope.addr.areaFullname;
                    $orderInfo.data.address = $scope.addr.address;
                    $orderInfo.data.idCard = $scope.addr.idCard;
                    $orderInfo.data.phone = $scope.addr.phone;
                    $location.path('/pos/submitOrder/' + $routeParams.userId);
                } else {
                    new $.Alert(response.data, 'error');
                    areaSelect($select);
                }
            });

            if ($.isTest) {
                $timeout(function () {
                    $orderInfo.data = {
                        "success": true,
                        "FreeAmount": 10,//优惠金额
                        //"couponDiscount":100,
                        "FreightAmount": 32,//运费
                        "receiverId": 0,//收货ID
                        "orderToken": "11dcf46a2fa192cf8501d01bf0a5295b",
                        "items": [{
                            "itemId": 5655,
                            "name": "贝亲pigeon Tall吸管瓶吸管水杯[粉色330ml]",
                            "barcode": 1111231331,
                            "price": 100,
                            "productId": 954,
                            "quantity": 1
                        }, {
                            "itemId": 34128,
                            "barcode": 4901301129069,
                            "name": "日本小林制药 防水液体创可贴[10g]",
                            "price": 39,
                            "productId": 1053,
                            "quantity": 2
                        }, {
                            "itemId": 34145,
                            "barcode": 4901301229069,
                            "name": "花王 蒸汽眼罩14片/盒无香型[无香型]",
                            "price": 59,
                            "productId": 399,
                            "stock": 100,
                            "quantity": 1
                        }]
                    };
                    $orderInfo.data.mobile = $scope.mobile;
                    $orderInfo.data.memberId = $scope.memberId;
                    $orderInfo.data.consignee = $scope.addr.consignee;
                    $orderInfo.data.areaFullname = $scope.addr.areaFullname;
                    $orderInfo.data.address = $scope.addr.address;
                    $orderInfo.data.idCard = $scope.addr.idCard;
                    $orderInfo.data.phone = $scope.addr.phone;
                    areaSelect($select);
                    $location.path('/pos/submitOrder/' + $routeParams.userId);
                }, 500);
            }
        }
    });

});