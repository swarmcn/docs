define(function (require, exports, module) {

    //提交订单
    $.myApp.controller('submitOrderCtrl', function ($scope, $http, $timeout, $location, $routeParams, $orderInfo) {
        $scope.nextBtn = '提交订单';
        $scope.step = 'submitOrder';

        //关闭页面提示
        window.onbeforeunload = function () {
            return "关闭页面，您输入的数据可能不会被保存？";
        };

        //解析加密后的店员ID
        $scope.userId = null;
        try {
            $scope.userId = parseInt($.base64.decode($routeParams.userId)) - $.timestamp_today;
            if ($scope.userId <= 0) {
                $location.path('/pos/shopCart');
                $location.replace();
            }
        }
        catch (ex) {
            $location.path('/pos/shopCart');
            $location.replace();
            return;
        }

        $scope.orderInfo = $orderInfo.data;
        if (!$orderInfo.data)
            $location.path('/pos/receiver/' + $routeParams.userId);

        //console.log( $orderInfo.data.mobile)
        //优惠券
        $scope.getVoucher = function () {
            var url = '/voucher/getVoucher.json';
            if ($.isTest)
                url = '/weixin/member/getVoucher.json';
            $http({
                method: 'get',
                url: url,
                params: ({
                    mobile: $orderInfo.data.mobile
                })
            }).success(function (response) {
                if (response.success) {
                    $scope.Voucher = response.data;
                    var voucherItems = $scope.Voucher;

                    var couponDiscount = 0.00;
                    for (var i = 0; i < voucherItems.length; i++) {
                        var item = voucherItems[i];
                        if ($scope.totalAmount - $scope.orderInfo.FreeAmount + $scope.orderInfo.FreightAmount >= item.minOrderAmount) {
                            couponDiscount = item.discountAmount;
                            $scope.couponDiscount = couponDiscount || 0;
                            $scope.orderInfo.couponDiscount = couponDiscount || 0;
                            $scope.couponName = item.name;

                            $timeout(function () {
                                $('.couponDiscount option').each(function () {
                                    if ($(this).text().length == 0)
                                        $(this).remove();
                                });
                            }, 100);
                            return;
                        }
                    }
                    $scope.couponDiscount = couponDiscount || 0;
                    $scope.orderInfo.couponDiscount = couponDiscount || 0;
                }
            });
        };

        //统计金额
        $scope.totalAmount = 0;
        $scope.products = [];
        if ($scope.orderInfo) {
            $.each($scope.orderInfo.items, function (n, x) {
                $scope.totalAmount += x.price * x.quantity;
                $scope.products.push({"itemId": x.itemId, "pid": x.productId, "quantity": x.quantity});
            });
            $scope.getVoucher();
        }

        //console.log($scope.orderInfo.memberId)
        //下一步
        $scope.nextStep = function () {

            if ($.isTest) {
                $orderInfo.data = [{
                    id: 123,
                    sn: "2015123456",
                    amount: $scope.totalAmount + $scope.orderInfo.FreightAmount - $scope.orderInfo.FreeAmount
                }, {
                    id: 444,
                    sn: "2015122234",
                    amount: $scope.totalAmount + $scope.orderInfo.FreightAmount - $scope.orderInfo.FreeAmount
                }, {
                    id: 446,
                    sn: "2015122236",
                    amount: $scope.totalAmount + $scope.orderInfo.FreightAmount - $scope.orderInfo.FreeAmount
                }];
            }

            if ($scope.orderInfo.couponDiscount == '0' || !$scope.orderInfo.couponDiscount)
                $scope.isUseVoucher = false;
            else
                $scope.isUseVoucher = true;



            var param = {
                memberId : $scope.orderInfo.memberId,
                receiverId: $scope.orderInfo.receiverId,
                products: JSON.stringify($scope.products).replace(/"/g, "'"),
                orderToken: $scope.orderInfo.orderToken,
                userId: $scope.userId,
                isUseVoucher: $scope.isUseVoucher,
                memo: $scope.memo
            };
            if (param.receiverId == 0) {
                param.mobile = $scope.orderInfo.mobile;
                param.memberId = $scope.orderInfo.memberId;
                param.consignee = $scope.orderInfo.consignee;
                param.phone = $scope.orderInfo.phone;
                param.idCard = $scope.orderInfo.idCard;
            }

            $http({
                method: 'POST',
                url: '/store/order/submitOrder',
                data: $.param(param),
                headers: $.headers
            }).success(function (response) {
                if (response.success) {

                    $orderInfo.data = response.data;

                    //console.log('submitOrder:');
                    //console.log($orderInfo.data);

                    $location.path('/pos/payment');
                    $location.replace();
                }
                else
                    new $.Alert(response.data, 'error');
            });

            if ($.isTest) {
                $location.path('/pos/payment');
                $location.replace();

            }
        }
    });

});