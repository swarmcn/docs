define(function (require, exports, module) {

    //录入商品
    var $cart_list = $('#cart_list');
    $.myApp.controller('shopCartCtrl', function ($scope, $http, $timeout, $location) {
        $scope.step = 'shopCart';
        var $keyword = $('#key-product');
        var $productId = $('[name="productId"]');

        //回车事件自动获取焦点
        document.onkeydown = function (event) {
            var e = event || window.event || arguments.callee.caller.arguments[0];
            if (e && e.keyCode == 13) {// enter 键
                $keyword.focus();
            }
        };

        //店员列表
        $http.get('/store/user/getList.json', {
            params: {
                enabled: true,
                pageNumber: 1,
                pageSize: 1000
            }
        }).success(function (response) {
            if (response.success) {
                $scope.userList = response.data;

                $timeout(function () {
                    $.initDropdown();
                }, 100);
            }
        });

        //获取满减信息
        $scope.getfullCutAmount = function (amount) {
            $scope.amount = 0.00;//合计
            $scope.subAmount = 0.00;//满减
            if ($scope.fullCut) {
                var fullCutItems = $scope.fullCut;
                if (fullCutItems.length > 0) {
                    $scope.amount = amount;
                    for (var i = 0; i < fullCutItems.length; i++) {
                        var item = fullCutItems[i];
                        if (amount >= item.fullAmount) {
                            $scope.subAmount = item.subtractAmount;
                            amount = amount - item.subtractAmount;
                            $scope.amount = amount;
                            return amount;
                        }
                    }
                }
                else {
                    $scope.amount = amount;
                    return amount;
                }
            } else {
                $scope.amount = amount;
                var url = '/promotion/getFullSubtract.json';
                if ($.isTest)
                    url = '/product/getFullSubtract.json';
                $http.get(url).success(function (response) {
                    if (response.success) {
                        $scope.fullCut = response.data;
                        var fullCutItems = $scope.fullCut;
                        if (fullCutItems.length > 0)
                            $scope.amount = amount;
                        for (var i = 0; i < fullCutItems.length; i++) {
                            var item = fullCutItems[i];
                            if (amount >= item.fullAmount) {
                                $scope.subAmount = item.subtractAmount;
                                amount = amount - item.subtractAmount;
                                $scope.amount = amount;
                                return amount;
                            }
                        }
                    }
                    else {
                        $scope.amount = amount;
                        return amount;
                    }
                });

            }
        };

        //绑定商品列表
        var url = '/store/cart/getList.json';
        if ($.isTest)
            url = '/store/pos/json/getCartList.json';
        $scope.cartList = [];
        $scope.totalQuantity = 0;
        $scope.totalAmount = 0;
        $http.get(url + '?ts=' + new Date().getTime()).success(function (response) {
            if (response.success) {
                $scope.cartList = response.data;
                $.each($scope.cartList, function (n, x) {
                    $scope.totalQuantity += x.quantity;
                    $scope.totalAmount += x.quantity * x.price;
                    x.quantity2 = x.quantity;//临时数量
                });
                $scope.getfullCutAmount($scope.totalAmount);
            }
        });

        //统计
        $scope.count = function () {
            $scope.totalQuantity = 0;
            $scope.totalAmount = 0;
            $.each($scope.cartList, function (n, x) {
                $scope.totalQuantity += x.quantity2;
                $scope.totalAmount += x.quantity2 * x.price;
                x.quantity = x.quantity2;//临时数量
            });
            $scope.getfullCutAmount($scope.totalAmount);
        };

        //修改
        $scope.edit = function (x, diff) {
            if(x.disabled) return;//屏蔽已锁定
            x.disabled = true;//锁定

            var reg = new RegExp("^[0-9]*$");
            if (!reg.test(x.quantity2))
                x.quantity2 = x.quantity;
            if (diff)//增减
                x.quantity2 += diff;
            if (x.quantity2 < 1)//不能小于1
                x.quantity2 = 1;
            if (x.quantity2 > x.stock)//不能大于库存
                x.quantity2 = x.stock;

            $http({
                method: 'POST',
                url: '/store/cart/edit',
                data: $.param({
                    itemId: x.itemId,
                    quantity: x.quantity2
                }),
                headers: $.headers
            }).success(function (response) {
                x.disabled = false;
                if (response.success) {
                    $scope.count();
                } else {
                    new $.Alert(response.data, 'error');
                    x.quantity2 = x.quantity;
                }
            });

            //前端测试数据
            if ($.isTest) {
                $timeout(function () {
                    x.disabled = false;
                    $scope.count();
                }, 1000);
            }
        };

        //扫描入购物车
        $scope.addCart = function () {
            var productId = $productId.val();
            var keyword = $keyword.val();
            var barcode = null;

            //1.纯数字+没id//2.非数字+有id
            var bool_a = !isNaN(parseInt(keyword)) && !productId;
            var bool_b = productId && isNaN(parseInt(keyword));
            if (bool_a || bool_b) {

                //条形码
                if (bool_a) {
                    barcode = keyword;
                    $keyword.autocomplete("destroy");
                }

                $http({
                    method: 'POST',
                    url: '/store/cart/add',
                    data: $.param({
                        productId: productId,
                        barcode: barcode
                    }),
                    headers: $.headers
                }).success(function (response) {
                    if (response.success) {
                        new $.Alert('录入成功', 'success', false, true, 1500);

                        var data = response.data;
                        data.quantity2 = data.quantity;

                        //处理列表
                        if (!$('#itemId' + data.itemId)[0])
                            $scope.cartList.push(data);//新增一条
                        else {
                            //修改原来一条
                            var index = -1;
                            $.each($scope.cartList, function (n, x) {
                                if (x.itemId == data.itemId)
                                    index = n;
                            });
                            $scope.cartList.splice(index, 1);
                            $scope.cartList.splice(index, 0, data);
                        }
                        $scope.count();

                        $timeout(function () {
                            $('.table td > span.flag_new').hide();
                            $('span.flag_new', '#itemId' + data.itemId).fadeIn(200);
                        }, 100);
                    }
                    else {
                        new $.Alert(response.data, 'error');
                    }
                    $productId.val('');
                    $keyword.val('').focus();
                });

                //前端测试数据
                if ($.isTest) {
                    $timeout(function () {
                        new $.Alert('录入成功', 'success', false, true, 1500);
                        var data = {
                            "itemId": 2,
                            "productId": 2,
                            "barcode": 123456,
                            "name": "贝亲pigeon Tall吸管瓶吸管水杯[粉色330ml]",
                            "price": 20,
                            "quantity": 10,
                            "stock": 999,
                            "isLowStock": false
                        };
                        data.quantity2 = data.quantity;

                        $cart_list.show();
                        if (!$('#itemId' + data.itemId)[0])
                            $scope.cartList.push(data);
                        else {
                            var index = -1;
                            $.each($scope.cartList, function (n, x) {
                                if (x.itemId == data.itemId)
                                    index = n;
                            });
                            $scope.cartList.splice(index, 1);
                            $scope.cartList.splice(index, 0, data);
                        }
                        $scope.count();


                        $timeout(function () {
                            var $itemId = $('#itemId' + data.itemId);
                            $('.table td > span.flag_new').hide();
                            $itemId.find('span.flag_new').fadeIn(200);
                        }, 100);

                        $productId.val('');
                        $keyword.val('').focus();
                    }, 500);
                }
            }
            else {
                $keyword.focus();
            }
        };

        //删除确认框
        $scope.showModalDel = function (index, x) {
            $scope.cart = null;
            if (x) {
                $scope.cart = {
                    index: index,
                    itemId: x.itemId,
                    barcode: x.barcode,
                    name: x.name,
                    title: '确定删除该商品？',
                    btn: '确定删除'
                }
            } else {
                $scope.cart = {
                    title: '确定清空商品列表？',
                    btn: '确定清空'
                }
            }
        };

        //删除//清空
        $scope.delete = function () {
            if ($scope.cart.itemId) {
                $http({
                    method: 'POST',
                    url: '/store/cart/delete',
                    data: $.param({
                        itemId: $scope.cart.itemId
                    }),
                    headers: $.headers
                }).success(function (response) {
                    if (response.success) {
                        $('#myModal').modal('hide');
                        new $.Alert(response.data, 'success');
                        $('#itemId' + $scope.cart.itemId).fadeOut(500);
                        $timeout(function () {
                            $scope.cartList.splice($scope.cart.index, 1);
                            $scope.count();
                        },500);
                    }
                    else
                        new $.Alert(response.data, 'error');
                });

                //前端测试数据
                if ($.isTest) {
                    $('#myModal').modal('hide');
                    new $.Alert('删除成功', 'success');
                    $('#itemId' + $scope.cart.itemId).fadeOut(1000);
                    $timeout(function () {
                        $scope.cartList.splice($scope.cart.index, 1);
                        $scope.count();
                    }, 1000);
                }
            }
            else {
                //清空
                $http({
                    method: 'POST',
                    url: '/store/cart/clear',
                    headers: $.headers
                }).success(function (response) {
                    if (response.success) {
                        $('#myModal').modal('hide');
                        new $.Alert(response.data, 'success');
                        $cart_list.fadeOut(500);
                        $timeout(function () {
                            $scope.cartList = [];
                            $cart_list.show();
                            $scope.count();
                            $keyword.focus();
                        },500);
                    }
                    else
                        new $.Alert(response.data, 'error');
                });

                //前端测试数据
                if ($.isTest) {
                    $('#myModal').modal('hide');
                    new $.Alert('清空成功', 'success');
                    $cart_list.fadeOut(1000);
                    $timeout(function () {
                        $scope.cartList = [];
                        $scope.count();
                        $keyword.focus();
                    }, 1000);
                }
            }
        };

        //下一步
        $scope.nextStep = function () {
            $scope.userId = $('[name="userId"]').val();
            if (!$scope.userId) {
                new $.Alert('请选择操作员！', 'warning');
                $.initDropdown();
                return;
            }

            if ($scope.amount > 1000) {
                new $.Alert('[ 海关规定 ]<br>过关订单单笔最高金额不能超过1000元！<br>否则将有扣留、退运风险！请拆单购买～', 'warning', false, true, 10000);
                return;
            }

            //店员ID64位加密
            var timestamp = $.timestamp_today + parseInt($scope.userId);
            $scope.userId = $.base64.encode(timestamp.toString());
            $location.path('/pos/receiver/' + $scope.userId);
        }
    });

});