define(function (require, exports, module) {
    var status = {
        "orderStatus":{
            "completed":"已完成",
            "cancelled":"已取消"
        },
        "paymentStatus":{
            "paid":"已支付",
            "unpaid":"未支付",
            "drawBack":"已申请退款",
            "partialRefunds":"部分退款",
            "refunded":"已退款"
        },
        "shippingStatus":{
            "shipped":"已发货",
            "received":"已收货",
            "applyReturn":"已申请退货",
            "partialReturns":"部分退货",
            "returned":"已退货"
        },
        "customsStatus":{
            "reported":"已报关",
            "success":"报关成功",
            "pass":"已通关",
            "fail":"报关失败"
        }
    };
    return status;
});
