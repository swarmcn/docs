define(function (require, exports, module) {

    seajs.use('store', function (ex) {
        require('pagination');
        var getQueryString = require('plugin/getQueryString');
        var status = require('store/js/order/status');
        var myApp = ex.myApp;

        myApp.controller('orderCtrl', function ($scope, $http, $timeout) {
            $scope.isManager = parseInt(ex.isShopManager);

            if($.isTest)
                $scope.isManager = 1;

            //店员列表
            $scope.getUser = function () {
                $http({
                    method: 'get',
                    url: '/store/user/getList.json'
                }).success(function (response) {
                    if (response.success) {
                        $scope.userList = response.data;
                    }
                })
            };
            $scope.getUser();

            $scope.userId = getQueryString('userId');
            $scope.method = getQueryString('method');
            //$scope.member = getQueryString('member');
            $scope.keyword = getQueryString('key');
            $scope.beginDate = getQueryString('bDate');
            $scope.endDate = getQueryString('eDate');

            $scope.orderStatus = getQueryString('orSta');
            $scope.paymentStatus = getQueryString('paySta');
            $scope.shippingStatus = getQueryString('shipSta');
            $scope.customsStatus = getQueryString('cuSta');
            $scope.hasExpired = getQueryString('hasExp');


            //搜索
            $scope.search = function(){
                $scope.userId = $('[name="userId"]').val();
                $scope.method = $('[name="method"]').val();
                $scope.keyword = $('[name="keyword"]').val();
                $scope.beginDate = $('[name="beginDate"]').val();
                $scope.endDate = $('[name="endDate"]').val();
                $scope.orderStatus = $('[name="orderStatus"]').val();
                $scope.paymentStatus = $('[name="paymentStatus"]').val();
                $scope.shippingStatus = $('[name="shippingStatus"]').val();
                $scope.customsStatus = $('[name="customsStatus"]').val();
                $scope.hasExpired = $('[name="hasExpired"]').val();
                location.href = '?'+'userId=' + $scope.userId + '&cuSta=' + $scope.customsStatus + '&shipSta=' + $scope.shippingStatus + '&paySta=' + $scope.paymentStatus + '&orSta=' + $scope.orderStatus + '&method=' + $scope.method + '&hasExp=' + $scope.hasExpired + '&key=' + $scope.keyword + '&bDate=' + $scope.beginDate + '&eDate=' + $scope.endDate;
            };

            //订单列表
            $scope.getList = function (pageNumber) {
                $scope.pageSize = 10;
                pageNumber = pageNumber || 1;
                $scope.page = pageNumber;
                var param = {
                    pageNumber: pageNumber || 1,
                    pageSize: $scope.pageSize,
                    stamp: new Date().getTime()
                };
                if($scope.userId)
                    param['userId'] = $scope.userId;
                if($scope.method)
                    param['method'] = $scope.method;
                if($scope.hasExpired)
                    param['hasExpired'] = $scope.hasExpired;
                if($scope.keyword)
                    param['keyword'] = $scope.keyword;
                if($scope.beginDate)
                    param['beginDate'] = $scope.beginDate;
                if($scope.endDate)
                    param['endDate'] = $scope.endDate;
                if($scope.orderStatus)
                    param['orderStatus'] = $scope.orderStatus;
                if($scope.paymentStatus)
                    param['paymentStatus'] = $scope.paymentStatus;
                if($scope.shippingStatus)
                    param['shippingStatus'] = $scope.shippingStatus;
                if($scope.customsStatus)
                    param['customsStatus'] = $scope.customsStatus;

                $http({
                    method: 'get',
                    url: '/store/order/getList.json',
                    params: (param)
                }).success(function (response) {
                    if (response.success) {
                        $scope.orderList = response.data;
                        $scope.totalCount = response.totalCount;
                        $scope.status = status;
                        $timeout(function () {
                            $('.pagination').pagination({
                                currentPage: pageNumber,
                                items: response.totalCount,
                                itemsOnPage: $scope.pageSize,
                                displayedPages: 3,
                                prevText: '上一页',
                                nextText: '下一页',
                                cssStyle: 'bootstrap-theme',
                                onPageClick: function (pageNumber) {
                                    $scope.getList(pageNumber);
                                }
                            });
                        }, 100);


                    }
                })
            };
            $scope.getList();
        })

    });

});