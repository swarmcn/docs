define(function (require, exports, module) {
    seajs.use('store', function (ex) {
        var status = require('store/js/order/status');
        var getQueryString = require('plugin/getQueryString');
        var myApp = ex.myApp;

        myApp.factory('$order', function () {
            return {};
        });

        myApp.config(function ($routeProvider) {
            $routeProvider
                .when('/info', {
                    controller: 'detailCtrl',
                    publicAccess: true,
                    templateUrl: 'detail/info.html'
                })
                .when('/items', {
                    controller: 'itemsCtrl',
                    templateUrl: 'detail/items.html',
                    publicAccess: true
                })
                .when('/paymentInfo', {
                    controller: 'paymentInfoCtrl',
                    templateUrl: 'detail/paymentInfo.html',
                    publicAccess: true
                })
                .when('/shippingInfo', {
                    controller: 'shippingInfoCtrl',
                    templateUrl: 'detail/shippingInfo.html',
                    publicAccess: true
                })
                .otherwise({
                    redirectTo: '/info'
                });
        });

        myApp.controller('orderCtrl', function ($scope, $timeout, $location) {
            $scope.go = function (path) {
                $location.path(path);
            }
        });

        //订单信息
        myApp.controller('detailCtrl', function ($scope, $http, $timeout, $order) {
            $scope.id = getQueryString('id');
            $http({
                method: 'get',
                url: '/store/order/getDetail.json',
                params: {
                    id: $scope.id
                },
                headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
            }).success(function (response) {
                if (response.success) {
                    $scope.order = $order.data = response.data;
                    $scope.status = status;
                }
            });
        });

        //商品信息
        myApp.controller('itemsCtrl', function ($scope, $timeout, $location, $order) {
            if (!$order.data)
                $location.path('/info');
            else
                $scope.items = $order.data.items;
        });

        //支付信息
        myApp.controller('paymentInfoCtrl', function ($scope, $timeout, $location, $order) {
            if (!$order.data)
                $location.path('/info');
            else
                $scope.paymentInfo = $order.data.paymentInfo;
        });

        //物流信息
        myApp.controller('shippingInfoCtrl', function ($scope, $timeout, $location, $order) {
            if (!$order.data)
                $location.path('/info');
            else
                $scope.shippingInfo = $order.data.shippingInfo;
        });
    })
})
