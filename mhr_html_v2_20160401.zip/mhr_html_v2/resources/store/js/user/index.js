define(function (require, exports, module) {
    seajs.use('store', function (ex) {
        require('token');//令牌，POST时必须调用
        require('pagination');
        var Alert = require('plugin/alert');
        var myApp = ex.myApp;

        //修改密码
        myApp.controller('changePwdCtrl', function ($scope, $http, $timeout) {
            $scope.changePwd = function () {
                if (!$scope.currentPassword) {
                    new Alert('请输入当前密码！', 'warning');
                    return;
                }
                if (!$scope.password) {
                    new Alert('请输入要修改的密码！', 'warning');
                    return;
                }
                if (!$scope.rePassword) {
                    new Alert('请再次输入修改的密码！', 'warning');
                    return;
                }
                if ($scope.password != $scope.rePassword) {
                    new Alert('两次密码不相同！', 'warning');
                    return;
                }
                $http({
                    method: 'POST',
                    url: '/store/password/update',
                    data: $.param({
                        currentPassword: $scope.currentPassword,
                        password: $scope.password,
                        rePassword: $scope.rePassword
                    }),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
                }).success(function (response) {
                    if (response.success) {
                        $scope.currentPassword = null;
                        $scope.password = null;
                        $scope.rePassword = null;
                        new Alert(response.data, 'success');
                    }
                    else
                        new Alert(response.data, 'danger');
                })
            }

        });

        myApp.controller('userCtrl', function ($scope, $http, $timeout) {
            $scope.isShopManagers = parseInt(ex.isShopManager);

            if($.isTest)
                $scope.isShopManagers = 1;

            //初始化分页
            $scope.pageSize = 10;
            $scope.getList = function (pageNumber) {
                $scope.page = pageNumber || 1;
                var param = {
                    pageNumber: pageNumber || 1,
                    pageSize: $scope.pageSize,
                    stamp: new Date().getTime()
                };
                $scope.enabled = $('[name="enabled"]').val();
                if(!$scope.isShopManager)
                    $scope.enabled = true;
                if ($scope.enabled) {
                    param['enabled'] = $scope.enabled;
                }
                if ($scope.username) {
                    param['username'] = $scope.username;
                }
                if ($scope.mobile) {
                    param['mobile'] = $scope.mobile;
                }

                $scope.pageSize = 10;
                $http({
                    method: 'get',
                    url: '/store/user/getList.json',
                    params: (param)
                }).success(function (response) {
                    if (response.success) {
                        $scope.userList = response.data;
                        $scope.totalCount = response.totalCount;
                        $timeout(function () {
                            $('.pagination').pagination({
                                currentPage: pageNumber,
                                items: response.totalCount,
                                itemsOnPage: $scope.pageSize,
                                displayedPages: 3,
                                prevText: '上一页',
                                nextText: '下一页',
                                cssStyle: 'bootstrap-theme',
                                onPageClick: function (pageNumber) {
                                    $scope.getList(pageNumber);
                                }
                            });
                            $.initDropdown();
                        }, 100);
                    }
                })

            };
            $scope.getList();


            //激活和锁定店员
            $scope.toggle = function (x) {
                $http({
                    method: 'POST',
                    url: '/store/user/toggle',
                    data: $.param({
                        id: x.id,
                        enabled: !x.enabled
                    }),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
                }).success(function (response) {
                    if (response.success) {
                        x.enabled = !x.enabled;
                        new Alert(response.data, 'success');
                    }
                    else
                        new Alert(response.data, 'danger');
                })

                if($.isTest)
                    x.enabled = !x.enabled;
            };

            //添加和编辑店员弹窗
            $scope.showShopModal = function (x, index) {
                $('.form-group').removeClass('has-error');
                if (x) {
                    $scope.user = jQuery.extend(true, {}, x);
                    $scope.user.index = index;
                }
                else {
                    $scope.user = {};
                }
                if ($scope.user.id)
                    $scope.disabled = true;
                else {
                    $scope.disabled = false;
                    $scope.user.enabled = true;
                }
            };

            //新增、修改店员
            $scope.updUsers = function () {
                if (!$scope.user.username) {
                    new Alert('请输入姓名！', 'warning');
                    return;
                }
                if (!$scope.user.mobile) {
                    new Alert('请输入手机号！', 'warning');
                    return;
                }
                if (!$scope.user.rePassword && $scope.user.password) {
                    new Alert('请再次输入密码！', 'warning');
                    return;
                }
                if ($scope.user.password != $scope.user.rePassword) {
                    new Alert('两次密码不相同请重新输入！', 'warning');
                    return;
                }

                var param = {
                    username: $scope.user.username,
                    mobile: $scope.user.mobile,
                    password: $scope.user.password,
                    rePassword: $scope.user.rePassword,
                    enabled: $scope.user.enabled
                };

                if ($scope.user.id) {
                    param['id'] = $scope.user.id;
                    param['enabled'] = $scope.user.enabled;
                }
                else {
                    param['enabled'] = true;
                }

                $http({
                    method: 'POST',
                    url: '/store/user/' + ($scope.user.id ? 'update' : 'add'),
                    data: $.param(param),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
                }).success(function (response) {
                    if (response.success) {
                        if ($scope.user.id) {//编辑
                            $scope.userList.splice($scope.user.index, 1);
                            $scope.userList.splice($scope.user.index, 0, $scope.user);
                        } else {//新增
                            $scope.getList();
                        }
                        $('#myModalShopUsers').modal('hide');
                    } else
                        new Alert(response.data, 'danger');
                })

            }
        })
    });

});