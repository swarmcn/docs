define(function (require, exports, module) {
    require('angularJs');
    require('angularRoute');
    require('jquery');
    require('bootstrap');
    require('placeholder');
    require('token');//令牌，POST时必须调用
    require('cookie');
    require('plugin/message');

    var circle = require('plugin/circle');
    var setUrlParam = require('plugin/setUrlParam');
    var getQueryString = require('plugin/getQueryString');
    var $delegate = require('plugin/delegateEvent');
    var Modal = require('plugin/modal');

    // 对Date的扩展，将 Date 转化为指定格式的String
    Date.prototype.Format = function (fmt) {
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    };

    //点击其他区域关闭popover
    $(document).click(function () {
        $('[data-toggle="popover"]').popover('hide')
    });
    $(document).delegate('[data-toggle="popover"],.popover', 'click', function (event) {
        event.stopPropagation();//排除popover
    });

    $.isTest = (location.hostname == 'localhost' || location.hostname.indexOf('192.168.2') > -1 || location.hostname.indexOf('172.') > -1);

    //表单序列化为JSON
    $.fn.serializeObject = function () {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };

    ////检测登录
    //$.checkAdminLogin = function () {
    //    var result = false;
    //    $.ajax({
    //        url: "/store/auth/check",
    //        type: "GET",
    //        dataType: "json",
    //        data: {pathname: location.pathname},
    //        cache: false,
    //        async: false,
    //        success: function (data) {
    //            result = data;
    //        }
    //    });
    //    return result;
    //};
    //if (!$.checkAdminLogin() && !$.isTest) {
    //    location.href = '/store/login.html?redirectUrl=' + encodeURIComponent(location.href);
    //}

    //下拉框划过显示//noHover将不生效
    $delegate('.container-fluid .dropdown,.modal-body .dropdown', {
        'mouseenter': function () {
            if (!$(this).hasClass('noHover')) {
                $(this).addClass('open');
                $('.btn', this).removeClass('active');
                if (!$('li.dropdown-header .fa', this)[0]) {
                    $('li.dropdown-header', this).append(' <i class="fa fa-paperclip fa-flip-horizontal"></i>')
                }
            }
        },
        'mouseleave': function () {
            if (!$(this).hasClass('noHover')) {
                $(this).removeClass('open');
                $(this).children('[data-toggle="dropdown"]').blur();
            }
        }
    });

    //初始化下拉菜单
    function initDropdown() {
        //模拟Select
        $('.dropdown-menu a[data]').each(function () {
            var el = $(this);
            var data = el.attr('data');
            var group = el.parent().attr('group');
            var pt = el.parents('.dropdown');

            var hidden = $('input:hidden', pt);
            if (group)
                hidden = $('input:hidden[name="' + group + '"]', pt);
            //var name = hidden.attr('name');

            var btn = $('[data-toggle="dropdown"]', pt);
            if (data.length > 0 && hidden.val() == data) {
                if (group) {
                    $('.dropdown-menu li[group="' + group + '"]', pt).removeClass('active');
                    el.parent().addClass('active');
                } else {
                    btn.html('<span>' + el.text() + '</span><span class="caret"></span>');
                    $('.dropdown-menu li', pt).removeClass('active');
                    el.parent().addClass('active');
                }
            }

            el.click(function () {
                //赋值
                hidden.val(data);
                if (group) {
                    if (el.parent().hasClass('active'))
                        hidden.val('');
                    $('.dropdown-menu li[group="' + group + '"]', pt).removeClass('active');
                    if (hidden.val().length > 0)
                        el.parent().addClass('active');
                } else {
                    //高亮
                    btn.html('<span>' + el.text() + '</span><span class="caret"></span>');
                    $('.dropdown-menu li', pt).removeClass('active');
                    el.parent().addClass('active')
                }
            });
        });
    }

    $.initDropdown = function () {
        initDropdown();
    };

    //myApp
    var myApp = angular.module("myApp", ['ngRoute']);

    //$httpProvider注册拦截器
    myApp.factory('Interceptor', function ($q) {
        var interceptor = {
            'request': function (config) {
                //console.log('request'+JSON.stringify(config));
                return config;
            },
            'response': function (response) {
                //console.log('response'+JSON.stringify(response))
                return response;
            },
            'requestError': function (rejection) {
                //console.log('requestError'+JSON.stringify(rejection))
                return $q.reject(rejection);
            },
            'responseError': function (rejection) {
                if (rejection.statusText == 'Forbidden') {
                    if(!$('#LoginTimeout')[0]) {
                        var LoginTimeout = new Modal('body', {
                            id: 'LoginTimeout',
                            width: 300,
                            marginTop: $(window).height() / 2 - 150,
                            title: '<i class="fa fa-warning"></i>警告',
                            body: '<div class="text-center" style="margin-top: 3px; line-height: 26px; font-size: 16px;">T_T啊哦~ 登录超时了！</div>' +
                            '<div class="text-muted text-center"><span class="time">5</span>秒后将自动关闭</div>',
                            haClose: true
                        });
                        LoginTimeout.find('.modal-footer').css('text-align', 'center');
                        LoginTimeout.find('.modal-footer .btn-default').remove();
                        LoginTimeout.modal('show');
                        LoginTimeout.on('hidden.bs.modal', function () {
                            location.replace('/store/login.html?redirectUrl=' + encodeURIComponent(location.href));
                        });
                        circle({
                            'fn': function (a) {
                                LoginTimeout.find('.time').text(a.times);
                            },
                            'afterfn': function () {
                                LoginTimeout.modal('hide');
                            },
                            'mg': 1000,
                            'times': 5
                        });
                    }
                }
                return rejection
            }
        };
        return interceptor;
    });

    //ajax请求全局配置
    myApp.config(['$httpProvider', function ($httpProvider) {
        if(!$.isTest) $httpProvider.interceptors.push('Interceptor');
        $httpProvider.defaults.headers.common['token'] = $.cookie('token') || 0;
        $httpProvider.defaults.headers.common['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
        $httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
    }]);

    //输出的html
    myApp.filter(
        //格式化html标签
        'to_trusted', ['$sce', function ($sce) {
            return function (text) {
                return $sce.trustAsHtml(text);
            }
        }]
    );
    myApp.filter(
        //加星，如13******88
        'to_asterisk', ['$sce', function () {
            return function (text, param1, param2, param3) {
                var len = text.length;
                param1 = param1 || 2;//头部保留数
                param2 = param2 || 2;//尾部保留数
                param3 = param3 || 6;//星号个数
                if (len > param1 + param2) {
                    var s = text.substring(0, param1);
                    var e = text.substring(len - param2, len);
                    var n = '';
                    for (var i = 0; i < Math.min(len - param1 - param2, param3); i++)
                        n += '*';
                    return s + n + e;
                }
                return text;
            }
        }]
    );

    myApp.filter(
        //截取字串加...//substring:0:10
        'substring', ['$sce', function () {
            return function (text, param1, param2) {
                param1 = param1 || 0;
                param2 = param2 || text.length;
                if (text.length > param2) {
                    return text.substring(param1, param2) + '...';
                }
                return text;
            }
        }]
    );

    var storeShopName = $.cookie('storeShopName') || '测试门店';//店铺名称
    var storeUserName = $.cookie('storeUserName') || '测试店';//登录名称
    var isShopManager = $.cookie('storeShopManager') || true;//是否店长
    var storeUserHead = $.cookie('storeUserHead') || '/resources/images/store/username.png';//店员头像
    myApp.controller("StoreCtrl", function ($http, $scope, $timeout, $interval) {
        var nowDate = new Date();
        $scope.timestamp = nowDate.Format('S');

        //门店信息
        $scope.storeShopName = storeShopName;
        $scope.storeUserName = storeUserName;
        $scope.isShopManager = isShopManager;
        $scope.storeUserHead = storeUserHead;

        //时钟
        $scope.time = nowDate.Format('hh:mm:ss');
        $interval(function () {
            $scope.time = new Date().Format('hh:mm:ss');
        }, 1000);
        $scope.day = nowDate.Format('yyyy/MM/dd');
        $scope.week = '星期';
        var week = nowDate.getDay();
        switch (week) {
            case 0 :
                $scope.week += "日";
                break;
            case 1 :
                $scope.week += "一";
                break;
            case 2 :
                $scope.week += "二";
                break;
            case 3 :
                $scope.week += "三";
                break;
            case 4 :
                $scope.week += "四";
                break;
            case 5 :
                $scope.week += "五";
                break;
            case 6 :
                $scope.week += "六";
                break;
        }

        $timeout(function () {
            initDropdown();
        }, 200);
    });

    //模块输出
    module.exports = {
        myApp: myApp,
        storeShopName: storeShopName,
        storeUserName: storeUserName,
        isShopManager: isShopManager
    };
});