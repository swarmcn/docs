define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('bootstrap');
    require('placeholder');
    require('cookie');
    require('token');//令牌，POST时必须调用
    require('validate');
    var Validate = require('plugin/validate.el');

    var Alert = require('plugin/alert');
    //var Guid = require('plugin/guid');
    var getQueryString = require('plugin/getQueryString');
    var setUrlParam = require('plugin/setUrlParam');
    var redirectUrl = decodeURIComponent(getQueryString('redirectUrl', null, true));
    var isTest = (location.hostname == 'localhost' || location.hostname.indexOf('192.168.2') > -1 || location.hostname.indexOf('172.') > -1);
    //表单验证
    //var captchaId = Guid();//验证码标识
    //var $captchaImage = $("#captchaImage");
    var $submit = $(":submit");

    //设置验证
    function getCaptcha(callback) {
        if(!$('#slideValidate').hasClass('open')) {
            $.getScript('//api.geetest.com/get.php?callback=startCaptcha', function () {
                window.startCaptcha = function () {
                    var url = '/common/startCaptcha';
                    if (isTest)
                        url = '/demo/startCaptchaServlet.json';
                    $.get(url, function (response) {
                        if (response.success) {
                            var data = {
                                gt: response.gt,
                                challenge: response.challenge,
                                product: "popup"
                            };
                            if (isTest)
                                delete data.challenge;
                            window.gt_captcha_obj = new window.Geetest(data)
                                .appendTo("#slideValidate").bindOn('#btn-login')
                                .onSuccess(function () {
                                    var validate = gt_captcha_obj.getValidate();
                                    if (typeof callback == 'function') {
                                        callback.call(this, validate);
                                    }
                                });
                                //.onRefresh(function () {
                                //    //$('#btn-login').data('geetest', false);
                                //});

                            $('#slideValidate').addClass('open');
                            var autoClick = setInterval(function () {
                                if($('#origin_btn-login').length == 0){
                                    setTimeout(function () {
                                        $('#btn-login').click();
                                    },100);
                                }else
                                    clearInterval(autoClick);
                            },10);
                        }
                    }, 'json');
                };
            });
        }
    }

    ////更换验证码
    //$captchaImage.click(function () {
    //    $(this).show().attr("src", "/common/captcha?captchaId=" + captchaId + "&timestamp=" + new Date().getTime());
    //}).click();//初始化

    //var storeId = $('[name="storeId"]');
    //$('.dropdown').data({'toggle': 'popover', 'placement': 'bottom', 'content': '请选择门店'});
    var userName = $('[name="userName"]').data({
        'toggle': 'popover',
        'placement': 'bottom',
        'content': '请输入手机号码'
    }).focus();
    var password = $('[name="password"]').data({'toggle': 'popover', 'placement': 'bottom', 'content': '请输入密码'});
    var captcha = $("#captcha").data({'toggle': 'popover', 'placement': 'bottom', 'content': '请输入验证码'});


    //初始化下拉菜单
    function initDropdown() {
        //模拟Select
        $('.dropdown-menu a[data]').each(function () {
            var el = $(this);
            var data = el.attr('data');
            var pt = el.parents('.dropdown');

            var hidden = $('input:hidden', pt);
            //var name = hidden.attr('name');

            var btn = $('[data-toggle="dropdown"]', pt);
            if (data.length > 0 && hidden.val() == data) {
                btn.html(el.text() + '&nbsp;<span class="caret pull-right"></span>');
                $('.dropdown-menu li', pt).removeClass('active');
                el.parent().addClass('active');
            }

            el.click(function () {
                //赋值
                hidden.val(data);
                //高亮
                btn.html(el.text() + '&nbsp;<span class="caret pull-right"></span>');
                $('.dropdown-menu li', pt).removeClass('active');
                el.parent().addClass('active')
            });
        });
    }

    //myApp
    var myApp = angular.module("myApp", []);

    myApp.controller("StoreCtrl", function ($http, $scope, $timeout) {

        //var url = '/storeshop/getlist.json';
        //if (location.hostname == 'localhost')
        //    url = '/admin/store/getList.json';
        //$http.get(url).success(function (response) {
        //    if (response.success) {
        //        $scope.storeList = response.data;
        //        $timeout(function () {
        //            storeId.val($.cookie('storeShopId'));
        //            initDropdown();
        //        }, 100)
        //    }
        //})

    });

    //登录
    $('#btn-login').click(function () {
        var el = $(this);

        //门店为空
        //if (storeId.val() == "") {
        //    showError($('.dropdown'));
        //    return;
        //}

        //用户名为空
        if (userName.val() == "") {
            userName.data('content','请输入手机号码');
            showError(userName);
            return;
        }

        var resPhone = Validate.checkformat(userName, 'phone');
        if (userName.val().length != 11 || !resPhone.res) {
            userName.data('content','手机号格式不正确');
            showError(userName);
            return;
        }

        //密码为空
        if (password.val() == "") {
            showError(password);
            return;
        }

        ////验证码为空
        //if (captcha.val() == "") {
        //    showError(captcha);
        //    return;
        //}


        //获取公钥
        var url = '/common/public_key';
        if (location.hostname == 'localhost')
            url = '/debug/public_key.json';
        getCaptcha(function (validate) {
            $.ajax({
                url: url,
                type: "GET",
                dataType: "json",
                cache: false,
                success: function (data) {
                    //调用加密
                    seajs.use("plugin/encrypt/secret", function () {
                            var rsaKey = new RSAKey();
                            rsaKey.setPublic(b64tohex(data.modulus), b64tohex(data.exponent));
                            var enPassword = hex2b64(rsaKey.encrypt(password.val()));

                            //提交表单
                            $.post('/store/login', {
                                mobile: userName.val(),
                                enPassword: enPassword,
                                geetest_challenge: validate.geetest_challenge,
                                geetest_validate: validate.geetest_validate,
                                geetest_seccode: validate.geetest_seccode
                            }, function (response) {
                                if (response.success) {
                                    var cookieOptions = {expires: 7, path: '/'};
                                    $.cookie('storeShopId', response.data.storeId, cookieOptions);//店铺Id
                                    $.cookie('storeShopName', response.data.storeName, cookieOptions);//店铺名称
                                    $.cookie('storeUserId', response.data.userId, cookieOptions);//登录名称
                                    $.cookie('storeUserName', response.data.username, cookieOptions);//登录名称
                                    $.cookie('storeUserHead', response.data.headimgurl, cookieOptions);//店员微信头像
                                    $.cookie('storeShopManager', response.data.isManager || response.data.isManager == 'true' ? 1 : 0, cookieOptions);//是否店长
                                    setTimeout(function () {
                                        if (redirectUrl)
                                            location.href = redirectUrl;
                                        else
                                            location.href = "/store/index.html";
                                    },500);
                                } else {
                                    //captcha.val("");
                                    //$captchaImage.click();
                                    //$submit.prop("disabled", false);
                                    //$submit.text('登录');
                                    window.gt_captcha_obj.refresh();
                                    new Alert(response.data, 'error', '.container');
                                }
                            }, 'json').error(function (err) {
                                var msg = err.status || err;
                                window.gt_captcha_obj.refresh();
                                new Alert(msg, 'error', '.container');
                                //$submit.prop("disabled", false);
                                //$submit.text('登录');
                            });
                        }
                    );
                }
            });
        })

    });

    //回车登录
    $("#password,[name='remember']").bind("keydown", function (e) {
        // 兼容FF和IE和Opera
        var theEvent = e || window.event;
        var code = theEvent.keyCode || theEvent.which || theEvent.charCode;
        if (code == 13) {
            //回车执行查询
            $("#btn-login").click();
        }
    });

    //显示报错
    function showError(el, msg) {
        if (msg) {
            var text = el.text();
            el.text(el.data('loading'));
            el.addClass('disabled').data('content', msg);
            setTimeout(function () {
                el.popover('destroy').removeClass('disabled');
            }, 2000);
        }
        el.addClass('input-danger')
            .focus()
            .popover('show')
            .bind('keyup click', function () {
                $(this).popover('destroy');
            });
    }

    //回车登录
    $('[name="userName"],[name="password"]').keyup(function (e) {
        if (e.keyCode == '13' && password.val().trim() != "") {
            $('#btn-sign').click();
        }
    })

});