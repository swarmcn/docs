define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('bootstrap');
    require('placeholder');
    require('token');//令牌，POST时必须调用
    require('cookie');
    require('plugin/message');

    var setUrlParam = require('plugin/setUrlParam');
    var getQueryString = require('plugin/getQueryString');
    var $delegate = require('plugin/delegateEvent');
    var timestamp = new Date().getTime();

    //点击其他区域关闭popover
    $(document).click(function () {
        $('[data-toggle="popover"]').popover('hide')
    });
    $(document).delegate('[data-toggle="popover"],.popover', 'click', function (event) {
        event.stopPropagation();//排除popover
    });

    $.headers = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'};
    $.isTest = (location.hostname == 'localhost' || location.hostname.indexOf('192.168.2') > -1 || location.hostname.indexOf('172.') > -1);

    //根据哈希自动切换旧版页面，先清空内容
    if (location.hash.indexOf('#/admin/') > -1) {
        $('.container-fluid > .navbar-fixed-bottom').remove();
        $('.container-fluid > .main').empty();
    }

    // 对Date的扩展，将 Date 转化为指定格式的String
    Date.prototype.Format = function (fmt) {
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    };

    //模擬iphone的微信頁面
    $delegate('.navbar-nav .weixin', {
        'mouseenter': function () {
            var wx = '<div class="modal fade" id="myModalWeixin" tabindex="-1" role="dialog" aria-labelledby="myModalWeixinLabel" aria-hidden="true">' +
                '<div class="modal-dialog" style="width:400px"><div class="modal-content" style="background:0 0;border:none;box-shadow:none">' +
                '<iframe src="/resources/plugin/iphone/index.html" frameborder="0" width="430" height="805" scrolling="no"></iframe></div></div></div>';
            if (!$('#myModalWeixin')[0])
                $('body').append(wx);
        }
    });

    //表单序列化为JSON
    $.fn.serializeObject = function () {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };

    //检测登录
    $.checkAdminLogin = function () {
        var result = false;
        $.ajax({
            url: "/admin/auth/check",
            type: "GET",
            dataType: "json",
            data: {pathname: location.pathname},
            cache: false,
            async: false,
            success: function (data) {
                result = data;
            }
        });
        return result;
    };
    if (!$.checkAdminLogin() && location.hostname != 'localhost') {
        location.href = '/admin/login.html?redirectUrl=' + encodeURIComponent(location.href);
    }

    //下拉框划过显示
    $delegate('.container-fluid .dropdown,.modal-body .dropdown', {
        'mouseenter': function () {
            $(this).addClass('open');
            $('.btn', this).removeClass('active');
            if (!$('li.dropdown-header .fa', this)[0]) {
                $('li.dropdown-header', this).append(' <i class="fa fa-paperclip fa-flip-horizontal"></i>')
            }
        },
        'mouseleave': function () {
            $(this).removeClass('open');
            $(this).children('[data-toggle="dropdown"]').blur();
        }
    });

    //初始化下拉菜单
    function initDropdown() {
        //模拟Select
        $('.dropdown-menu a[data]').each(function () {
            var el = $(this);
            var data = el.attr('data');
            var pt = el.parents('.dropdown');

            var hidden = $('input:hidden', pt);
            //var name = hidden.attr('name');

            var btn = $('[data-toggle="dropdown"]', pt);
            if (data.length > 0 && hidden.val() == data) {
                btn.html(el.text() + '&nbsp;<span class="caret"></span>');
                $('.dropdown-menu li', pt).removeClass('active');
                el.parent().addClass('active');
            }

            el.click(function () {
                //赋值
                hidden.val(data);
                //高亮
                btn.html(el.text() + '&nbsp;<span class="caret"></span>');
                $('.dropdown-menu li', pt).removeClass('active');
                el.parent().addClass('active')
            });
        });
    }

    $.initDropdown = function () {
        initDropdown();
    };

    //myApp
    var myApp = angular.module("myApp", []);

    //ajax请求全局配置
    myApp.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.defaults.headers.common['token'] = $.cookie('token') || 0;
        $httpProvider.defaults.headers.common['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
        $httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
    }]);

    //输出的html
    myApp.filter(
        //格式化html标签
        'to_trusted', ['$sce', function ($sce) {
            return function (text) {
                return $sce.trustAsHtml(text);
            }
        }]
    );
    myApp.filter(
        //加星，如13******88
        'to_asterisk', ['$sce', function () {
            return function (text, param1, param2, param3) {
                var len = text.length;
                param1 = param1 || 2;//头部保留数
                param2 = param2 || 2;//尾部保留数
                param3 = param3 || 6;//星号个数
                if (len > param1 + param2) {
                    var s = text.substring(0, param1);
                    var e = text.substring(len - param2, len);
                    var n = '';
                    for (var i = 0; i < Math.min(len - param1 - param2, param3); i++)
                        n += '*';
                    return s + n + e;
                }
                return text;
            }
        }]
    );

    myApp.filter(
        //截取字串加...//substring:0:10
        'substring', ['$sce', function () {
            return function (text, param1, param2) {
                param1 = param1 || 0;
                param2 = param2 || text.length;
                if (text.length > param2) {
                    return text.substring(param1, param2) + '...';
                }
                return text;
            }
        }]
    );

    myApp.controller("adminCtrl", function ($http, $scope, $timeout, $interval) {
        $scope.timestamp = new Date().getTime();
        var nowDate = new Date();

        //时钟
        $scope.time = nowDate.Format('hh:mm:ss');
        $interval(function () {
            $scope.time = new Date().Format('hh:mm:ss');
        }, 1000);
        $scope.day = nowDate.Format('yyyy/MM/dd');
        $scope.week = '星期';
        var week = nowDate.getDay();
        switch (week) {
            case 0 :
                $scope.week += "日";
                break;
            case 1 :
                $scope.week += "一";
                break;
            case 2 :
                $scope.week += "二";
                break;
            case 3 :
                $scope.week += "三";
                break;
            case 4 :
                $scope.week += "四";
                break;
            case 5 :
                $scope.week += "五";
                break;
            case 6 :
                $scope.week += "六";
                break;
        }

        $scope.sidebarList = [];
        $scope.adminUserName = $.cookie('adminUserName') || $.cookie('adminRememberMe') || '管理员';

        //跳转iframe
        $scope.jump = function (event, isOld) {
            var $sidebar = $('#sidebar');
            var $iframe = $('#iframe');
            //if (isOld) {
            var el = $(event.target || event);
            if (el.parents('#sidebar')[0]) {
                $('li', $sidebar).removeClass('active');
                $('a span.fa-rocket', $sidebar).remove();

                el.parent().addClass('active');//高亮
                el.parents('ul').eq(0).addClass('in').prev().removeClass('collapsed');//展开
                el.append('<span class="pull-right fa fa-rocket fa-md"></span>');//加星
                location.hash = '#' + setUrlParam(el.attr('href').replace('/admin', '').replace('.html', '/') || '', 'ts', '').replace('?ts=', '').replace('&ts=', '');
            }
            if ($iframe[0])
                $iframe.show();
            else {
                var winHeight = $(window).height();
                $('.container-fluid > .main').html('<iframe id="iframe" name="iframe" frameborder="0" src="/admin/common/index" style="width: 100%; height: 100%;"></iframe>')
            }
            document.title = el.text() + ' - 美日惠运营后台';
            //}
        };

        if ($('.container-fluid')[0]) {
            var url = '/admin/common/getSidebar.json';
            if ($.isTest)
                url = '/admin/system/menu/getSidebar.json';
            $http.get(url + '?stamp=' + new Date().getTime()).success(function (response) {
                if (response.success) {
                    $scope.sidebarList = response.data;

                    $timeout(function () {
                        //根据哈希自动切换旧版页面
                        if (location.hash.indexOf('#/') > -1) {
                            var winHeight = $(window).height();
                            var hash = location.hash;
                            var lastWord = hash.substr(hash.length - 1, 1);
                            if (lastWord == '/')
                                hash = hash.substr(0, hash.length - 1) + '.html';
                            if ($('#sidebar a[href="/admin' + hash.replace('#', '') + '"]')[0]) {
                                $('.container-fluid > .main').html('<iframe id="iframe" name="iframe" frameborder="0" src="' + setUrlParam('/admin' + hash.replace('#', ''), 'ts', new Date().getTime()) + '" style="width: 100%; height: 100%;"></iframe>');
                                $scope.jump('#sidebar a[href="/admin' + hash.replace('#', '') + '"]', true);
                            }
                            else
                                $('#iframe')[0].src = '/admin/common/index';
                        } else {
                            $('#iframe')[0].src = '/admin/common/index';
                        }
                    }, 100);
                }
            });
        }

        $timeout(function () {
            initDropdown();
        }, 200);
    });

    //模块输出
    module.exports = {
        myApp: myApp,
        fn: function () {
        }
    };
});