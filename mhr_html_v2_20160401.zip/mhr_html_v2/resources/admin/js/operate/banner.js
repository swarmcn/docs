define(function (require, exports, module) {

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        //require('angularJs');
        //require('jquery');
        require('plugin/lightbox/js/lightbox.min');
        require('plugin/jquery-ui/jquery-ui.css');

        var getQueryString = require('plugin/getQueryString');
        var Alert = require('plugin/alert');
        var Modal = require('plugin/modal');
        var circle = require('plugin/circle');
        var UploadImgBox = require('admin/js/admin_upload');

        //var bannerType = {0: '美日惠首页', 1: '美日惠二级页面', 2: '微商城首页'};//banner分类
        var bannerType = {2: '微商城首页',0: '美日惠首页'};//banner分类

        //添加banner
        $('.btn-addBanner').each(function () {
            var el = $(this);
            UploadImgBox(el, '添加banner图片', function (myModal) {

                var box = '<div class="form-horizontal">' +
                    '<input type="hidden" name="id" value="" formtype="val_item" empty="true">' +
                    '<div class="form-group form-group-sm hide">' +
                    '<label for="picUrl" class="col-sm-2 control-label">缩略图地址</label>' +
                    '<div class="col-sm-7" style="padding: 0 5px;"><input empty="true" tabindex="1" type="text" class="form-control" id="thumbnailUrl" name="thumbnailUrl" placeholder="请输入外链图片地址或者上传新图片 70*70" placeholders="缩略图地址" formtype="val_item" format="url"></div>' +
                    '<div class="col-sm-2" style="padding: 0 0 0 5px;">' +
                    '<form method="post" action="/admin/file/upload" enctype="multipart/form-data">' +
                    '<input type="hidden" name="maxSize" value="100">' +
                    '<input type="hidden" name="token" value="' + $.cookie("token") + '">' +
                    '<input type="hidden" name="fileType" value="image">' +
                    '<input type="file" name="file" class="upload_btn">' +
                    '<button type="button" class="btn btn-primary btn-sm upload_label" style="width: 78px; padding-left: 5px;"><span class="upload_text">上传图片</span>&nbsp;<span class="fa fa-cloud-upload"></span></button></form>' +
                    '</div></div>';

                box += '<div class="form-group form-group-sm">' +
                    '<label for="title" class="col-sm-2 control-label">横幅标题</label> ' +
                    '<div class="col-sm-10"><input empty="true" tabindex="3" type="text" class="form-control" id="title" ' +
                    'name="title" placeholder="请输入横幅标题" placeholders="横幅标题" formtype="val_item"></div></div>' +
                    '<input type="hidden" name="describe" value="#fff" formtype="val_item">'+

                    '<div class="form-group form-group-sm">' +
                    '<label for="type" class="col-sm-2 control-label">所属页面</label> ' +
                    '<div class="col-sm-10"><select class="form-control btn btn-default" id="bannerType" name="typeId" formtype="val_item"></select></div> </div>';

                    //' <div class="form-group form-group-sm">' +
                    //'<label for="describe" class="col-sm-2 control-label">背景色值</label> ' +
                    //'<div class="col-sm-10"><input tabindex="3" type="text" class="form-control" id="describe" ' +
                    //'name="describe" placeholder="请输入背景色值，如#970256" ' +
                    //' placeholders="背景色值" formtype="val_item" empty="true"></div> </div>';

                $('.form-horizontal', myModal).append(box);
                $('[name="maxWidth"]', myModal).val(1002);
                $('[name="maxHeight"]', myModal).val(360);
                $('.modal-content', myModal).attr('action', '/admin/banner/updateBanner');

                var option = '';
                $.each(bannerType, function (n, v) {
                    option += '<option value="' + n + '">' + v + '</option>';
                });
                $('#bannerType').html(option).val(getQueryString('typeId') || 2)

            }, function (ob) {
                location.href = '?ts=' + new Date().getTime() + '&typeId=' + $('#bannerType').val();
            })
        });

        myApp.controller('bannerCtrl', function ($scope, $http, $timeout) {

            $scope.typeId = getQueryString('typeId') || 2;
            $scope.bannerType = bannerType;

            //初始化排序
            $scope.initSort = function () {
                seajs.use('plugin/jquery-ui/jquery-ui-1.11.4', function () {
                    $('.table tbody').sortable({
                        placeholder: "bg-warning",
                        revert: true,
                        opacity: 0.5,
                        cursor: "move",
                        axis: "y",
                        start: function (event, ui) {
                            $('.table thead th').each(function (index) {
                                $('td', ui.item).eq(index).width($(this).width())
                            })
                        },
                        stop: function (event, ui) {
                            var len = $('.table tbody tr').length;
                            $('.table tbody tr').each(function (index) {
                                var id = $(this).attr('bid');
                                var oldNum = parseInt($('td:eq(0)', this).text());
                                $('td:eq(0)', this).text(index + 1);
                                if(id && oldNum != index + 1) {
                                    $.post('/admin/banner/sortBanner', {
                                        id: id,
                                        sortNum: index + 1,
                                        sid: Math.random()
                                    }, 'json')
                                }
                            });
                        }
                    });
                })
            };

            //删除操作
            $scope.delete = function (event, id) {
                var el = $(event.target);
                var myModal = new Modal(el, {
                    id: 'myDelete',
                    marginTop: $(window).height() / 2 - 60,
                    title: '是否确认删除？',
                    btnText: '确认删除',
                    width: 400
                });
                var pt = el.parents('tr').eq(0);
                $('.btn-primary', myModal).on('click', function () {
                    myModal.modal('hide');
                    $.post('/admin/banner/deleteBanner', {
                        id: id
                    }, function (response) {
                        if (response.success) {
                            new Alert(response.data || '删除成功', 'success');
                            circle({
                                'fn': function (a) {
                                    pt.addClass('success');
                                    if (a.times % 2) {
                                        pt.removeClass('success');
                                    }
                                },
                                'afterfn': function () {
                                    var tb = pt.parents('.table');
                                    pt.remove();
                                    var trs = $('tr', tb);
                                    trs.each(function (a) {
                                        console.log(a);
                                        if (a) {
                                            $('td', this).eq(0).text(a);
                                        }
                                    });
                                },
                                'mg': 200,
                                'times': 4
                            })
                        } else {
                            new Alert(response.data, 'error');
                        }
                    }, 'json').error(function (err) {
                        var msg = err.status || err;
                        new Alert(msg, 'error');
                    })
                })
            };

            //添加/编辑
            $scope.initEdit = function () {

                $('.table tr a.edit').each(function () {
                    var el = $(this);
                    var tr = el.parents('.table tr');
                    var id = tr.attr('bid');

                    UploadImgBox(this, '更改banner图片', function (myModal) {

                        var box = '<div class="form-horizontal">' +
                        '<input type="hidden" name="id" value="" formtype="val_item" empty="true">' +
                        '<div class="form-group form-group-sm hide">' +
                        '<label for="picUrl" class="col-sm-2 control-label">缩略图地址</label>' +
                        '<div class="col-sm-7" style="padding: 0 5px;"><input empty="true" tabindex="1" type="text" class="form-control" id="thumbnailUrl" name="thumbnailUrl" placeholder="请输入外链图片地址或者上传新图片 70*70" placeholders="缩略图地址" formtype="val_item" format="url"></div>' +
                        '<div class="col-sm-2" style="padding: 0 0 0 5px;">' +
                        '<form method="post" action="/admin/file/upload" enctype="multipart/form-data">' +
                        '<input type="hidden" name="maxSize" value="100">' +
                        '<input type="hidden" name="token" value="' + $.cookie("token") + '">' +
                        '<input type="hidden" name="fileType" value="image">' +
                        '<input type="file" name="file" class="upload_btn">' +
                        '<button type="button" class="btn btn-primary btn-sm upload_label" style="width: 78px; padding-left: 5px;"><span class="upload_text">上传图片</span>&nbsp;<span class="fa fa-cloud-upload"></span></button></form>' +
                        '</div></div>';

                        box += '<div class="form-group form-group-sm">' +
                            '<label for="title" class="col-sm-2 control-label">横幅标题</label> ' +
                            '<div class="col-sm-10"><input empty="true" tabindex="3" type="text" class="form-control" id="title" ' +
                            'name="title" placeholder="请输入横幅标题" placeholders="横幅标题" formtype="val_item"></div></div>' +
                            '<input type="hidden" name="describe" value="#fff" formtype="val_item">'+

                            ' <div class="form-group form-group-sm">' +
                            '<label for="type" class="col-sm-2 control-label">所属页面</label> ' +
                            '<div class="col-sm-10"><select class="form-control btn btn-default" id="bannerType" name="typeId" formtype="val_item"></select></div> </div>';
                            //
                            //'<div class="form-group form-group-sm">' +
                            //'<label for="describe" class="col-sm-2 control-label">背景色值</label> ' +
                            //'<div class="col-sm-10"><input tabindex="3" type="text" class="form-control" id="describe" ' +
                            //'name="describe" placeholder="请输入背景色值，如#970256" ' +
                            //' placeholders="背景色值" formtype="val_item" empty="true"></div> </div>';
                        $('.form-horizontal', myModal).append(box);

                        var option = '';
                        $.each($scope.bannerType, function (n, v) {
                            option += '<option value="' + n + '">' + v + '</option>';
                        });

                        $('[name="id"]', myModal).val(id);
                        $('[name="maxWidth"]', myModal).val(1002);
                        $('[name="maxHeight"]', myModal).val(360);
                        $('.modal-content', myModal).attr('action', '/admin/banner/updateBanner');

                        $('#bannerType').html(option).val($('td:eq(1)', tr).attr('typeId'));
                        $('#picUrl').val($('img.picUrl', tr).attr('src'));
                        $('#thumbnailUrl').val($('img.thumbnailUrl', tr).attr('src'));
                        //$('#describe').val($('img.picUrl', tr).attr('bg'));
                        $('#picLink').val($('td.link', tr).text());
                        $('#title').val($('td.title', tr).text());

                    }, function (ob) {
                        $('img.picUrl', tr).attr('src', $('#picUrl').val());
                        //$('img.picUrl', tr).attr('bg', $('#describe').val());
                        $('img.thumbnailUrl', tr).attr('src', $('#thumbnailUrl').val());

                        var picLink = $('#picLink').val();
                        $('td.link', tr).html('<a href="' + picLink + '" target="_blank">' + picLink + '</a>');
                        var $bannerType = $('#bannerType');
                        $('td.typeId', tr).text($bannerType.find("option:selected").text()).attr('typeId', $bannerType.val());
                        $('td.title', tr).text($('#title').val());
                        $('#myUpload').modal('hide');

                        if($scope.typeId != $bannerType.val())
                            location.href = '?ts=' + new Date().getTime() + '&typeId=' + $bannerType.val();
                    })
                })
            };

            var url = '/common/getBanner.json';
            if(location.hostname == 'localhost')
                url = '/admin/operate/banner/getBanner.json';
            $http.get(url + '?typeId=' + $scope.typeId).success(function (response) {
                if (response.success) {
                    $scope.bannerList = response.data;

                    $timeout(function () {
                        $scope.initSort();
                        $scope.initEdit();
                    }, 100);
                }
            })
        });
    });
});