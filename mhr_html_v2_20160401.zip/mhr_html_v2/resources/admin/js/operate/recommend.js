define(function (require, exports, module) {

    var pageSize = 10;
    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        //require('angularJs');
        //require('jquery');
        //require('plugin/lightbox/js/lightbox.min');
        require('plugin/jquery-ui/jquery-ui.css');
        require('pagination');

        var Alert = require('plugin/alert');
        var getQueryString = require('plugin/getQueryString');

        //myApp.controller('recommendCtrl', function ($scope, $http, $timeout) {
        //    $scope.tagIds = getQueryString('tagIds') || 7;
        //
        //    $scope.tagList = [
        //        {"id": 1, "name": "幼儿护理"},
        //        {"id": 2, "name": "美容美发"},
        //        {"id": 3, "name": "健康助眠"},
        //        {"id": 4, "name": "口腔护理"},
        //        {"id": 5, "name": "减肥食品"},
        //        {"id": 6, "name": "女性护理"},
        //        {"id": 7, "name": "热销商品"},
        //        {"id": 8, "name": "精选商品"},
        //        {"id": 9, "name": "促销商品"}
        //    ];
        //
        //    $scope.getTagName = function (id) {
        //        $.each($scope.tagList, function (n, x) {
        //            if (x.id == id)
        //                return x.name;
        //        })
        //    };
        //
        //    //初始化排序
        //    $scope.initSort = function () {
        //        seajs.use('plugin/jquery-ui/jquery-ui-1.11.4', function () {
        //            $('#tb_recommend.table tbody').sortable({
        //                placeholder: "bg-warning",
        //                revert: true,
        //                opacity: 0.5,
        //                cursor: "move",
        //                axis: "y",
        //                start: function (event, ui) {
        //                    $('#tb_recommend.table thead th').each(function (index) {
        //                        $('td', ui.item).eq(index).width($(this).width())
        //                    })
        //                },
        //                stop: function (event, ui) {
        //                    var len = $('#tb_recommend.table tbody tr').length;
        //                    $('#tb_recommend.table tbody tr').each(function (index) {
        //                        var id = $(this).attr('recId');
        //                        var oldNum = parseInt($('td:eq(0)', this).text());
        //                        $('td:eq(0)', this).text(index + 1);
        //                        if (id && oldNum != len - index) {
        //                            $.post('/admin/recommend/sort', {
        //                                id: id,
        //                                sortNum: (len - index),
        //                                sid: Math.random()
        //                            }, 'json')
        //                        }
        //                    });
        //                }
        //            });
        //        })
        //    };
        //
        //
        //    //添加推荐
        //    $scope.add = function (event, id) {
        //        var el = $(event.target);
        //        var pt = el.parents('tr').eq(0);
        //        if ($('tr[pid="' + id + '"]', '#tb_recommend')[0]) {
        //            new Alert('该商品已推荐', 'warning');
        //            return;
        //        }
        //        $.post('/admin/recommend/add', {
        //            productId: id,
        //            tagIds: $scope.tagIds,
        //            isPC: true,
        //            isWX: true
        //        }, function (response) {
        //            if (response.success) {
        //                new Alert(response.data, 'success');
        //                pt.fadeOut(1000, function () {
        //                    $(this).remove();
        //                });
        //                $scope.getRecommendList();
        //            } else {
        //                new Alert(response.data, 'error');
        //            }
        //        }, 'json');
        //    };
        //
        //    //撤销推荐
        //    $scope.delete = function (event, id) {
        //        var el = $(event.target);
        //        var pt = el.parents('tr').eq(0);
        //        $.post('/admin/recommend/delete', {
        //            id: id
        //        }, function (response) {
        //            if (response.success) {
        //                new Alert(response.data, 'success');
        //                pt.fadeOut(1000, function () {
        //                    $(this).remove();
        //                });
        //            } else {
        //                new Alert(response.data, 'error');
        //            }
        //        }, 'json');
        //    };
        //
        //    //更新推荐
        //    $scope.update = function (x, type) {
        //        var isPC = x.isPC;
        //        var isWX = x.isWX;
        //        if (type == 'PC')
        //            isPC = !x.isPC;
        //        else
        //            isWX = !x.isWX;
        //        $http({
        //            method: 'POST',
        //            url: '/admin/recommend/update',
        //            data: $.param({
        //                id: x.itemId,
        //                isPC: isPC,
        //                isWX: isWX
        //            }),
        //            headers: {
        //                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        //            }
        //        }).success(function (response) {
        //            if (response.success) {
        //                x.isPC = isPC;
        //                x.isWX = isWX;
        //                new Alert(response.data, 'success');
        //            } else {
        //                new Alert(response.data, 'error');
        //            }
        //        });
        //    };
        //
        //    //推荐列表
        //    $scope.getRecommendList = function () {
        //        $http.get("/product/getProductForIndex.json?tagIds=" + $scope.tagIds).success(function (response) {
        //            if (response.success && response.data.length > 0) {
        //                $scope.recommendList = response.data;
        //
        //                $timeout(function () {
        //                    $scope.initSort();
        //                }, 100);
        //            }
        //        });
        //    };
        //    $scope.getRecommendList();
        //
        //    //商品列表
        //    $scope.getProductList = function (currentPage) {
        //        currentPage = currentPage || 1;
        //        $http({
        //            method: 'get',
        //            url: '/product/getProductList.json',
        //            params: {
        //                keyword: $scope.keyword,
        //                pageNumber: currentPage,
        //                pageSize: pageSize,
        //                stamp: new Date().getTime()
        //            }
        //        }).success(function (response) {
        //            $scope.productList = null;
        //            $scope.totalCount = 0;
        //            if (response.success) {
        //                $scope.productList = response.data;
        //                $scope.totalCount = response.totalCount;
        //                $timeout(function () {
        //                    $('.pagination').pagination({
        //                        currentPage: currentPage,
        //                        items: $scope.totalCount,
        //                        itemsOnPage: pageSize,
        //                        displayedPages: 3,
        //                        prevText: '上一页',
        //                        nextText: '下一页',
        //                        cssStyle: 'bootstrap-theme',
        //                        onPageClick: function (pageNumber) {
        //                            $scope.getProductList(pageNumber);
        //                        }
        //                    });
        //                }, 100);
        //            }
        //        });
        //    };
        //    $scope.getProductList();
        //});


        myApp.controller('themeRecommendCtrl', function ($scope, $http, $timeout) {
            $scope.tagId = getQueryString('tagId');
            $scope.pageSize = pageSize;

            //获取推荐tag分类
            var url = '/common/getTagList.json';
            if ($.isTest)
                url = '/product/getTagList.json';
            $http.get(url + '?type=theme').success(function (response) {
                if (response.success) {
                    $scope.TagList = response.data;

                    //默认加载第一个tag
                    if(!$scope.tagId && $scope.TagList){
                        $scope.getRecommendThemeList($scope.TagList[0].id);
                    }
                }
            });

            //初始化排序
            $scope.initSort = function () {
                seajs.use('plugin/jquery-ui/jquery-ui-1.11.4', function () {
                    $('#theme_recommend.table tbody').sortable({
                        placeholder: "bg-warning",
                        revert: true,
                        opacity: 0.5,
                        cursor: "move",
                        axis: "y",
                        start: function (event, ui) {
                            $('#theme_recommend.table thead th').each(function (index) {
                                $('td', ui.item).eq(index).width($(this).width())
                            })
                        },
                        stop: function (event, ui) {
                            var len = $('#theme_recommend.table tbody tr').length;
                            $('#theme_recommend.table tbody tr').each(function (index) {
                                var id = $(this).attr('recId');
                                //console.log(id)
                                var oldNum = parseInt($('td:eq(0)', this).text());
                                $('td:eq(0)', this).text(index + 1);
                                if (id) {
                                    $.post('/admin/theme/recommend/sort', {
                                        id: id,
                                        sortNo: index + 1,
                                        sid: Math.random()
                                    }, 'json')
                                }
                            });
                        }
                    });
                })
            };

            //推荐主题列表
            $scope.RecommendThemeList = [];
            $scope.getRecommendThemeList = function (tagId) {
                if(tagId) {
                    $scope.tagId = tagId;
                    var url = '/admin/theme/recommend/getList.json';
                    if ($.isTest)
                        url = '/admin/operate/theme/getList.json';
                    $http.get(url + "?tagId=" + $scope.tagId).success(function (response) {
                        if (response.success && response.data.length > 0) {
                            $scope.RecommendThemeList = response.data;
                            $timeout(function () {
                                $scope.initSort();
                            }, 100);
                        }
                    });
                }
            };
            $scope.getRecommendThemeList($scope.tagId);

            //主题列表
            $scope.getThemeList = function (currentPage) {
                currentPage = currentPage || 1;
                $scope.pageNumber = currentPage;
                $http({
                    method: 'get',
                    url: '/admin/theme/getList.json',
                    params: {
                        keyword: $scope.keyword,
                        pageNumber: currentPage,
                        pageSize: pageSize,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    $scope.productList = null;
                    $scope.totalCount = 0;
                    if (response.success) {
                        $scope.ThemeList = response.data;
                        $scope.totalCount = response.totalCount;
                        $timeout(function () {
                            $('.pagination').pagination({
                                currentPage: currentPage,
                                items: $scope.totalCount,
                                itemsOnPage: pageSize,
                                displayedPages: 3,
                                prevText: '上一页',
                                nextText: '下一页',
                                cssStyle: 'bootstrap-theme',
                                onPageClick: function (pageNumber) {
                                    $scope.getThemeList(pageNumber);
                                }
                            });
                        }, 100);
                    }
                });
            };
            $scope.getThemeList();

            //添加推荐
            $scope.add = function (event, x) {
                var el = $(event.target);
                var pt = el.parents('tr').eq(0);
                if ($('#theme_recommend tr[themeId="' + x.id + '"]')[0]) {
                    new Alert('该主题已推荐', 'warning');
                    return;
                }
                if(!x.enabled){
                    new Alert('主题未启用，推荐后不会在首页显示哦！','warning');
                }
                $http({
                    method: 'POST',
                    url: '/admin/theme/recommend/add',
                    data: $.param({
                        themeId: x.id,
                        tagId: $scope.tagId
                    }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
                }).success(function (response) {
                    if (response.success) {
                        new Alert('推荐成功', 'success');
                        pt.fadeOut(1000, function () {
                            $(this).remove();
                        });
                        $timeout(function () {
                            $scope.RecommendThemeList.push({
                                "id": x.id,
                                "itemId":response.data,
                                "title": x.title
                            });
                        },1000);
                        //$scope.getRecommendThemeList($scope.tagId);
                    } else {
                        new Alert(response.data, 'error');
                    }
                });
            };

            //撤销推荐
            $scope.delete = function (event, id) {
                var el = $(event.target);
                var pt = el.parents('tr').eq(0);
                $.post('/admin/theme/recommend/delete', {
                    id: id
                }, function (response) {
                    if (response.success) {
                        new Alert(response.data, 'success');
                        pt.fadeOut(1000, function () {
                            $(this).remove();
                        });
                    } else {
                        new Alert(response.data, 'error');
                    }
                }, 'json');
            };


        })


    });
});