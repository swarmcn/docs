define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('plugin/lightbox/js/lightbox.min');
    require('plugin/jquery-ui/jquery-ui.css');
    require('pagination');
    require('plugin/validate.el');

    var UploadFile = require('plugin/upload');
    var Alert = require('plugin/alert');
    var getQueryString = require('plugin/getQueryString');

    // 对Date的扩展，将 Date 转化为指定格式的String
    Date.prototype.Format = function (fmt) {
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    };

    var pageSize = 8;
    var pageSize2 = 6;
    var flashId = getQueryString('id');
    var isTest = (location.hostname == 'localhost');
    if (flashId) {

        //绑定上传
        function initUploadFile(obj) {
            new UploadFile(obj, function (data, el) {
                var res = {};
                try {
                    res = eval('(' + data + ')');
                } catch (e) {

                }
                if (isTest)
                    res.url = 'http://www.365meirihui.com/resources/images/active/guoqing-2015/banner.jpg';
                if (res.url) {
                    $('.input-group > .imgUrl', el).val(res.url);
                    $('.input-group > a', el).attr('href', res.url);
                    $('.input-group > a > img', el).attr('src', res.url);
                    new Alert((res.message && res.message.content) || '上传成功', "success");
                } else {
                    new Alert((res.message && res.message.content) || '404', "error");
                }
            });
        }

        initUploadFile('.upload-pc');
        initUploadFile('.upload-wx');
        initUploadFile('.upload-brief');
    } else {
        ////商品搜索表单
        //$('.page-header form').submit(function () {
        //    var $keyword = $("input", this);
        //    location.href = '?key=' + encodeURI($keyword.val());
        //});
        //$('.panel-heading form').submit(function () {
        //    var $keyword = $("input", this);
        //    location.href = '?key=' + encodeURI($keyword.val());
        //});
    }

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('flashCtrl', function ($scope, $http, $timeout) {

            $scope.nowDate = new Date().getTime();
            $scope.token = $.cookie('token') || 0;
            if (flashId) {
                var url = '/admin/flash/getDetail.json';
                if (isTest)
                    url = '/admin/operate/flash/getDetail.json';
                $http.get(url + '?id=' + flashId).success(function (response) {
                    if (response.success) {
                        $scope.flash = response.data;
                        $scope.flash.id = flashId;

                        //格式化时间
                        if ($scope.flash.beginDate)
                            $scope.flash.beginDate = new Date($scope.flash.beginDate).Format("yyyy-MM-dd hh:mm:ss");
                        else
                            $scope.flash.beginDate = new Date().Format("yyyy-MM-dd 10:00:00");//初始时间
                        if ($scope.flash.endDate)
                            $scope.flash.endDate = new Date($scope.flash.endDate).Format("yyyy-MM-dd hh:mm:ss");
                        else
                            $scope.flash.endDate = new Date(new Date($scope.flash.beginDate).getTime() + 86400000).Format("yyyy-MM-dd 9:59:59");//初始时间

                        $timeout(function () {
                            seajs.use('plugin/bootstrap-switch/js/bootstrap-switch.min', function () {
                                $("input[type=\"checkbox\"]").show().bootstrapSwitch();
                            });
                        }, 100);
                    }
                });

                //保存
                $scope.save = function () {
                    var isErr = false;
                    $scope.flash.enabled = $('#enabled').prop('checked');//是否启用
                    $scope.flash.discount = $('[name="discount"]').val();
                    $('[name].form-control:not([empty="true"])').each(function () {
                        var el = $(this);
                        var name = el.attr('name');
                        var val = el.val() || el.html();
                        var info = el.attr('info') || el.attr('placeholder');
                        if (!val && !isErr && $scope.flash.enabled) {
                            isErr = true;
                            el.focus();
                            new Alert(info + ' 不能为空', "warning");
                        }
                        $scope.flash[name] = val;
                    });
                    if (isErr)
                        return;

                    $.post('/admin/flash/update', $scope.flash, function (response) {
                        if (response.success)
                            location.replace('index.html?ts=' + new Date().getTime());
                        else
                            new Alert(response.data, "error");
                    }, 'json');
                }
            } else {
                //绑定列表
                $scope.key = getQueryString('key');
                $scope.keyword = getQueryString('keyword');
                var url = '/admin/flash/getList.json';
                if (isTest)
                    url = '/admin/operate/flash/getList.json';
                $scope.getFlashList = function (currentPage) {
                    currentPage = currentPage || 1;
                    $http({
                        method: 'get',
                        url: url,
                        params: {
                            keyword: $scope.key,
                            pageNumber: currentPage,
                            pageSize: pageSize,
                            stamp: new Date().getTime()
                        }
                    }).success(function (response) {
                        $scope.flashList = [];
                        $scope.flashTotalCount = 0;
                        if (response.success) {
                            $scope.flashList = response.data;
                            $scope.flashTotalCount = response.totalCount;
                            $timeout(function () {
                                $('.page_flash .pagination').pagination({
                                    currentPage: currentPage,
                                    items: $scope.flashTotalCount,
                                    itemsOnPage: pageSize,
                                    displayedPages: 3,
                                    prevText: '上一页',
                                    nextText: '下一页',
                                    cssStyle: 'bootstrap-theme',
                                    onPageClick: function (pageNumber) {
                                        $scope.getFlashList(pageNumber);
                                    }
                                });
                            }, 100);
                        }
                    });
                };
                $scope.getFlashList();

                //商品列表
                $scope.getProductList = function (currentPage) {
                    currentPage = currentPage || 1;
                    $scope.currentPage = currentPage;
                    $http({
                        method: 'get',
                        url: '/product/getProductList.json',
                        params: {
                            isAll: true,
                            keyword: $scope.keyword,
                            pageNumber: currentPage,
                            pageSize: pageSize2,
                            stamp: new Date().getTime()
                        }
                    }).success(function (response) {
                        $scope.productList = [];
                        $scope.productTotalCount = 0;
                        if (response.success) {
                            $scope.productList = response.data;
                            $scope.productTotalCount = response.totalCount;
                            $timeout(function () {
                                $('.panel-info .pagination').pagination({
                                    currentPage: currentPage,
                                    items: $scope.productTotalCount,
                                    itemsOnPage: pageSize2,
                                    displayedPages: 3,
                                    prevText: '上一页',
                                    nextText: '下一页',
                                    cssStyle: 'bootstrap-theme',
                                    onPageClick: function (pageNumber) {
                                        $scope.getProductList(pageNumber);
                                    }
                                });
                            }, 100);
                        }
                    });
                };
                $scope.getProductList();

                //添加推荐
                $scope.addFlash = function (x) {
                    $http({
                        method: 'POST',
                        url: '/admin/flash/add',
                        data: $.param({productId: x.id}),
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                        }
                    }).success(function (response) {
                        if (response.success) {
                            $('#p' + x.id).fadeOut(1000);
                            $timeout(function () {
                                $scope.productList.splice(x, 1);
                                $scope.flashList.unshift({
                                    "flashId": response.data.flashId,
                                    "stock": response.data.stock,
                                    "productId": x.id,
                                    "name": x.name,
                                    "enabled": false,
                                    "price": x.price
                                });
                            }, 1000);
                        }
                        else
                            new Alert(response.data, 'error');
                    });
                };
            }
        });
    });

});