define(function (require, exports, module) {

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        require('plugin/lightbox/js/lightbox.min');
        require('plugin/jquery-ui/jquery-ui.css');

        var getQueryString = require('plugin/getQueryString');
        var Alert = require('plugin/alert');
        var UploadFile = require('plugin/upload');
        var headers = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'};


        //绑定上传
        new UploadFile('#url_upload', function (data, el) {
            var res = {};
            try {
                res = eval('(' + data + ')');
            } catch (e) {

            }
            if ($.isTest)
                res.url = 'http://www.365meirihui.com/resources/images/active/guoqing-2015/banner.jpg';
            if (res.url) {
                $('[name="url"]', el).val(res.url);
                new Alert((res.message && res.message.content) || '上传成功', "success");
            } else {
                new Alert((res.message && res.message.content) || '404', "error");
            }
        });

        myApp.controller('pictureCtrl', function ($scope, $http,$timeout) {
            $scope.token = $.cookie('token');

            //绑定列表
            var url = "/admin/picture/getList.json";
            if($.isTest)
                url = '/admin/operate/picture/getList.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.pictureList = response.data;

                    //临时处理
                    $.each($scope.pictureList, function (n,x) {
                        if(!x.type)
                            x.type = 'loginPage';
                    })
                }
            });

            //绑定编辑
            $scope.showModal = function (index, x) {
                if(x) {
                    $scope.pic = {
                        index: index,
                        type: x.type,
                        title: x.title,
                        link: x.link,
                        url: x.url
                    };
                }
                else{
                    $scope.pic = {};
                }
                $timeout(function () {
                    $('[name="title"]').focus();
                }, 1000)
            };

            //保存广告
            $scope.save = function () {
                var param = {
                    type: $('[name="type"]').val(),
                    title: $scope.pic.title,
                    link: $scope.pic.link,
                    url: $('[name="url"]').val()
                };

                if(!$scope.pic.index && $('tr[data-type="'+ param.type +'"]','#tb_picture')[0]){
                    new Alert('该广告位已存在','warning');
                    return;
                }

                if(!param.url){
                    new Alert('请上传广告图片','warning');
                    return;
                }

                //if($scope.pic.index) {
                //    $scope.pictureList.splice($scope.pic.index, 1);
                //    $scope.pictureList.splice($scope.pic.index, 0, param);
                //}
                //else{
                //    $scope.pictureList.push(param);
                //}
                //$('#myModal').modal('hide');

                $http({
                    method: 'POST',
                    url: '/admin/picture/update',
                    data: $.param(param),
                    headers: headers
                }).success(function (response) {
                    if (response.success) {
                        new Alert(response.data, 'success');
                        if($scope.pic.index) {
                            $scope.pictureList.splice($scope.pic.index, 1);
                            $scope.pictureList.splice($scope.pic.index, 0, param);
                        }
                        else{
                            $scope.pictureList.push(param);
                        }
                        $('#myModal').modal('hide');
                    }
                    else
                        new Alert(response.data, 'danger');
                });
            };

            //绑定删除
            $scope.showModalDel = function (index,x) {
                $scope.pic = {
                    index: index,
                    type: x.type
                };
            };

            //删除广告
            $scope.delete = function () {

                //$scope.pictureList.splice($scope.pic.index, 1);
                //$('#myModalDel').modal('hide');

                $http({
                    method: 'POST',
                    url: '/admin/picture/delete',
                    data: $.param({
                        type: $scope.pic.type
                    }),
                    headers: headers
                }).success(function (response) {
                    if (response.success) {
                        new Alert(response.data, 'success');
                        $scope.pictureList.splice($scope.pic.index, 1);
                        $('#myModalDel').modal('hide');
                    }
                    else
                        new Alert(response.data, 'danger');
                });
            };
        })
    });
});