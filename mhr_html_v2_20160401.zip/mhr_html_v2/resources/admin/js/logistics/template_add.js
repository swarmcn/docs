define(function (require, exports, module) {
    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        //require('angularJs');
        require('bootstrap');
        require('jquery');
        require('token');//令牌，POST时必须调用
        require('pagination');
        require('plugin/lightbox/js/lightbox.min');
        require('plugin/validate.el');

        var Alert = require('plugin/alert');
        var $delegate = require('plugin/delegateEvent');
        var getQueryString = require('plugin/getQueryString');
        var id = getQueryString('id');
        var timestamp = new Date().getTime();

        //移除高亮
        $delegate('.input-danger',{
            'keyup': function () {
                if($.trim($(this).val()).length > 0)
                    $(this).removeClass('input-danger');
            }
        });

        //关闭弹窗
        $delegate('a.btn-close', {
            'click': function () {
                $('.popover').popover('destroy');
            }
        });

        $delegate('.popover-title label',{
            'click': function () {
                var el = $(this);
                var pt = el.parents('.popover');
                $(':checkbox',pt).prop('checked', false);
            }
        });

        //replace
        myApp.filter(
            'replace', ['$sce', function ($sce) {
                return function (text, param1, param2) {
                    var re = new RegExp(param1, "g");
                    if(text)
                        return text.replace(re, param2);
                    else
                        return text;
                }
            }]
        );

        //取整
        myApp.filter(
            'to_Int', ['$sce', function ($sce) {
                return function (text) {
                    return parseInt(text);
                }
            }]
        );

        myApp.controller('templateCtrl', function ($scope, $http) {
            $scope.ZXS = [1, 18, 792, 2240];//直辖市
            $scope.temp = {};
            if(id) {
                var url = '/admin/shipping_method/getDetail.json';
                if (location.host.indexOf('localhost') > -1)
                    url = '/admin/system/logistics/template/getSingle.json';
                $http.get(url + '?id=' + id).success(function (response) {
                    if (response.success) {
                        $scope.temp = response.data;
                        if(!$scope.temp.items)
                            $scope.temp.items = [];
                        if(!$scope.temp.freeItems)
                            $scope.temp.freeItems = [];
                    }
                });
            }else{
                $scope.temp = {
                    "id": null,
                    "name": null,
                    "sharePrice": null,
                    "modifyDate": null,
                    "firstWeight": 1,
                    "firstPrice": null,
                    "continueWeight": 1,
                    "continuePrice": null,
                    "items": [{
                        //"itemId": null,
                        "continuePrice": 1,
                        "continueWeight": 1,
                        "deliveryAreaIds": null,
                        "deliveryAreaNames": null,
                        "firstPrice": 1,
                        "firstWeight": 1
                    }],
                    "freeItems": [],
                    "specifiedFree": false
                };
            }

            //绑定省列表
            var url = '/common/areas/getList.json';
            if (location.host.indexOf('localhost') > -1)
                url = '/member/areas/getList.json';
            $http.get(url + '?ts=' + timestamp).success(function (response) {
                if (response.success) {
                    $scope.jsonArea = response.data;
                    $.each($scope.jsonArea, function (n, x) {
                        x.index = n;
                        if ($scope.ZXS.indexOf(x.id) == -1) {
                            var url = '/common/areas/getList.json?parentId=' + x.id;
                            if (location.host.indexOf('localhost') > -1)
                                url = '/member/areas/getCity.json?1=1';
                            $http.get(url + '&ts=' + timestamp).success(function (citys) {
                                x.cityIds = [];
                                x.cityNames = [];
                                x.areas = [];
                                $.each(citys.data, function (n, c) {
                                    x.areas.push({"id": c.id, "name": c.name});
                                    x.cityIds.push(c.id);
                                    x.cityNames.push(c.name);
                                });
                            });
                        }
                    });
                }
            });

            //选择市
            $delegate('.areaList i.fa', {
                'click': function () {
                    var el = $(this);
                    var pid = el.data('id');
                    var index = parseInt(el.data('index'));
                    if (typeof(el.attr("aria-describedby")) != "undefined" || $('.cityList')[0])
                        return;

                    var cityIds = $scope.jsonArea[index].cityIds;
                    var cityNames = $scope.jsonArea[index].cityNames;

                    if (cityIds && cityIds.length > 0) {
                        var html = '<ul id="cityList' + pid + '" class="areaList cityList clearfix">';
                        $.each(cityIds.toString().split(','), function (n, id) {
                            var isChecked = $('[value="' + id + '"].checked')[0];
                            var isDisabled = $('[value="' + id + '"].disabled')[0];
                            var name = cityNames[n];//名称
                            html += '<li id="c' + id + '" class="pull-left text-overflow">' +
                                '<label><input type="checkbox" value="' + id + '" name="city" data-name="' + name + '" ' +
                                (isChecked ? 'checked ' : '') + (isDisabled ? 'disabled ' : '') +
                                ' > ' +
                                '<span title="' + name + '" ' + (isDisabled ? 'class="text-muted" ' : '') + '>' + name + '</span></label>' +
                                '</li>'
                        });
                        html += '</ul><hr style="margin:0 0 5px;"><div class="text-center" style="padding: 0 5px 5px;">' +
                            '<a class="btn btn-primary btn-xs btn-close-city" data-index="' + index + '" data-id="' + pid + '">关闭</a></div>';

                        $('.btn-select').addClass('disabled');
                        $('.cityList').each(function () {
                            $(this).parents('.popover').popover('destroy');
                        });
                        $('.areaList label').removeClass('text-red');
                        el.siblings('label').addClass('text-red').children(':checkbox').prop('disabled', true).prop('checked', false);
                        el.attr('title', '选择市<label class="pull-right">【反选】</label>').data({
                            "container": "body",
                            "toggle": "popover",
                            "placement": "bottom",
                            "content": html
                        }).popover({html: true}).popover('show');
                    }
                }
            });

            //确定选择
            $delegate('a.btn-select', {
                'click': function () {
                    var el = $(this);
                    var index = parseInt(el.data('index'));
                    var item = null, name = null;
                    var pt = null;
                    if (el.hasClass('item' + index))
                        pt = $('#item' + index);
                    else
                        pt = $('#freeItem' + index);
                    var $deliveryAreaIds = $('.deliveryAreaIds', pt);
                    if ($deliveryAreaIds[0]) {
                        item = $scope.temp.items[index];
                        item.deliveryAreaIds = [];
                        item.deliveryAreaNames = [];
                        $('[name="province"]:checkbox,[name="city"].checked', '.areaList').each(function () {
                            var el = $(this);
                            var id = parseInt(el.val());
                            if (el.attr('name') == 'province')
                                name = el.next().text();
                            else
                                name = el.data('name') || el.attr('cityName');
                            var index1 = item.deliveryAreaIds.indexOf(id);
                            var index2 = item.deliveryAreaNames.indexOf(name);
                            if (el[0].checked || el.hasClass('checked')) {
                                if (index1 > -1) {
                                    item.deliveryAreaIds.splice(index1, 1);
                                    item.deliveryAreaIds.splice(index1, 0, id);
                                }
                                else
                                    item.deliveryAreaIds.push(id);

                                if (index2 > -1) {
                                    item.deliveryAreaNames.splice(index2, 1);
                                    item.deliveryAreaNames.splice(index2, 0, name);
                                } else
                                    item.deliveryAreaNames.push(name);
                            }
                            else {
                                if (index1 > -1)
                                    item.deliveryAreaIds.splice(index1, 1);
                                if (index2 > -1)
                                    item.deliveryAreaNames.splice(index2, 1);
                            }
                        });
                        $deliveryAreaIds.val(item.deliveryAreaIds);
                        item.deliveryAreaNames = item.deliveryAreaNames.toString().replace(/,/g, '、');
                        $deliveryAreaIds.next().text(item.deliveryAreaNames || '未添加地区');
                    } else {
                        var $freeAreaIds = $('.freeAreaIds', pt);
                        item = $scope.temp.freeItems[index];
                        item.freeAreaIds = [];
                        item.freeAreaNames = [];
                        $('[name="province"]:checkbox,[name="city"].checked', '.areaList').each(function () {
                            var el = $(this);
                            var id = parseInt(el.val());
                            if (el.attr('name') == 'province')
                                name = el.next().text();
                            else
                                name = el.data('name') || el.attr('cityName');
                            var index1 = item.freeAreaIds.indexOf(id);
                            var index2 = item.freeAreaNames.indexOf(name);
                            if (el[0].checked || el.hasClass('checked')) {
                                if (index1 > -1) {
                                    item.freeAreaIds.splice(index1, 1);
                                    item.freeAreaIds.splice(index1, 0, id);
                                }
                                else
                                    item.freeAreaIds.push(id);

                                if (index2 > -1) {
                                    item.freeAreaNames.splice(index2, 1);
                                    item.freeAreaNames.splice(index2, 0, name);
                                } else
                                    item.freeAreaNames.push(name);
                            }
                            else {
                                if (index1 > -1)
                                    item.freeAreaIds.splice(index1, 1);
                                if (index2 > -1)
                                    item.freeAreaNames.splice(index2, 1);
                            }
                        });
                        $freeAreaIds.val(item.freeAreaIds);
                        item.freeAreaNames = item.freeAreaNames.toString().replace(/,/g, '、');
                        $freeAreaIds.next().text(item.freeAreaNames || '未添加地区');
                    }
                    el.next().click();
                }
            });

            //关闭城市弹窗
            $delegate('a.btn-close-city', {
                'click': function () {
                    var el = $(this);
                    var pid = el.data('id');
                    var pt = $('#cityList' + pid);
                    var index = parseInt(el.data('index'));
                    var $province = $('.popover [name="province"][value="' + pid + '"]:checkbox');
                    if ($(':checkbox:checked', pt).length > 0) {
                        $province.parents('li').find('.cityNum').text('(' + $(':checkbox:checked', pt).length + ')');
                        $('[name="city"]', $province.parent()).removeClass('checked');
                        $(':checkbox:checked', pt).each(function () {
                            var el = $(this);
                            var val = el.val();
                            $('[name="city"][value="' + val + '"]', $province.parent()).addClass('checked', 'checked').data('name', el.data('name'));
                        });
                    } else {
                        $province.parents('li').find('.cityNum').text('');
                        $('[name="city"]', $province.parents('li')).removeClass('checked');
                        $province.prop('disabled', false);
                    }
                    $('.areaList label.text-red').removeClass('text-red');
                    pt.parents('.popover').popover('destroy');
                    $('a.btn-select').removeClass('disabled');
                }
            });

            //添加记录
            $scope.addItem = function () {
                $scope.temp.items.push({
                    "continuePrice": 1,
                    "continueWeight": 1,
                    "deliveryAreaIds": null,
                    "deliveryAreaNames": null,
                    "firstPrice": 1,
                    "firstWeight": 1
                })
            };

            //移除记录
            $scope.delItem = function (index) {
                if(confirm('确定删除该条记录？'))
                    $scope.temp.items.splice(index, 1);
            };


            //添加记录
            $scope.addFreeItem = function () {
                $scope.temp.freeItems.push({
                    "freeAreaIds": null,
                    "freeAreaNames": null,
                    "freeWeight": 0,
                    "freeAmount":0,
                    "freeType":"weight"
                })
            };

            //移除记录
            $scope.delFreeItem = function (index) {
                if(confirm('确定删除该条记录？'))
                    $scope.temp.freeItems.splice(index, 1);
            };

            //开关包邮
            $scope.toggleFree = function () {
                if(!$scope.temp.specifiedFree && $scope.temp.freeItems.length > 0){
                    $.each($scope.temp.freeItems, function (index,x) {
                        if(x.freeAreaIds.length == 0 || !x.freeWeight)
                            $scope.temp.freeItems.splice(index, 1);
                    })
                }
            };

            //选择地区
            $scope.showAreas = function (e, index) {
                var el = $(e.target);
                var tr = el.parents('tr');
                if (typeof(el.attr("aria-describedby")) != "undefined")
                    return;

                $('.popover').popover('hide');
                el.attr('title', '选择地区').data({
                    "container": "body",
                    "toggle": "popover",
                    "placement": "right",
                    "content": $('.areaBox').html()
                }).popover({html: true}).popover('show');
                var popoverId = $('#' + el.attr("aria-describedby"));
                popoverId.find('.btn-select').data('index', index).addClass(tr[0].id);

                if ($('.deliveryAreaIds', tr)[0]) {
                    //屏蔽已选
                    $('.deliveryAreaIds', tr.siblings('tr')).each(function () {
                        var del = $(this);
                        if (del.val().length > 0) {
                            $.each(del.val().split(','), function (n, id) {
                                console.log(id);
                                var obj = $('[value="' + id + '"]', popoverId);
                                if (obj.attr('name') == 'province') {
                                    obj.prop('disabled', true);
                                    obj.parents('li').addClass('text-muted').find('.fa');
                                        //.prop('disabled', true);
                                }
                                else {
                                    obj.addClass('disabled');
                                    $('[name="province"]', obj.parents('li')).prop('disabled', true);
                                }
                            });
                        }
                    });

                    var deliveryAreaIds = $scope.temp.items[index].deliveryAreaIds;
                    if (deliveryAreaIds && deliveryAreaIds.length > 0) {
                        $.each(deliveryAreaIds.toString().split(','), function (n, id) {
                            var obj = $('[value="' + id + '"]', popoverId);
                            if (obj.attr('name') == 'province')
                                obj.prop('checked', true);
                            else {
                                obj.addClass('checked');
                                var num = obj.parents('li').find('.cityNum');
                                $('[name="province"]', obj.parents('li')).prop('disabled', true);
                                var text = (parseInt(num.text().replace('(', '').replace(')', '')) || 0) + 1;
                                num.text('(' + text + ')');
                            }
                        });
                    }
                } else {
                    //屏蔽已选
                    $('.freeAreaIds', tr.siblings('tr')).each(function () {
                        var del = $(this);
                        if (del.val().length > 0) {
                            $.each(del.val().split(','), function (n, id) {
                                console.log(id);
                                var obj = $('[value="' + id + '"]', popoverId);
                                if (obj.attr('name') == 'province') {
                                    obj.prop('disabled', true);
                                    obj.parents('li').addClass('text-muted').find('.fa').prop('disabled', true);
                                }
                                else {
                                    obj.addClass('disabled');
                                    $('[name="province"]', obj.parents('li')).prop('disabled', true);
                                }
                            });
                        }
                    });

                    var freeAreaIds = $scope.temp.freeItems[index].freeAreaIds;
                    if (freeAreaIds && freeAreaIds.length > 0) {
                        $.each(freeAreaIds.toString().split(','), function (n, id) {
                            var obj = $('[value="' + id + '"]', popoverId);
                            if (obj.attr('name') == 'province')
                                obj.prop('checked', true);
                            else {
                                obj.addClass('checked');
                                var num = obj.parents('li').find('.cityNum');
                                $('[name="province"]', obj.parents('li')).prop('disabled', true);
                                var text = (parseInt(num.text().replace('(', '').replace(')', '')) || 0) + 1;
                                num.text('(' + text + ')');
                            }
                        });
                    }
                }
            };

            //保存模板
            $scope.saveTemp = function () {
                var ipt = $('input[info]:not([empty="true"])');
                for (var i = 0; i < ipt.length; i++) {
                    var el = ipt.eq(i);
                    if (el.val().length == 0) {
                        el.addClass('input-danger').focus();
                        new Alert(el.attr('info'), 'warning');
                        return;
                    }
                }

                var $form = $('#tempForm');
                var formData = $form.serializeObject();
                formData.specifiedFree = $scope.temp.specifiedFree;
                $http({
                    method: 'POST',
                    url: '/admin/shipping_method/' + (id ? 'update' : 'add'),
                    data: $.param(formData),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
                }).success(function (response) {
                    if (response.success)
                        location.href = 'index.html';
                    else
                        new Alert(response.data, 'error');
                });
            };
        });
    });
});