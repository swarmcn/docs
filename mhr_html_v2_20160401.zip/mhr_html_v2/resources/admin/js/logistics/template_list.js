define(function (require, exports, module) {

    require('angularJs');
    require('jquery');
    require('token');//令牌，POST时必须调用
    require('pagination');
    require('plugin/lightbox/js/lightbox.min');

    var form_action = require('plugin/form_action');
    var Alert = require('plugin/alert');
    var Modal = require('plugin/modal');

    var pageSize = 10;
    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        //replace
        myApp.filter(
            'replace', ['$sce', function ($sce) {
                return function (text, param1, param2) {
                    var re = new RegExp(param1, "g");
                    if(text)
                        return text.replace(re, param2);
                    else
                        return text;
                }
            }]
        );

        myApp.controller("templateCtrl", function ($scope, $http, $timeout) {
            var url = '/admin/shipping_method/getList.json';
            if (location.host.indexOf('localhost') > -1)
                url = '/admin/logistics/template/getList.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.templateList = response.data;
                }
            })
        })


    });
});