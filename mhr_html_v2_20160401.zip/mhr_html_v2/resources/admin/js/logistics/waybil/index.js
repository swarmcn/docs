define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    var Alert = require('plugin/alert');
    var getQueryString = require('plugin/getQueryString');
    var $delegate = require('plugin/delegateEvent');


    //移除高亮
    $delegate('.form-group .form-control',{
        'keyup': function () {
            if($.trim($(this).val()).length > 0)
                $(this).parents('.form-group').removeClass('has-error');
        }
    });

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;
        myApp.controller('waybilCtrl', function ($scope, $http) {
            //提交匹配物流批次编号和主运单号
            $scope.submit = function(){
                var ipt = $('.form-control:not(:hidden)');
                for (var i = 0; i < ipt.length; i++) {
                    var el = ipt.eq(i);
                    if (el.val().length == 0) {
                        el.focus().parents('.form-group').addClass('has-error');
                        new Alert(el.attr('placeholder'), 'warning');
                        return;
                    }
                }

                $http({
                    method: 'POST',
                    url: '/admin/logisBatch/match',
                    data: $.param({
                        sn :$scope.sn,
                        totalWayBillNo:$scope.totalWayBillNo,
                        airline:$scope.airline
                    }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
                }).success(function (response) {
                    if (response.success)
                    {
                        new Alert(response.data, 'success');
                        $(".form-group .form-control").val(null);
                    }
                    else
                        new Alert(response.data, 'error');
                });
            }

        })
    })

})
