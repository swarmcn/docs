define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('plugin/validate.el');
    var Alert = require('plugin/alert');
    var getQueryString = require('plugin/getQueryString');
    var batchId = getQueryString('batchId');
    var batchSN = getQueryString('batchSN');

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('orderListCtrl', function ($scope, $http, $timeout) {
            $scope.batchSN = batchSN;//批次号

            //设置板车数
            $scope.setPackageQuantity = function () {
                if ($scope.packageQuantity) {
                    $http({
                        method: 'POST',
                        url: '/admin/logisBatch/setPackageQuantity',
                        data: $.param({
                            batchId: batchId,
                            packageQuantity: $scope.packageQuantity
                        }),
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                        }
                    }).success(function (response) {
                        if (response.success)
                            $scope.orderList.packageQuantity = $scope.packageQuantity;
                        else
                            new Alert(response.data, 'error');
                        $scope.packageQuantity = null;
                    });
                } else {
                    $('[name="packageQuantity"]').focus();
                }
            };

            //批次订单列表
            $scope.getOrderList = function () {
                var url = '/admin/logisBatch/getOrderList.json';
                if ($.isTest)
                    url = "/admin/logistics/batch/getOrderList.json";
                $.get(url,{
                    batchId:batchId,
                    pageSize:100,
                    pageNumber:1
                }, function (response) {
                    if (response.success) {
                        $scope.orderList = response.data;
                    }
                });
            };
            $scope.getOrderList();

            $scope.logisBatch_load = function () {
                $scope.orderNo = $scope.orderNo.toString();
                if (!$scope.orderNo)
                    return;

                var isCanLoad = null;
                var delIndex = null;
                $.each($scope.orderList.orders, function (n, x) {
                    if (x.sn.toString() == $scope.orderNo.toString()) {
                        if (!x.loaded) {
                            isCanLoad = true;
                            delIndex = n;
                        }
                        else
                            isCanLoad = false;
                    }
                });
                if (isCanLoad == null) {
                    new Alert( $scope.orderNo + '<br/>The order number and no match for the Lot NO.', 'warning', false, false);
                    $scope.orderNo = null;
                    return;
                }
                if (!isCanLoad) {
                    new Alert($scope.orderNo + '<br/>The order number has already been installed.', 'warning', false, false);
                    $scope.orderNo = null;
                    return;
                }

                $http({
                    method: 'POST',
                    url: '/admin/logisBatch/load',
                    data: $.param({
                        batchId: batchId,
                        orderNo: $scope.orderNo
                    }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
                }).success(function (response) {
                    if (response.success) {
                        if (delIndex > -1) $scope.orderList.orders.splice(delIndex, 1);
                        $scope.orderList.orders.unshift({sn: $scope.orderNo, loaded: true});
                        $scope.orderList.loadedQuantity++;
                        $scope.orderNo = null;
                    }
                    else {
                        new Alert(response.data, 'error', false, false);
                        $scope.orderNo = null;
                    }
                })
            }
        })

    })
})


