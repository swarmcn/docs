define(function (require, exports, module) {

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        require('pagination');
        require('date');
        var Alert = require('plugin/alert');
        var getQueryString = require('plugin/getQueryString');

        var sn = getQueryString('sn');
        var totalWayBillNo = getQueryString('totalWayBillNo');
        var beginDate = getQueryString('beginDate');
        var endDate = getQueryString('endDate');


        myApp.controller('batchCtrl', function ($scope, $http, $timeout) {
            var myDate = new Date();
            if (sn)
                $scope.snID = sn;
            if (totalWayBillNo)
                $scope.totalWayBillNo = totalWayBillNo;
            if (beginDate)
                $scope.beginDate = beginDate;
            else
                $scope.beginDate = new Date(new Date().setTime(myDate.getTime() - 1000 * 60 * 60 * 24 * 30)).Format("yyyy-MM-dd");
            if (endDate)
                $scope.endDate = getQueryString('endDate');
            else
                $scope.endDate = new Date(myDate.getFullYear() + "-" + (myDate.getMonth() + 1) + "-" + myDate.getDate()).Format("yyyy-MM-dd");


            //获取物流批次编号
            $scope.getSnClick = function () {
                var url = '/admin/logisBatch/getSn.json';
                if ($.isTest)
                    url = "/admin/logistics/batch/getSn.json";
                $.get(url, function (response) {
                    if (response.success) {
                        $scope.sn = response.data;
                        new Alert('物流ロット番号：' + response.data, 'success', false, false);
                    } else
                        new Alert(response.data, 'error');
                });
            };

            //初始化分页
            $scope.pageSize = 10;

            //物流批次列表
            var url = '/admin/logisBatch/getList.json';
            if ($.isTest)
                url = "/admin/logistics/batch/getList.json";

            $scope.getList = function (pageNumber) {
                pageNumber = pageNumber || 1;
                $scope.page = pageNumber;
                $http.get(url, {
                    params: {
                        sn: $scope.snID,
                        totalWayBillNo: $scope.totalWayBillNo,
                        beginDate: $scope.beginDate,
                        endDate: $scope.endDate,
                        pageNumber: pageNumber,
                        pageSize: $scope.pageSize,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.historyList = response.data;
                        $scope.totalCount = response.totalCount;

                        $timeout(function () {
                            $('.page_history .pagination').pagination({
                                currentPage: pageNumber,
                                items: $scope.totalCount,
                                itemsOnPage: $scope.pageSize,
                                displayedPages: 3,
                                prevText: 'pre-page',
                                nextText: 'next page',
                                cssStyle: 'bootstrap-theme',
                                onPageClick: function (pageNumber) {
                                    $scope.getList(pageNumber);
                                }
                            });
                        }, 100);
                    }
                });
            };
            $scope.getList(1);

        })
    })

});