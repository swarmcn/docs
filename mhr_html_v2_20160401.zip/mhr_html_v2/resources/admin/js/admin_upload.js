define(function(require, exports) {
    require('jquery');
    require('cookie');
    var Alert = require('plugin/alert');
    var form_action = require('plugin/form_action');
    var Modal = require('plugin/modal');
    var UploadFile = require('plugin/upload');

    var create_upload_box = '<div class="form-horizontal">' +
        '<input type="hidden" name="id" value="" formtype="val_item" empty="true">' +
        '<div class="form-group form-group-sm">' +
        '<label for="picUrl" class="col-sm-2 control-label">图片地址</label>' +
        '<div class="col-sm-7" style="padding: 0 5px;"><input tabindex="1" type="text" class="form-control" id="picUrl" name="picUrl" placeholder="请输入外链图片地址或者上传新图片" placeholders="图片地址" formtype="val_item" format="url"></div>' +
        '<div class="col-sm-2" style="padding: 0 0 0 5px;">' +
        '<form method="post" action="/admin/file/upload" enctype="multipart/form-data">' +
        '<input type="hidden" name="maxSize" value="100">' +
        '<input type="hidden" name="token" value="' + $.cookie("token") + '">' +
        '<input type="hidden" name="fileType" value="image">' +
        '<input type="file" name="file" class="upload_btn">' +
        '<button type="button" class="btn btn-primary btn-sm upload_label" style="width: 78px; padding-left: 5px;"><span class="upload_text">上传图片</span>&nbsp;<span class="fa fa-cloud-upload"></span></button></form>' +
        '</div></div>' +
        '<div class="form-group form-group-sm"><label for="jumpUrl" class="col-sm-2 control-label">跳转地址</label>' +
        '<div class="col-sm-10" style=""><input tabindex="2" type="text" class="form-control" id="picLink" name="link" placeholder="请输入跳转地址" placeholders="跳转地址" formtype="val_item" format="url" empty="true" value="#"></div></div></div>'


    var uploadImgBox = function (btn,title,before_fn,after_fn) {
        $(btn).click(function () {
            var el = $(this);
            var action = el.attr('action') || 'uploadAdvert';
            var actiontype = el.attr('actiontype');//动作类型
            var maxWidth = el.attr('maxWidth') || 1200;
            var maxHeight = el.attr('maxHeight') || 120;
            var maxSize = el.attr('maxSize') || 150;
            var myUpload = new Modal(el, {
                id:'myUpload',
                width:450,
                marginTop:$(window).height()/2-150,
                title: title,
                btnText: '保存',
                body:create_upload_box
            });

            $('.modal-content',myUpload).attr({'action':action,'formtype':'form'});
            //$('.form-group',el.parent()).each(function () {
            //    $('.form-horizontal',myUpload).append('<div class="form-group form-group-sm">'+$(this).html()+'</div>');
            //});

            $('[name="id"]',myUpload).val(actiontype);
            $('[name="maxSize"]',myUpload).val(maxSize);

            if(typeof before_fn == 'function') {
                before_fn.call(myUpload);
            }

            maxWidth = $('[name="maxWidth"]',myUpload).val();
            maxHeight = $('[name="maxHeight"]',myUpload).val();
            maxSize = $('[name="maxSize"]',myUpload).val();
            //$('.modal-title',myUpload).append('<small class="danger">（图片大小'+maxSize+'K以内）</small>');

            //var upload_btn = $('.upload_btn',myUpload);
            //var upload_label = $('.upload_label',myUpload);
            new UploadFile($('.form-group',myUpload), function(data, el) {
                var res = {};
                try {
                    res = eval('(' + data + ')');
                } catch (e) {

                }

                if (res.url) {
                    $('#picUrl', el).val(res.url);
                    $('#thumbnailUrl', el).val(res.url);
                    new Alert((res.message && res.message.content) || '上传成功', "success");
                }else{
                    new Alert((res.message && res.message.content) || '404', "error");
                }
            });

            //提交保存
            $('.modal-footer .btn-primary',myUpload).click(function () {
                var ob = {};
                form_action(this, function (data) {
                    ob = data;
                    $('#describe').val($('#describe').val() || '#');
                    return true;
                }, function(response){
                    if(response.success){
                        new Alert(response.data,'success');
                        if(typeof after_fn == 'function'){
                            after_fn.call(ob);
                        }
                    }
                    else
                        new Alert(response.data,'error',$('.modal-content',myUpload));
                },function(err){
                   var msg = err.status || err;
                    new Alert(msg,'error',$('.modal-content',myUpload));
                })
            });
        });
    }

    return uploadImgBox;
});