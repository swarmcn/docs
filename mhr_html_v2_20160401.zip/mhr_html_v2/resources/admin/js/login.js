define(function (require, exports, module) {
    require('jquery');
    require('bootstrap');
    require('placeholder');
    require('cookie');
    require('token');//令牌，POST时必须调用
    require('validate');

    var Alert = require('plugin/alert');
    var Guid = require('plugin/guid');
    var getQueryString = require('plugin/getQueryString');
    var setUrlParam = require('plugin/setUrlParam');
    var redirectUrl = decodeURIComponent(getQueryString('redirectUrl', null, true));
    var isTest = (location.hostname == 'localhost' || location.hostname.indexOf('192.168.2') > -1 || location.hostname.indexOf('172.') > -1);

    //设置验证
    function getCaptcha(callback) {
        if (!$('#slideValidate').hasClass('open')) {
            $.getScript('//api.geetest.com/get.php?callback=startCaptcha', function () {
                window.startCaptcha = function () {
                    var url = '/common/startCaptcha';
                    if (isTest)
                        url = '/demo/startCaptchaServlet.json';
                    $.get(url, function (response) {
                        if (response.success) {
                            var data = {
                                gt: response.gt,
                                challenge: response.challenge,
                                product: "popup"
                            };
                            if (isTest)
                                delete data.challenge;
                            //ip不在中国时显示英文版
                            if(typeof remote_ip_info == 'object'){
                                if(remote_ip_info.country != "中国")
                                    data.lang = 'en';
                            }
                            window.gt_captcha_obj = new window.Geetest(data)
                                .appendTo("#slideValidate").bindOn('#btn-login')
                                .onSuccess(function () {
                                    var validate = gt_captcha_obj.getValidate();
                                    if (typeof callback == 'function') {
                                        callback.call(this, validate);
                                    }
                                });
                                //.onRefresh(function () {
                                //    //$('#btn-login').data('geetest', false);
                                //});

                            $('#slideValidate').addClass('open');
                            var autoClick = setInterval(function () {
                                if($('#origin_btn-login').length == 0){
                                    setTimeout(function () {
                                        $('#btn-login').click();
                                    },100);
                                }else
                                    clearInterval(autoClick);
                            },10);
                        }
                    }, 'json');
                };
            });
        }
    }

    ////表单验证
    //var captchaId = Guid();//验证码标识
    //var $captchaImage = $("#captchaImage");
    var $submit = $(":submit");
    //
    ////更换验证码
    //$captchaImage.click(function () {
    //    $(this).show().attr("src", "/common/captcha?captchaId=" + captchaId + "&timestamp=" + new Date().getTime());
    //}).click();//初始化

    //iframe框架内出现登录页面
    if (window.parent && window.parent.location != window.location) {
        if (!redirectUrl)
            redirectUrl = document.referrer;
        $(document.body).remove();
        window.parent.location.replace('/admin/login.html?redirectUrl=' + encodeURIComponent(redirectUrl));
        return;
    }

    var userName = $('[name="userName"]').data({
        'toggle': 'popover',
        'placement': 'bottom',
        'content': '请输入用户名'
    }).val($.cookie('adminRememberMe')).focus();
    var password = $('[name="password"]').data({'toggle': 'popover', 'placement': 'bottom', 'content': '请输入密码'});
    if ($.cookie('adminRememberMe'))
        password.focus();
    //var captcha = $("#captcha").data({'toggle': 'popover', 'placement': 'bottom', 'content': '请输入验证码'});
    //var slideValidate = $('#slideValidate').data({
    //    'toggle': 'popover',
    //    'placement': 'bottom',
    //    'content': '请拖动滑块完成验证'
    //});
    var remember = $('[name="remember"]');

    //登录
    $submit.click(function () {

        var el = $(this);

        //用户名为空
        if (userName.val() == "") {
            showError(userName);
            return;
        }

        //密码为空
        if (password.val() == "") {
            showError(password);
            return;
        }

        ////验证码为空
        //if (captcha.val() == "") {
        //    showError(captcha);
        //    return;
        //}

        //记住我
        remember.val(remember.is(':checked'));

        //$.get('/admin/logout');

        //调用验证插件
        getCaptcha(function (validate) {
            //console.log(validate);

            $.ajax({
                url: "/common/public_key",
                type: "GET",
                dataType: "json",
                cache: false,
                success: function (data) {
                    //调用加密
                    seajs.use("plugin/encrypt/secret", function () {
                        var rsaKey = new RSAKey();
                        rsaKey.setPublic(b64tohex(data.modulus), b64tohex(data.exponent));
                        var enPassword = hex2b64(rsaKey.encrypt(password.val()));

                        //提交表单
                        $.post('/admin/newlogin', {
                            username: userName.val(),
                            enPassword: enPassword,
                            geetest_challenge: validate.geetest_challenge,
                            geetest_validate: validate.geetest_validate,
                            geetest_seccode: validate.geetest_seccode
                        }, function (response) {
                            $.cookie('adminUserName', userName.val(), {expires: 7, path: '/'});//登录名称
                            if (remember.prop("checked")) {
                                $.cookie('adminRememberMe', userName.val(), {expires: 7, path: '/'});//记忆登录名称
                            } else {
                                $.removeCookie('adminRememberMe');
                            }
                            if (response.success) {
                                setTimeout(function () {
                                    if (redirectUrl && redirectUrl.indexOf('#/') > -1)
                                        location.href = redirectUrl;
                                    else
                                        location.href = "/admin/index.html";
                                }, 500);
                            } else {
                                //$submit.prop("disabled", false);
                                //$submit.text('登录');

                                //手动刷新验证码
                                //window.gt_captcha_obj.disable();
                                window.gt_captcha_obj.refresh();
                                new Alert(response.data, 'danger', '.container', true, 5000);
                            }
                        }, 'json').error(function (err) {
                            var msg = err.status || err;
                            window.gt_captcha_obj.refresh();
                            new Alert(msg, 'danger', '.container', true, 5000);
                            //$submit.prop("disabled", false);
                            //$submit.text('登录');
                        });
                    });
                }
            });
        });

        //////验证码为空
        //if (!el.data('geetest')) {
        //    showError(slideValidate);
        //    return;
        //}
        //

        ////正在登录...
        //el.text('正在登录...');
        //


    });

    //回车登录
    $("#password,[name='remember']").bind("keydown", function (e) {
        // 兼容FF和IE和Opera
        var theEvent = e || window.event;
        var code = theEvent.keyCode || theEvent.which || theEvent.charCode;
        if (code == 13) {
            //回车执行查询
            $("#btn-login").click();
        }
    });

    //显示报错
    function showError(el, msg) {
        if (msg) {
            var text = el.text();
            el.text(el.data('loading'));
            el.addClass('disabled').data('content', msg);
            setTimeout(function () {
                el.popover('destroy').removeClass('disabled');
            }, 2000);
        }
        el.addClass('input-danger')
            .focus()
            .popover('show')
            .bind('keyup click', function () {
                $(this).popover('destroy');
            });
    }

    //回车登录
    $('[name="userName"],[name="password"]').keyup(function (e) {
        if (e.keyCode == '13' && password.val().trim() != "") {
            $('#btn-sign').click();
        }
    })


});