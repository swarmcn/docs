define(function (require, exports, module) {

    var pageSize = 10;
    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;
        require('token');//令牌，POST时必须调用
        require('pagination');
        require('plugin/validate.el');
        require('plugin/lightbox/js/lightbox.min');
        var Validate = require('plugin/validate.el');

        var form_action = require('plugin/form_action');
        var Alert = require('plugin/alert');
        //var Modal = require('plugin/modal');
        var areaSelect = require('share/js/addrSelect');
        var $select = $('.selectArea select');


        myApp.controller('storeCtrl', function ($scope, $http, $timeout) {

            $scope.storeId = null;
            $scope.hostname = 'http://' + location.host;

            //生成带门店的商品列表
            $scope.create = function (x) {
                if (x && $scope.storeId || !x) {
                    var isTwo = x && $scope.storeId;
                    var chk_storeId = $('[name="storeId"]:checked');
                    if (chk_storeId.length == 0) {
                        new Alert('请勾选门店编号', 'warning');
                        return;
                    }
                    $scope.storeId = chk_storeId.val();
                    if (isTwo)
                        new Alert("切换成功，当前门店：" + x.name, 'success');
                }
            };

            //拷贝链接
            $scope.initClipboard = function () {
                seajs.use('plugin/zeroClipboard/ZeroClipboard.min', function () {
                    $('.clipboard').each(function () {

                        // 定义一个新的复制对象
                        var clip = new ZeroClipboard(this, {
                            moviePath: "/resources/plugin/zeroClipboard/ZeroClipboard.swf"
                        });

                        // 复制内容到剪贴板成功后的操作
                        clip.on('complete', function (client, args) {
                            new Alert("复制成功，请粘贴（Ctrl + V）", 'success');
                        });
                    });
                });
            };

            //门店列表
            var url = '/admin/store/getList.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.storeList = response.data;
                }
            });

            //商品列表
            $scope.getProductList = function (currentPage) {
                currentPage = currentPage || 1;
                $http({
                    method: 'get',
                    url: '/product/getProductList.json',
                    params: {
                        keyword: $scope.keyword,
                        pageNumber: currentPage,
                        pageSize: pageSize,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    $scope.productList = null;
                    $scope.totalCount = 0;
                    if (response.success) {
                        $scope.productList = response.data;
                        $scope.totalCount = response.totalCount;

                        $timeout(function () {
                            $scope.initClipboard();
                            $('.pagination').pagination({
                                currentPage: currentPage,
                                items: $scope.totalCount,
                                itemsOnPage: pageSize,
                                displayedPages: 3,
                                prevText: '上一页',
                                nextText: '下一页',
                                cssStyle: 'bootstrap-theme',
                                onPageClick: function (pageNumber) {
                                    $scope.getProductList(pageNumber);
                                }
                            });
                        }, 100);
                    }
                });
            };
            $scope.getProductList();


            //添加和编辑门店弹窗
            $scope.showShopModal = function (x) {
                $('.form-group').removeClass('has-error');
                $scope.id = null;
                $scope.name = null;
                $scope.addr = null;
                $scope.phone = null;
                $scope.zipCode = null;
                $scope.areaCode1 = null;
                $scope.areaCode2 = null;
                $scope.areaCode3 = null;
                $scope.managerRate = null;
                $scope.userRate = null;
                $scope.rules = null;

                if (x) {
                    $scope.storeItem = x;
                    $scope.id = x.id;
                    $scope.name = x.name;
                    $scope.addr = x.addr;
                    $scope.phone = x.phone;
                    $scope.zipCode = x.zipCode;
                    $scope.areaCode1 = x.areaCode1;
                    $scope.areaCode2 = x.areaCode2;
                    $scope.areaCode3 = x.areaCode3;
                    $scope.managerRate = x.managerRate;
                    $scope.userRate = x.userRate;
                    $scope.rules = x.rules;
                }

                $timeout(function () {
                    areaSelect($select);
                }, 100);
            };

            $scope.saveShop = function () {
                if (!$scope.name) {
                    new Alert('请输入门店名称！', 'warning');
                    return;
                }
                if (!$scope.addr) {
                    new Alert('请输入门店地址！', 'warning');
                    return;
                }
                if (!$scope.phone) {
                    new Alert('请输入联系电话！', 'warning');
                    return;
                }
                if (!$scope.zipCode) {
                    new Alert('请输入邮编！', 'warning');
                    return;
                }
                if (!$scope.managerRate) {
                    new Alert('请输入店长提成比例！', 'warning');
                    return;
                }
                if (!$scope.userRate) {
                    new Alert('请输入店员提成比例！', 'warning');
                    return;
                }
                if (!$scope.rules) {
                    new Alert('请输入提成规则！', 'warning');
                    return;
                }
                var resManagerRate = Validate.checkformat('[name="managerRate"]','number');
                var resUserRate = Validate.checkformat('[name="userRate"]', 'number');
                if (!resManagerRate.res || !resUserRate.res){
                    new Alert('店长或者店员提成比例格式不正确，请输入数字类型', 'warning');
                    return;
                }


                var param = {
                    name: $scope.name,
                    addr: $scope.addr,
                    phone: $scope.phone,
                    zipCode: $scope.zipCode,
                    managerRate:$scope.managerRate,
                    userRate:$scope.userRate,
                    rules: $scope.rules
                };
                $scope.areaCode1 = $('[name="areaCode1"]').val();
                $scope.areaCode2 = $('[name="areaCode2"]').val();
                $scope.areaCode3 = $('[name="areaCode3"]').val();
                if ($scope.id) {
                    param['id'] = $scope.id;
                    if ($scope.areaCode3)
                        param['area.id'] = $scope.areaCode3;
                    else
                        param['area.id'] = $scope.areaCode2;
                }
                else {
                    if ($scope.areaCode3)
                        param['area.id'] = $scope.areaCode3;
                    else
                        param['area.id'] = $scope.areaCode2;
                }

                $http({
                    method: 'POST',
                    url: '/admin/store/update',
                    data: $.param(param),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
                }).success(function (response) {
                    if (response.success) {
                        $('#myModalShop').modal('hide');
                        location.reload(true);
                    } else
                        new Alert(response.data, 'danger');
                });
            };


            //弹窗门店店长
            $scope.showShopUsersModal = function (x) {
                $('.form-group').removeClass('has-error');
                $scope.id = x.id;
                $scope.storeItem = x;
                //$scope.storeItem = x;
                //$scope.username = x.username;
                //$scope.password = x.password;
                //$scope.rePassword = x.rePassword;
                //$scope.mobile = x.mobile;
            };

            //新增门店店长
            $scope.updShopUsers = function () {
                if (!$scope.password) {
                    new Alert('请输入密码！', 'warning');
                    return;
                }
                if (!$scope.rePassword && $scope.password) {
                    new Alert('请再次输入密码！', 'warning');
                    return;
                }
                if ($scope.password != $scope.rePassword) {
                    new Alert('两次密码不相同！', 'warning');
                    return;
                }

                var param = {
                    storeId: $scope.id,
                    username: $scope.username,
                    mobile: $scope.mobile,
                    password: $scope.password,
                    rePassword: $scope.rePassword
                };

                if ($.isTest) {
                    $scope.storeItem.username = $scope.username;
                    $scope.storeItem.mobile = $scope.mobile;
                    var index = $scope.storeList.indexOf($scope.storeItem);
                    $scope.storeList.splice(index, 1);
                    $scope.storeList.splice(index, 0, $scope.storeItem);
                    $('#myModalShopUsers').modal('hide');
                }

                $http({
                    method: 'POST',
                    url: '/admin/store/updateManager',
                    data: $.param(param),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
                }).success(function (response) {
                    if (response.success) {
                        $scope.storeItem.username = $scope.username;
                        $scope.storeItem.mobile = $scope.mobile;
                        var index = $scope.storeList.indexOf($scope.storeItem);
                        $scope.storeList.splice(index, 1);
                        $scope.storeList.splice(index, 0, $scope.storeItem);
                        $('#myModalShopUsers').modal('hide');
                    } else
                        new Alert(response.data, 'danger');
                })
            }

        });
    });
});