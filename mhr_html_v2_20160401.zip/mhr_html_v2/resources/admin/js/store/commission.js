define(function (require, exports, module) {
    seajs.use('admin', function (ex) {
        require('token');
        require('validate');
        var Alert = require('plugin/alert');
        var $delegate = require('plugin/delegateEvent');
        var Validate = require('plugin/validate.el');

        //移除高亮
        $delegate('.form-group .form-control', {
            'keyup': function () {
                if ($.trim($(this).val()).length > 0)
                    $(this).parents('.form-group').removeClass('has-error');
            }
        });

        var myApp = ex.myApp;
        myApp.controller('commissionCtrl', function ($scope, $http) {

            var url = '/admin/store/commission/getDetail.json';
            if($.isTest)
                url = '/admin/store/getCommission.json';
            $http({
                method: 'get',
                url:url,
                headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
            }).success(function (response) {
                if (response.success) {
                    $scope.commission = response.data;
                }
            });

            $scope.save = function(){

                //验证必填
                var ipt = $('.form-control');
                for (var i = 0; i < ipt.length; i++) {
                    var el = ipt.eq(i);
                    if (el.val().length == 0) {
                        el.focus().parents('.form-group').addClass('has-error');
                        new Alert(el.attr('placeholder') || el.attr('info') + '不能为空', 'warning');
                        return;
                    }
                }

                var resManagerRate = Validate.checkformat('[name="managerRate"]','number');
                var resUserRate = Validate.checkformat('[name="userRate"]', 'number');
                if (!resManagerRate.res || !resUserRate.res){
                    new Alert('店长或者店员提成比例格式不正确，请输入数字类型', 'warning');
                    return;
                }


                $http({
                    method: 'POST',
                    url: '/admin/store/commission/update',
                    data: $.param($scope.commission),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
                }).success(function (response) {
                    if (response.success) {
                        new Alert(response.data, 'success');
                    } else
                        new Alert(response.data, 'danger');
                });
            }
        })
    })
})
