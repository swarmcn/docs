define(function (require, exports, module) {
    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;
        require('token');//令牌，POST时必须调用
        require('pagination');
        $.base64 = require('plugin/encrypt/base64');
        var Alert = require('plugin/alert');
        var getQueryString = require('plugin/getQueryString');

        myApp.controller('userCtrl', function ($scope, $http, $timeout) {
            $scope.shopId = getQueryString('shopId');
            $scope.hostname = location.host;
            //获取门店列表
            var url = "/admin/store/getList.json";
            $.get(url, function (response) {
                if (response.success) {
                    $scope.shopList = response.data;
                    $scope.shopId = $scope.shopId || $scope.shopList[0].id;
                    $scope.shopName = $scope.shopList[0].name;
                    $scope.search($scope.shopId);
                }
            });


            //拷贝链接
            $scope.initClipboard = function () {
                seajs.use('plugin/zeroClipboard/ZeroClipboard.min', function () {
                    $('.clipboard').each(function () {
                        // 定义一个新的复制对象
                        var clip = new ZeroClipboard(this, {
                            moviePath: "/resources/plugin/zeroClipboard/ZeroClipboard.swf"
                        });

                        // 复制内容到剪贴板成功后的操作
                        clip.on('complete', function (client, args) {
                            new Alert("复制成功，请粘贴（Ctrl + V）", 'success');
                        });
                    });
                });
            };

            ////店员ID64位加密
            $scope.base64Encode = function(userId){
                if(userId){
                    userId = $.base64.encode(userId + '|' + userId);
                    return userId;
                }
            };




            //初始化分页
            $scope.pageSize = 10;

            //门店店员列表
            $scope.search = function (shopId, pageNumber) {
                pageNumber = pageNumber || 1;
                $scope.page = pageNumber;

                var url = "/admin/store/user/getList.json";
                $http.get(url, {
                    params: {
                        storeId: shopId || $('[name="shopId"]').val(),
                        mobile: $scope.mobile,
                        username: $scope.username,
                        pageNumber: pageNumber,
                        pageSize: $scope.pageSize,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.userList = response.data;

                        $scope.totalCount = response.totalCount;
                        $timeout(function () {
                            $scope.initClipboard();
                            $('.user .pagination').pagination({
                                currentPage: pageNumber,
                                items: $scope.totalCount,
                                itemsOnPage: $scope.pageSize,
                                displayedPages: 3,
                                prevText: '上一页',
                                nextText: '下一页',
                                cssStyle: 'bootstrap-theme',
                                onPageClick: function (pageNumber) {
                                    $scope.search(shopId, pageNumber);
                                }
                            });
                            $.initDropdown();
                        }, 100);
                    }
                });
            };


            //设为店长
            $scope.setManager = function (x) {
                var storeId = $('[name="shopId"]').val();
                $http({
                    method: 'POST',
                    url: '/admin/store/user/setManager',
                    data: $.param({
                        id: x.id,
                        storeId: storeId
                    }),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
                }).success(function (response) {
                    if (response.success)
                        $scope.search(storeId, $scope.page);
                    else
                        new Alert(response.data, 'danger');
                });
            };

            //激活和锁定店员
            $scope.toggle = function (x) {
                if ($.isTest)
                    x.enabled = !x.enabled;

                $http({
                    method: 'POST',
                    url: '/admin/store/user/toggle',
                    data: $.param({
                        id: x.id,
                        enabled: !x.enabled
                    }),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
                }).success(function (response) {
                    if (response.success) {
                        x.enabled = !x.enabled;
                        new Alert(response.data, 'success');
                    }
                    else
                        new Alert(response.data, 'danger');
                });
            };
        })


    })
})