define(function (require, exports, module) {
    var status = {
        "status": {
            "success": "成功",
            "refuse": "拒绝",
            "accepting": "受理中"
        }
    };
    return status;
});
