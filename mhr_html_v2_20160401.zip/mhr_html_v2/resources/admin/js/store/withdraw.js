define(function (require, exports, module) {
    seajs.use('admin', function (ex) {
        require('token');
        require('pagination');
        var Alert = require('plugin/alert');
        var status = require('admin/js/store/status');

        var myApp = ex.myApp;
        myApp.controller('withdrawCtrl', function ($scope,$http,$timeout) {
            //门店列表
            var url = '/admin/store/getList.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.storeList = response.data;
                }
            });
            
            //提现列表
            $scope.getList = function (pageNumber) {
                //初始化分页
                $scope.pageSize = 10;
                pageNumber = pageNumber || 1;
                $scope.pageNumber = pageNumber;
                $http({
                    method: 'get',
                    url: '/admin/store/withdraw/getList.json',
                    params: {
                        storeId: $scope.storeId || $('[name="storeId"]').val(),
                        mobile: $scope.mobile,
                        pageNumber: pageNumber,
                        pageSize: $scope.pageSize,
                        stamp: new Date().getTime()
                    },
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
                }).success(function (response) {
                    if (response.success) {
                        $scope.withdrawList = response.data;
                        $scope.totalCount = response.totalCount;
                        $scope.wdStatus = status;
                        $timeout(function () {
                            $('.pagination').pagination({
                                currentPage: pageNumber,
                                items: $scope.totalCount,
                                itemsOnPage: $scope.pageSize,
                                displayedPages: 3,
                                prevText: '上一页',
                                nextText: '下一页',
                                cssStyle: 'bootstrap-theme',
                                onPageClick: function (pageNumber) {
                                    $scope.getList(pageNumber);
                                }
                            });
                        }, 100);
                    }
                });
            };
            $scope.getList();


            //显示弹窗
            $scope.showModal = function (x) {
                $scope.id = null;
                $scope.status = null;
                if (x) {
                    $scope.id = x.id;
                }
            };

            //审核
            $scope.audit = function () {
                if(!$scope.status){
                    new Alert("请选择审核状态！", 'warning');
                    return;
                }
                else if($scope.status == 'false' && !$scope.reason){
                    new Alert("请说明拒绝原因！", 'warning');
                    $('[name="reason"]').focus();
                    return;
                }

                $http({
                    method: 'POST',
                    url: '/admin/store/withdraw/check',
                    data: $.param({
                        id: $scope.id,
                        pass: $scope.status,
                        reason: $scope.reason
                    }),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
                }).success(function (response) {
                    if (response.success) {
                        $.each($scope.withdrawList, function (n, x) {
                            if ($scope.id == x.id) {
                                x.status = $scope.status ? 'refuse':'success';
                            }
                        });
                        $('#myModal').modal('hide');
                        new Alert(response.data, 'success');
                        $('[name="reason"]').val(null);
                    }
                    else
                        new Alert(response.data, 'danger');
                })
            }
        })
    })
})
