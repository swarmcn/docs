define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('plugin/jquery-ui/jquery-ui.css');
    require('plugin/validate.el');

    var Alert = require('plugin/alert');
    var getQueryString = require('plugin/getQueryString');

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('siteMapCtrl', function ($scope, $http, $timeout) {
            $scope.headers = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'};

            //初始化排序
            $scope.initSort = function (obj, level) {
                seajs.use('plugin/jquery-ui/jquery-ui-1.11.4', function () {
                    var moveIndex, stopIndex,newData;
                    $(obj).sortable({
                        placeholder: "bg-warning",
                        revert: true,
                        opacity: 0.5,
                        distance: 30,
                        cursor: "move",
                        axis: "y",
                        start: function () {
                            moveIndex = stopIndex = -1;
                        },
                        sort: function (event, ui) {
                            $('tr.ui-sortable-helper', obj).addClass('moving');
                            moveIndex = $('tr.ui-sortable-helper', obj).index();

                            //拖动时定宽
                            $('thead th', $(obj).parent()).each(function (index) {
                                $('tr.ui-sortable-helper td', $(obj).parent()).eq(index).width($(this).width())
                            });
                        },
                        stop: function (event, ui) {
                            //更新序号
                            $('tr.ng-scope', obj).each(function (index) {
                                var id = $(this).attr('menuId');
                                var oldNum = parseInt($('td:eq(0)', this).text());
                                $('td:eq(0)', this).text(index + 1);
                                //if (id && oldNum != index + 1) {
                                $.post('/admin/menu/sort', {
                                    id: id,
                                    sortNo: index + 1,
                                    level: level,
                                    stamp: new Date().getTime()
                                }, 'json');
                                //}
                            });

                            //初始化被移动的json对象
                            stopIndex = $('tr.ng-scope.moving', obj).index();
                            $('tr.ng-scope.moving', obj).removeClass('moving');
                            if(level == 1) {
                                newData = $scope.levelOneList[moveIndex];
                                $scope.levelOneList.splice(moveIndex, 1);
                                $scope.levelOneList.splice(stopIndex, 0, newData);
                            }
                            else{
                                newData = $scope.levelTwoList[moveIndex];
                                $scope.levelTwoList.splice(moveIndex, 1);
                                $scope.levelTwoList.splice(stopIndex, 0, newData);
                            }
                        }
                    });
                })
            };

            //一级栏目
            var url = '/admin/menu/getList.json';
            if ($.isTest)
                url = '/admin/system/menu/getList.json';
            $http.get(url + '?stamp=' + new Date().getTime()).success(function (response) {
                if (response.success) {
                    $scope.levelOneList = response.data || [];
                    $timeout(function () {
                        $('#level1 .ng-hide').remove();
                        $scope.initSort('#level1 tbody', 1);
                        if ($scope.levelOneList && $scope.levelOneList.length > 0)
                            $scope.getLevelTwoList($scope.levelOneList[0].id, $scope.levelOneList[0].items || []);
                    }, 100);
                }
            });

            //显示二级栏目
            $scope.getLevelTwoList = function (parentId, data) {
                $('#level1 [menuId]').removeClass('bg-info');
                $('#level1_' + parentId).addClass('bg-info');
                $scope.parentId = parentId;
                $scope.levelTwoList = [];
                if (data) {
                    //alert(1);
                    $scope.levelTwoList = data;
                    $timeout(function () {
                        $scope.initSort('#level2 tbody', 2);
                    }, 100)
                } else {
                    var url = '/admin/menu/getList.json';
                    if ($.isTest)
                        url = '/admin/system/menu/getList.json';
                    $http.get(url + '?parentId=' + parentId + '&stamp=' + new Date().getTime()).success(function (response) {
                        if (response.success) {
                            $scope.levelTwoList = response.data || [];
                            $timeout(function () {
                                $scope.initSort('#level2 tbody', 2);
                            }, 100)
                        }
                    });
                }
            };

            //显示弹窗
            $scope.showModal = function (level, x) {
                $('.form-group').removeClass('has-error');
                $scope.menu = {
                    level: level,
                    id: null,
                    parentId: null || (level > 1 ? $scope.parentId : null),
                    icon: null,
                    name: null,
                    url: null,
                    path: null,
                    authority: null
                };
                if (x) {
                    $scope.menu.id = x.id;
                    $scope.menu.icon = x.icon;
                    $scope.menu.name = x.name;
                    if (level > 1) {
                        $scope.menu.parentId = x.parentId;
                        $scope.menu.path = x.path;
                        $scope.menu.url = x.url;
                        $scope.menu.authority = x.authority;
                    }
                }
            };

            //保存
            $scope.saveLevel = function () {

                var isErr = false;
                $('.form-control:not(:hidden)').each(function () {
                    var val = $.trim($(this).val());
                    if (!val) {
                        if (!isErr)
                            $(this).focus();
                        $(this).parents('.form-group').addClass('has-error');
                        isErr = true
                    }
                });
                if (isErr)
                    return;

                if ($scope.menu.level == 1) {//一级
                    $http({
                        method: 'POST',
                        url: '/admin/menu/' + ($scope.menu.id ? 'update' : 'add'),
                        data: $.param({
                            id: $scope.menu.id,
                            name: $scope.menu.name,
                            icon: $scope.menu.icon
                        }),
                        headers: $scope.headers
                    }).success(function (response) {
                        if (response.success) {
                            if ($scope.menu.id) {//编辑
                                $.each($scope.levelOneList, function (n, x) {
                                    if ($scope.menu.id == x.id) {
                                        x.icon = $scope.menu.icon;
                                        x.name = $scope.menu.name;
                                    }
                                });
                            } else {//新增
                                $scope.levelOneList.push({
                                    id: response.data,
                                    name: $scope.menu.name,
                                    icon: $scope.menu.icon,
                                    itemCount: 0
                                });
                            }
                            $('#myModalLevel').modal('hide');
                        } else
                            new Alert(response.data, 'danger');
                    });
                } else {//二级
                    $http({
                        method: 'POST',
                        url: '/admin/menu/' + ($scope.menu.id ? 'updateItem' : 'addItem'),
                        data: $.param({
                            id: $scope.menu.id,
                            parentId: $scope.menu.parentId,
                            name: $scope.menu.name,
                            icon: $scope.menu.icon,
                            url: $scope.menu.url,
                            authority: $scope.menu.authority || '#',
                            path: $scope.menu.path
                        }),
                        headers: $scope.headers
                    }).success(function (response) {
                        if (response.success) {
                            if ($scope.menu.id) {//编辑
                                $.each($scope.levelTwoList, function (n, x) {
                                    if ($scope.menu.id == x.id) {
                                        x.icon = $scope.menu.icon;
                                        x.name = $scope.menu.name;
                                        x.url = $scope.menu.url;
                                        x.authority = $scope.menu.authority;
                                        x.path = $scope.menu.path;
                                    }
                                });
                            } else {//新增
                                var pt = $('#level1_' + $scope.menu.parentId);
                                $('.count', pt).text(parseInt($('.count', pt).text()) + 1);
                                $('[data-target="#myModalDel"]', pt).remove();
                                $scope.levelTwoList.push({
                                    id: response.data,
                                    parentId: $scope.menu.parentId,
                                    name: $scope.menu.name,
                                    icon: $scope.menu.icon,
                                    url: $scope.menu.url,
                                    authority: $scope.menu.authority,
                                    path: $scope.menu.path
                                });
                            }
                            $('#myModalLevel').modal('hide');
                        } else
                            new Alert(response.data, 'danger');
                    });
                }
            };

            //删除确认框
            $scope.deleteModal = function (level, x) {
                $scope.menu = {
                    level: level,
                    id: x.id,
                    name: x.name
                };
            };

            //删除栏目
            $scope.deleteLevel = function () {
                $http({
                    method: 'POST',
                    url: '/admin/menu/delete',
                    data: $.param({
                        id: $scope.menu.id,
                        level: $scope.menu.level
                    }),
                    headers: $scope.headers
                }).success(function (response) {
                    if (response.success) {
                        $('#myModalDel').modal('hide');
                        $('#level' + $scope.menu.level + '_' + $scope.menu.id).fadeOut(1000, function () {
                            $(this).remove();
                        });
                    } else
                        new Alert(response.data, 'danger');
                });
            }
        });
    });
});