define(function (require, exports, module) {
    require('angularJs');

    require('token');//令牌，POST时必须调用
    var Alert = require('plugin/alert');

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('ERPCtrl', function ($scope, $http, $timeout) {
            $scope.nullTime = '';

            var url = "/admin/erpSynchro/list.json";
            if($.isTest)
                url = "/admin/system/erpSynchro/list.json";
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.erpList = response.data;
                }
            });

            //更新
            $scope.edit = function (el, x) {
                $http({
                    method: 'POST',
                    url: '/admin/erpSynchro/update.json',
                    data: $.param({
                        tagid: x.tagid
                    }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
                }).success(function (response) {
                    if (response.success) {
                        new Alert(response.data, 'success');
                        x.lasttime = response.lasttime;
                        x.success = response.success;
                        x.nullTime = false;
                    }
                    else
                    {
                        new Alert(response.data, 'error');
                        x.nullTime = true;
                    }


                });
            }
        })
    })
})