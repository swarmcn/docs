define(function (require, exports, module) {
    require('jquery');
    require('pagination');
    require('plugin/lightbox/js/lightbox.min');
    require('plugin/jquery-ui/jquery-ui.css');

    var UploadFile = require('plugin/upload');
    var Alert = require('plugin/alert');
    var getQueryString = require('plugin/getQueryString');
    var $delegate = require('plugin/delegateEvent');
    var pageSize = 10;

    // 对Date的扩展，将 Date 转化为指定格式的String
    Date.prototype.Format = function (fmt) {
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    };

    //移除高亮
    $delegate('.form-group .form-control', {
        'keyup': function () {
            if ($.trim($(this).val()).length > 0)
                $(this).parents('.form-group').removeClass('has-error');
        }
    });

    //关键字搜索商品/jquery-ui/autocomplete
    $delegate('#key-product', {
        'focus': function () {
            var el = $(this);
            if (!el.hasClass('ui-autocomplete-input')) {
                seajs.use('plugin/jquery-ui/jquery-ui-1.11.4', function () {
                    window.productList = [];
                    el.autocomplete({
                        minLength: 1,
                        source: function (request, response) {
                            var term = request.term;
                            $.getJSON("/product/getProductList.json", {
                                keyword: term,
                                pageNumber: 1,
                                pageSize: 10,
                                stamp: new Date().getTime()
                            }, function (data, status, xhr) {
                                if (data.success && data.totalCount > 0) {
                                    response($.map(data.data, function (item) {
                                        return {
                                            term: term,
                                            label: item.fullName,
                                            value: item.fullName,
                                            id: item.id,
                                            imgUrl: item.mediumUrl
                                        }
                                    }));
                                }
                                else {
                                    response([{
                                        term: term,
                                        label: '没有找到与“' + term + '”相关的商品',
                                        disabled: true
                                    }]);
                                }
                            });
                        },
                        select: function (event, ui) {
                            var $tbody = $('.select-product-box tbody');
                            if (ui.item.id && !$('#trP' + ui.item.id, $tbody)[0]) {
                                window.productList.push(ui.item);
                                var tr = '<tr id="trP' + ui.item.id + '"><td>' + ui.item.id + '</td>' +
                                    '<td><a href="' + ui.item.imgUrl + '" target="_blank">' +
                                    '<img style="width:16px;" src="' + ui.item.imgUrl + '"></a></td>' +
                                    '<td>' + ui.item.value + '</td></tr>';
                                $tbody.append(tr);
                            }
                            setTimeout(function () {
                                el.val('').focus();
                            }, 100);
                        }
                    }).data("ui-autocomplete")._renderItem = function (ul, item) {
                        return $("<li>").addClass(item.disabled ? 'ui-state-disabled' : '')
                            .append("<a>" + item.label.replace(item.term, '<font color="red">' + item.term + '</font>') + "</a>")
                            .appendTo(ul);
                    };
                })
            }
        }
    });

    //编辑器
    seajs.use('admin/editor/kindeditor', function () {
        var setting = {
            uploadImageExtension: "jpg,jpeg,bmp,gif,png",
            uploadFlashExtension: "swf,flv",
            uploadMediaExtension: "swf,flv,mp3,wav,avi,rm,rmvb",
            uploadFileExtension: "zip,rar,7z,doc,docx,xls,xlsx,ppt,pptx"
        };

        if (typeof(KindEditor) != "undefined") {
            // 自定义插件 #1 insertPro
            KindEditor.plugin('insertPro', function (K) {
                var self = this, name = 'insertPro';
                self.clickToolbar(name, function () {
                    var dialog = new KindEditor.dialog({
                        width: 500,
                        height: 400,
                        title: '选择要插入的商品',
                        body: '<div class="select-product-box">' +
                        '<input type="text" autofocus autocomplete="off" id="key-product" placeholder="请输入关键字搜索商品">' +
                        '<table class="table table-bordered table-hover table-condensed" style="font-size: 12px;"><thead><tr><th width="55">编号</th><th width="55">图片</th><th>名称</th></tr></thead><tbody></tbody></table></div>',
                        closeBtn: {
                            name: '关闭',
                            click: function (e) {
                                dialog.remove();
                                window.productList = [];
                            }
                        },
                        yesBtn: {
                            name: '确定',
                            click: function (e) {
                                //console.log(window.productList);
                                var html = '';
                                $.each(window.productList, function (n, x) {
                                    html += '<img class="ke-product" style="width:64px; margin:5px;border: 1px solid #000000;" ' +
                                        'src="' + x.imgUrl + '" title="' + x.value + '" data-id="' + x.id + '">'
                                });
                                self.insertHtml(html);
                                window.productList = [];
                                dialog.remove();
                            }
                        },
                        noBtn: {
                            name: '取消',
                            click: function (e) {
                                dialog.remove();
                                //window.productList = [];
                            }
                        }
                    });

                    //绑定缓存的商品
                    if (window.productList && window.productList.length > 0) {
                        var $tbody = $('.select-product-box tbody');
                        $.each(window.productList, function (n, x) {
                            if (!$('#trP' + x.id, $tbody)[0]) {
                                //window.productList.push(x);
                                var tr = '<tr id="trP' + x.id + '"><td>' + x.id + '</td>' +
                                    '<td><a href="' + x.imgUrl + '" target="_blank">' +
                                    '<img style="width:16px;" src="' + x.imgUrl + '"></a></td>' +
                                    '<td>' + x.value + '</td></tr>'
                                $tbody.append(tr);
                            }
                        });
                    }
                });
            });

            KindEditor.ready(function (K) {
                window.editor = K.create("#content", {
                    resizeType: 1,
                    autoHeightMode: true,
                    newlineTag: 'br',
                    items: [
                        "undo", "redo", "|", "plainpaste", "wordpaste", "clearhtml", "removeformat", "|", "justifyleft", "justifycenter", "justifyright",
                        "justifyfull", "insertorderedlist", "insertunorderedlist", "indent", "outdent", "subscript",
                        "superscript", "|", "insertPro", "/",
                        "formatblock", "fontsize", "|", "forecolor", "bold", "italic", "underline", "strikethrough",
                        "lineheight", "|", "image",
                        "flash", "media", "insertfile", "|", "fullscreen", "preview", "source","link","unlink"
                    ],
                    langType: 'zh_CN',
                    syncType: "form",
                    filterMode: false,
                    pagebreakHtml: '<hr class="pageBreak" \/>',
                    allowFileManager: true,
                    filePostName: "file",
                    fileManagerJson: "/admin/file/browser",
                    uploadJson: "/admin/file/upload",
                    uploadImageExtension: setting.uploadImageExtension,
                    uploadFlashExtension: setting.uploadFlashExtension,
                    uploadMediaExtension: setting.uploadMediaExtension,
                    uploadFileExtension: setting.uploadFileExtension,
                    extraFileUploadParams: {
                        token: $.cookie("token")
                    },
                    afterChange: function () {
                        this.sync();
                    }
                });
            });
        }
    });

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;
        var headers = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'};

        myApp.controller('ListCtrl', function ($scope, $http, $timeout) {
            $scope.keyword = getQueryString('keyword');
            $scope.typeId = getQueryString('typeId');
            $scope.pageSize = pageSize;

            //搜索
            $scope.search = function () {
                $scope.typeId = $('.page-header [name="typeId"]').val();
                location.href = '?typeId=' + $scope.typeId + '&keyword=' + encodeURI($scope.keyword);
            };

            //获取分类列表
            var url = '/admin/theme/type/getList.json';
            if ($.isTest)
                url = '/weixin/theme/getType.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.typeList = response.data;
                }
            });

            //开关主题
            $scope.toggle = function (x) {
                $http({
                    method: 'POST',
                    url: '/admin/theme/handle',
                    data: $.param({
                        id: x.id,
                        enabled: !x.enabled
                    }),
                    headers: headers
                }).success(function (response) {
                    if (response.success) {
                        x.enabled = !x.enabled;
                        new Alert(response.data, 'success');
                    }
                    else
                        new Alert(response.data, 'danger');
                });
            };

            //获取主题列表
            $scope.getList = function (pageNumber) {
                pageNumber = pageNumber || 1;
                $scope.pageNumber = pageNumber;
                $http.get('/admin/theme/getList.json', {
                    params: {
                        keyword: $scope.keyword,
                        typeId: $scope.typeId,
                        pageNumber: pageNumber,
                        pageSize: pageSize,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.themeList = response.data;
                        $scope.totalCount = response.totalCount;

                        $timeout(function () {
                            $('.pagination').pagination({
                                currentPage: pageNumber,
                                items: $scope.totalCount,
                                itemsOnPage: pageSize,
                                displayedPages: 3,
                                prevText: '上一页',
                                nextText: '下一页',
                                cssStyle: 'bootstrap-theme',
                                onPageClick: function (pageNumber) {
                                    $scope.getList(pageNumber);
                                }
                            });
                        }, 100);
                    }
                });
            };
            $scope.getList(1);
        });

        myApp.controller('DetailCtrl', function ($scope, $http, $timeout) {
            $scope.themeId = getQueryString('id');
            $scope.token = $.cookie('token') || 0;
            if ($scope.themeId) {
                document.title = '编辑主题 - 美日惠运营后台';
                $('.page-header').text('编辑主题');
            } else {
                document.title = '添加主题 - 美日惠运营后台';
                $('.page-header').text('添加主题');
            }

            //获取分类列表
            var url = '/admin/theme/type/getList.json';
            if ($.isTest)
                url = '/weixin/theme/getType.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.typeList = response.data;
                }
            });

            //绑定上传
            function initUploadFile(obj) {
                new UploadFile(obj, function (data, el) {
                    var res = {};
                    try {
                        res = eval('(' + data + ')');
                    } catch (e) {

                    }
                    if ($.isTest)
                        res.url = 'http://www.365meirihui.com/resources/images/active/guoqing-2015/banner.jpg';
                    if (res.url) {
                        $('.input-group > .imgUrl', el).val(res.url);
                        $('.input-group > a', el).attr('href', res.url);
                        $('.input-group > a > img', el).attr('src', res.url);
                        new Alert((res.message && res.message.content) || '上传成功', "success");
                    } else {
                        new Alert((res.message && res.message.content) || '404', "error");
                    }
                });
            }

            initUploadFile('.upload-largeUrl');
            initUploadFile('.upload-thumbnailUrl');

            //初始化开关
            function bootstrapSwitch() {
                seajs.use('plugin/bootstrap-switch/js/bootstrap-switch.min', function () {
                    $("input[type=\"checkbox\"]").show().bootstrapSwitch();
                });
            }

            $scope.theme = {
                issueDate: new Date().Format("yyyy-MM-dd")//初始时间
            };
            if (!$scope.themeId) {
                bootstrapSwitch();
            } else {
                url = '/admin/theme/getDetail.json';
                if ($.isTest)
                    url = '/theme/getDetail.json';
                $http.get(url + '?id=' + $scope.themeId).success(function (response) {
                    if (response.success) {
                        $scope.theme = response.data;
                        $scope.theme.id = $scope.themeId;

                        //格式化时间
                        if ($scope.theme.issueDate)
                            $scope.theme.issueDate = new Date($scope.theme.issueDate).Format("yyyy-MM-dd");

                        if ($scope.theme.productItems && $scope.theme.productItems.length > 0) {
                            //获取商品信息
                            function getProduct(id) {
                                var p = {};
                                $.each($scope.theme.productItems, function (n, x) {
                                    if (x.id == id) p = x;
                                });
                                return p;
                            }

                            //组装商品集合
                            var $temp = $('.temp-content').html($scope.theme.content);
                            $('div.productItems', $temp).each(function () {
                                var el = $(this);
                                var pids = el.text().replace(/}{/g, ',').replace(/}|{/g, '').split(',');
                                el.text('');
                                for (var i = 0; i < pids.length; i++) {
                                    var x = getProduct(pids[i]);
                                    el.append('<img class="ke-product" style="width:64px; margin:5px;border: 1px solid #000000;" ' +
                                        'src="' + x.mediumUrl + '" title="' + x.name + '" data-id="' + x.id + '">')
                                }
                                el.after(el.html()).remove();
                            });
                            $scope.theme.content = $temp.html();
                        }

                        $timeout(function () {
                            bootstrapSwitch();
                            window.editor.html($scope.theme.content);
                        }, 100);
                    }
                });
            }

            //保存主题
            $scope.save = function () {
                //验证必填
                var ipt = $('.form-control:not([empty])');
                for (var i = 0; i < ipt.length; i++) {
                    var el = ipt.eq(i);
                    if (el.val().length == 0) {
                        el.focus().parents('.form-group').addClass('has-error');
                        new Alert(el.attr('placeholder') || el.attr('info') + '不能为空', 'warning');
                        return;
                    }
                }

                $scope.theme.content = $('#content').val();

                //获取商品id集合
                var $temp = $('.temp-content').html($scope.theme.content);
                var $img = $('img.ke-product', $temp);
                var $products = [];
                $img.each(function (index) {
                    var el = $(this);
                    var pid = el.data('id');
                    if (!el.parent().hasClass('productItems') && !el.prev().hasClass('productItems') && !el.next().hasClass('productItems')) {
                        if ($products.indexOf(pid) == -1)
                            $products.push(pid);
                        el.wrap('<div class="productItems">{' + pid + '}</div>');
                        el.remove();
                    } else {
                        var $list = el.prev('.productItems');
                        var pIds = $list.text();
                        if (pIds.indexOf('{' + pid + '}') == -1) {
                            if ($products.indexOf(pid) == -1)
                                $products.push(pid);
                            pIds += '{' + pid + '}';
                        }
                        $list.text(pIds);
                        el.remove();
                    }
                });


                function queryString(url, name) {
                    // 如果链接没有参数，或者链接中不存在我们要获取的参数，直接返回空 
                    if (url.indexOf("?") == -1 || url.indexOf(name + '=') == -1) {
                        return '';
                    }
                    // 获取链接中参数部分 
                    var queryString = url.substring(url.indexOf("?") + 1);
                    // 分离参数对 ?key=value&key2=value2 
                    var parameters = queryString.split("&");
                    var pos, paraName, paraValue;
                    for (var i = 0; i < parameters.length; i++) {
                        // 获取等号位置 
                        pos = parameters[i].indexOf('=');
                        if (pos == -1) {
                            continue;
                        }
                        // 获取name 和 value 
                        paraName = parameters[i].substring(0, pos);
                        paraValue = parameters[i].substring(pos + 1);
                        if (paraName == name) {
                            return unescape(paraValue.replace(/\+/g, " "));
                        }
                    }
                    return '';
                }
                var $link = $('a[href*="/product/detail.html?id="]',$temp);
                $link.each(function () {
                    var url = $(this).attr('href').toLowerCase();
                    var id = queryString(url,'id');
                    if ($products.indexOf(id) == -1)
                        $products.push(parseInt(id));
                })


                //参数集
                var param = {
                    largeUrl: $('[name="largeUrl"]').val(),
                    thumbnailUrl: $('[name="thumbnailUrl"]').val(),
                    title: $scope.theme.title,
                    slogan:$scope.theme.slogan,
                    summary: $scope.theme.summary,
                    content: $temp.html().replace(/\n|\r|\t/g, ''),
                    issueDate: $('[name="issueDate"]').val(),
                    'themeType.id': $('[name="typeId"]').val(),
                    enabled: $('[name="enabled"]').prop('checked'),
                    keyword: $scope.theme.keyword
                };

                //编辑时传id
                if($scope.themeId)
                    param['id'] = $scope.themeId;

                //格式商品列表参数
                $.each($products, function (n, value) {
                    param['products[' + n + '].id'] = value;
                });

                console.log($products);

                //请求接口
                $http({
                    method: 'POST',
                    url: '/admin/theme/' + ($scope.themeId ? 'update' : 'add'),
                    data: $.param(param),
                    headers: headers
                }).success(function (response) {
                    if (response.success)
                        location.href = 'index.html?ts=' + new Date().getTime();
                    else
                        new Alert(response.data, 'error');
                });
            }
        });
    });
});