define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('plugin/jquery-ui/jquery-ui.css');
    require('plugin/validate.el');

    var Alert = require('plugin/alert');
    var getQueryString = require('plugin/getQueryString');

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('themeTypeCtrl', function ($scope, $http, $timeout) {


            //获取主题分类列表
            var url = '/admin/theme/type/getList.json';
            if ($.isTest)
                url = '/theme/typeList.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.themeTypeList = response.data;
                }
            });


            //显示弹窗
            $scope.showModal = function (x) {
                $('.form-group').removeClass('has-error');
                $scope.id = null;
                $scope.sortNo = null;
                $scope.name = null;
                if (x) {
                    $scope.id = x.id;
                    $scope.sortNo = x.sortNo;
                    $scope.name = x.name;
                }
            };

            $scope.save = function () {
                var param = {
                    name: $scope.name,
                    sortNo: $scope.sortNo
                };
                if ($scope.id)
                    param['id'] = $scope.id;
                $http({
                    method: 'POST',
                    url: '/admin/theme/type/' + ($scope.id ? 'update' : 'add'),
                    data: $.param(param),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
                }).success(function (response) {
                    if (response.success) {
                        //if ($scope.id) {//编辑
                        //    $.each($scope.themeTypeList, function (n, x) {
                        //        if ($scope.id == x.id) {
                        //            x.name = $scope.name;
                        //            x.sortNo = $scope.sortNo;
                        //        }
                        //    });
                        //} else {//新增
                        //    $scope.themeTypeList.push({
                        //        id: response.data,
                        //        name: $scope.name,
                        //        sortNo: $scope.sortNo
                        //    });
                        //    $scope.id = null;
                        //    $scope.sortNo = null;
                        //    $scope.name = null;
                        //}
                        location.reload(true);
                        $('#myModalLevel').modal('hide');
                    } else
                        new Alert(response.data, 'danger');
                });
            }


        });

    });
});