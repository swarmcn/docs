define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('token');//令牌，POST时必须调用
    var form_action = require('plugin/form_action');
    var Alert = require('plugin/alert');
    var Modal = require('plugin/modal');

    var $addressForm = $('#mJJForm');
    require('plugin/jquery-ui/jquery-ui.css');

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;



        myApp.controller("ManJianCtrl", function ($scope,$http,$timeout) {

            $scope.getList= function () {
                var url = '/admin/fullSubtract/getList.json';
                if (location.hostname == 'localhost')
                    url = '/admin/marketing/getList.json';

                $http.get(url).success(function (response) {
                    if(response.success){
                        $scope.fullCut = response.data;
                    }
                })
            }
            $scope.getList();


            ////开始结束时间插件
            //$scope.initDatepicker = function () {
            //    seajs.use(['plugin/jquery-ui/jquery-ui-1.11.4','plugin/jquery-ui/timepicker-addon'], function () {
            //        $('[name="beginDate"]').prop('readOnly', true).datetimepicker({
            //            changeYear: true,
            //            changeMonth: true,
            //            showOtherMonths: true,
            //            selectOtherMonths: true,
            //            dateFormat: "yy-mm-dd",
            //            timeFormat: "HH:mm:ss",
            //            onClose: function (selectedDate) {
            //                $('[name="endDate"]').datetimepicker("option", "minDate", selectedDate);
            //            }
            //        });
            //        $('[name="endDate"]').prop('readOnly', true).datetimepicker({
            //            changeYear: true,
            //            changeMonth: true,
            //            showOtherMonths: true,
            //            selectOtherMonths: true,
            //            dateFormat: "yy-mm-dd",
            //            timeFormat: "HH:mm:ss",
            //            onClose: function (selectedDate) {
            //                $('[name="beginDate"]').datetimepicker("option", "maxDate", selectedDate);
            //            }
            //        });
            //    });
            //}




            //是否启用满减
            $scope.update = function (x) {
                var enabled;
                if(x.enabled == true)
                    enabled = false;
                else
                    enabled = true;
                $http({
                    method: 'POST',
                    url: '/admin/fullSubtract/handle',
                    data: $.param({
                        id: x.id,
                        enabled: enabled
                    }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
                }).success(function (response) {
                    if (response.success) {
                        x.enabled = enabled;
                        new Alert(response.data,'success');

                    }else{
                        new Alert(response.data,'error');
                    }
                });
            };

            //删除满减
            $scope.delFull=function(event,x,fullAmount){
                event = event.target;
                var pt = $(event).parents('tr').eq(0);
                $http({
                    method: 'POST',
                    url: '/admin/fullSubtract/deleteItem',
                    data: $.param({
                        id: x.id,
                        fullAmount: fullAmount
                    }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
                }).success(function (response) {
                    if (response.success) {
                        new Alert(response.data,'success');
                        pt.fadeOut(500, function () {
                            $(this).remove();
                        });
                    } else {
                        new Alert(response.data,'error');
                    }
                });
            }




            //添加满减规格
            $scope.fullEdit = function (event, x) {



                var el = $(event.target);
                var isUpdate = x != null;
                if(isUpdate)
                    var tr = $('#fullSubtract'+x.id);
                var body = '<div class="mb5"><input type="hidden" name="id" formtype="val_item" empty="true" value="' + (x.id) + '">' +
                    '<div class="form-group form-group-sm"><label><i class="fa fa-asterisk text-danger"></i>&nbsp;满多少金额（包含）</label>' +
                    '<input tabindex="1" type="text" class="form-control" name="fullAmount" placeholder="请输入满多少金额（包含）" placeholders="满多少金额（包含）" formtype="val_item" ">' +
                    '<div class="form-group form-group-sm"><label><i class="fa fa-asterisk text-danger"></i>&nbsp;减多少金额（包含）</label>' +
                    '<input tabindex="1" type="text" class="form-control" name="subtractAmount" placeholder="请输入减多少金额（包含）" placeholders="减多少金额（包含）" formtype="val_item" ">'+
                    '</div>';
                var myfullAmount= new Modal(el, {
                    id: 'myfullAmount',
                    width:300,
                    marginTop: $(window).height() / 2 - 150,
                    title:'新增满减项',
                    btnText: '保存',
                    body: body
                });



                //保存
                event = event.target;
                var pt = $(event).parents('tr').eq(0);
                $('.modal-content', myfullAmount).attr({'formtype': 'form', 'action': '/admin/fullSubtract/addItem'});
                $('.btn-primary', myfullAmount).click(function () {
                    myfullAmount.modal('hide');



                    var obj = {};
                    form_action(this, function (data) {
                        obj = data;
                        return true;
                    }, function (response) {
                         if (response.success) {
                            new Alert(response.msg,'success');
                            $scope.getList();

                            //var fullAmountTR= document.getElementById('fullAmount'+ x.id).insertRow(0)
                            //var y=fullAmountTR.insertCell(0)
                            //var z=fullAmountTR.insertCell(1)
                            //y.innerHTML = '满<span>'+obj.fullAmount+'</span>减<span>'+obj.subtractAmount+'</span>';
                            ////y.innerHTML = '满<span  ng-bind="">11</span>减<span ng-bind="2">1</span>';
                            //z.innerHTML = '<i ng-click="delFull($event,x,i.fullAmount)" class="text-danger fa fa-lg fa-close " title="点击移除该满减"></i>';
                            //angular.element(document).injector().invoke(function ($compile) {
                            //    var scope=angular.element(fullAmountTR).scope();
                            //    $compile(
                            //        z
                            //    )(scope);
                            //})

                    }
                        else
                            new Alert(response.data, 'error', $('.modal-content', myfullAmount));
                    }, function (err) {
                        var msg = err.status || err;
                        new Alert(msg, 'error', $('.modal-content', myfullAmount));
                    })
                })
            };



            //新增修改活动列表
            $scope.edit = function (event, x) {

                $timeout(function () {
                    $scope.initDatepicker();
                },100)

                var el = $(event.target);
                var isUpdate = x != null;

                if(isUpdate)

                    var tr = $('#fullSubtract'+x.id);
                var body = '<input type="hidden" name="id" formtype="val_item" empty="true" value="' + (isUpdate ? x.id : '') + '">' +
                    '<div class="form-group form-group-sm"><label><i class="fa fa-asterisk text-danger"></i>&nbsp;活动名称</label>' +
                    '<input tabindex="1" type="text" class="form-control" name="name" placeholder="请输入活动名称" placeholders="活动名称" formtype="val_item" value="' + (isUpdate ? $('.name',tr).text() : '') + '"></div>' +
                    '<div class="form-group form-group-sm"><label><i class="fa fa-asterisk text-danger"></i>&nbsp;开始日期</label>' +
                    '<input tabindex="2" type="text" onfocus="WdatePicker({dateFmt:\'yyyy-MM-dd HH:mm:ss\'});" ' +
                    'class="form-control beginDate" name="beginDate" placeholder="请选择开始日期" placeholders="开始日期" formtype="val_item" value="' + (isUpdate ? $('.beginDate',tr).text() : '') + '"></div>' +
                    '<div class="form-group form-group-sm"><label><i class="fa fa-asterisk text-danger"></i>&nbsp;截止日期</label>' +
                    '<input tabindex="3" type="text" class="form-control endDate" onfocus="WdatePicker({dateFmt:\'yyyy-MM-dd HH:mm:ss\'});" ' +
                    'name="endDate" placeholder="请选择截止日期" placeholders="截止日期" formtype="val_item" value="' + (isUpdate ? $('.endDate',tr).text() : '') + '"></div>'+
                    '';
                var myStore = new Modal(el, {
                    id: 'myStore',
                    width: 400,
                    marginTop: $(window).height() / 2 - 150,
                    title: isUpdate ? '编辑满减活动' : '添加满减活动',
                    btnText: '保存',
                    body: body
                });



                //保存
                var url;
                if(x != null)
                {
                    url="/admin/fullSubtract/update";
                }
                else
                {
                    url="/admin/fullSubtract/add";
                }

                $('.modal-content', myStore).attr({'formtype': 'form', 'action':url});
                $('.btn-primary', myStore).click(function () {
                    var obj = {};
                    form_action(this, function (data) {
                        obj = data;
                        return true;
                    }, function (response) {
                        if (response.success) {
                            if(isUpdate){
                                $('.name',tr).text(obj.name);
                                $('.beginDate',tr).text(obj.beginDate);
                                $('.endDate',tr).text(obj.endDate);
                                myStore.modal('hide');
                                new Alert(response.data,'success');
                            }
                            else{
                                $scope.getList();
                            }

                        }
                        else
                            new Alert(response.data, 'error', $('.modal-content', myStore));
                    }, function (err) {
                        var msg = err.status || err;
                        new Alert(msg, 'error', $('.modal-content', myStore));
                    })
                })
            };
        })


    })


})