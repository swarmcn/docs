define(function (require, exports, module) {
    seajs.use('admin', function (ex) {
        require('pagination');
        var Alert = require('plugin/alert');
        var myApp = ex.myApp;


        myApp.controller('voucherCtrl', function ($scope, $http, $timeout) {
            $scope.nowDate = new Date().getTime();
            $scope.hostname = location.host;

            //获取优惠券列表
            $scope.getList = function (pageNumber) {
                //初始化分页
                $scope.pageSize = 10;
                pageNumber = pageNumber || 1;
                $scope.page = pageNumber;

                var url = '/admin/voucher/getList.json';
                if ($.isTest)
                    url = '/admin/marketing/voucher/getList.json';
                $http({
                    method: 'get',
                    params :({
                        pageNumber:pageNumber,
                        pageSize:$scope.pageSize
                    }),
                    url: url
                }).success(function (response) {
                    if (response.success) {
                        $scope.voucherList = response.data;
                        $scope.totalCount = response.totalCount;
                        $scope.initClipboard();
                        $timeout(function () {
                            $('.pagination').pagination({
                                currentPage: pageNumber,
                                items: $scope.totalCount,
                                itemsOnPage: $scope.pageSize,
                                displayedPages: 3,
                                prevText: '上一页',
                                nextText: '下一页',
                                cssStyle: 'bootstrap-theme',
                                onPageClick: function (pageNumber) {
                                    $scope.getList(pageNumber);
                                }
                            });
                        }, 100);
                    }
                })
            };
            $scope.getList();


            //锁定、激活优惠券
            $scope.toggle = function (x) {
                $http({
                    method: 'POST',
                    url: '/admin/voucher/toggle',
                    data: $.param({
                        id: x.id,
                        enabled: !x.enabled
                    }),
                    headers: $.headers
                }).success(function (response) {
                    if (response.success) {
                        x.enabled = !x.enabled;
                        new Alert(response.data, 'success');
                    }
                    else {
                        new Alert(response.data, 'danger');
                    }

                });
                if ($.isTest)
                    x.enabled = !x.enabled;
            };

            //拷贝链接
            $scope.initClipboard = function () {
                seajs.use('plugin/zeroClipboard/ZeroClipboard.min', function () {
                    $('.clipboard').each(function () {

                        // 定义一个新的复制对象
                        var clip = new ZeroClipboard(this, {
                            moviePath: "/resources/plugin/zeroClipboard/ZeroClipboard.swf"
                        });

                        // 复制内容到剪贴板成功后的操作
                        clip.on('complete', function (client, args) {
                            new Alert("复制成功，请粘贴（Ctrl + V）", 'success');
                        });
                    });
                });
            };

        })
    })
})