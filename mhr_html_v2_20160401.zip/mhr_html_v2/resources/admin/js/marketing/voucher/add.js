define(function (require, exports, module) {
    seajs.use('admin', function (ex) {
        var Alert = require('plugin/alert');
        var validate = require('plugin/validate.el');
        var getQueryString = require('plugin/getQueryString');
        var $delegate = require('plugin/delegateEvent');

        var myApp = ex.myApp;

        //移除高亮
        $delegate('.form-control', {
            'keyup': function () {
                if ($.trim($(this).val()).length > 0)
                    $(this).parent().removeClass('has-error');
            }
        });

        //取整
        myApp.filter(
            'to_Int', ['$sce', function ($sce) {
                return function (text) {
                    return parseInt(text);
                }
            }]
        );

        myApp.controller('voucherCtrl', function ($scope, $http, $timeout) {
            $scope.voucher = {};
            $scope.voucher.items = [];
            $scope.totalAmount = 0;
            $scope.voucher.id = getQueryString('id');

            //初始化单选按钮
            $scope.bootstrapSwitch = function () {
                $timeout(function () {
                    seajs.use('plugin/bootstrap-switch/js/bootstrap-switch.min', function () {
                        $("input[type=\"checkbox\"]").show().bootstrapSwitch();
                    });
                }, 100);
            };

            //输入时校验人民币
            $scope.regMoney = function (money) {
                var val = money;
                if (!validate.is_num(val)) {
                    var nVal = '';
                    val = val + '';
                    $.each(val.split(''), function (n, v) {
                        if (typeof v == 'number' || (v == '.' && nVal.indexOf('.') == -1))
                            nVal += v;
                    });
                    val = nVal;
                }
                var decimal = (val+'').split('.');
                if (decimal.length > 1) {
                    if (decimal[1].length > 2) {
                        val = decimal[0] + '.' + decimal[1].substr(0, 2);
                    }
                }
                return val;
            };

            //统计总额
            $scope.count = function (x) {
                if (x) {
                    x.discountAmount = $scope.regMoney(x.discountAmount) || 1;
                    x.minOrderAmount = $scope.regMoney(x.minOrderAmount) || 1;
                    if (!validate.is_num(x.quantity) || x.quantity < 1)
                        x.quantity = 1;
                }
                if ($scope.voucher.items.length > 0) {
                    $scope.totalAmount = 0;
                    $.each($scope.voucher.items, function (n, x) {
                        $scope.totalAmount += x.quantity * x.discountAmount;
                    });
                }
            };

            if ($scope.voucher.id) {
                var url = '/admin/voucher/getDetail.json';
                if ($.isTest)
                    url = '/admin/marketing/voucher/getDetail.json';
                $http({
                    method: 'get',
                    url: url + '?id=' + $scope.voucher.id
                }).success(function (response) {
                    if (response.success) {
                        $scope.voucher = response.data;
                        $scope.voucher.beginDate = new Date($scope.voucher.beginDate).Format("yyyy/MM/dd hh:mm:ss");
                        $scope.voucher.endDate = new Date($scope.voucher.endDate).Format("yyyy/MM/dd hh:mm:ss");
                        $scope.count();
                        $scope.bootstrapSwitch();
                    }
                });
            } else {
                $scope.voucher = {
                    "id": null,
                    "name": null,
                    "enabled": false,
                    "beginDate": new Date().Format("yyyy/MM/dd 00:00:00"),
                    "endDate": new Date().Format("yyyy/MM/dd 23:59:59"),
                    "items": [{
                        "discountAmount": 1,
                        "minOrderAmount": 1,
                        "quantity": 1
                    }]
                };
                $scope.count();
                $scope.bootstrapSwitch();
            }

            //添加空记录
            $scope.addItem = function () {
                $scope.voucher.items.push({
                    "discountAmount": 1,
                    "minOrderAmount": 1,
                    "quantity": 1
                });
                $scope.count();
            };

            //清空记录
            $scope.delItem = function (index) {
                console.log(index);
                if (confirm('确定删除该条记录？')) {
                    $scope.voucher.items.splice(index, 1);
                    $scope.count();
                }
            };

            //保存
            $scope.save = function () {
                var ipt = $('input.form-control:not([empty="true"])');
                for (var i = 0; i < ipt.length; i++) {
                    var el = ipt.eq(i);
                    if (el.val().length == 0) {
                        el.focus().parent().addClass('has-error');
                        new Alert(el.attr('info') || el.attr('placeholder'), 'warning');
                        return;
                    }
                }

                var $form = $('#voucherForm');
                var formData = $form.serializeObject();
                formData.enabled = $('#enabled:checked').length > 0;
                if(!$scope.voucher.id)
                    delete formData.id;
                $http({
                    method: 'POST',
                    url: '/admin/voucher/' + ($scope.voucher.id ? 'update' : 'add'),
                    data: $.param(formData),
                    headers: $.headers
                }).success(function (response) {
                    if (response.success)
                        location.href = 'index.html';
                    else
                        new Alert(response.data, 'error');
                });
            };
        });
    });
});