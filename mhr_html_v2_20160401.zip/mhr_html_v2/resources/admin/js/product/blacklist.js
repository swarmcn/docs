define(function (require, exports, module) {
    require('angularJs');
    require('token');//令牌，POST时必须调用
    require('pagination');
    var Alert = require('plugin/alert');
    var getQueryString = require('plugin/getQueryString');

    var $keyword =$('input[name="key"]');

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('blackListCtrl', function ($scope, $http, $timeout) {

            //初始化分页
            var pageSize = 10;

            //获取黑名单列表
            var url = "/admin/product/getBlacklist.json";
            if($.isTest)
                url = "/admin/product/blacklist/getBlacklist.json";

            $scope.getList = function (pageNumber) {
                pageNumber = pageNumber || 1;
                $http.get(url, {
                    params: {
                        keyword: $scope.key,
                        pageNumber: pageNumber,
                        pageSize: pageSize,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.blackList = response.data;
                        $scope.blackTotalCount = response.totalCount;
                        $timeout(function () {
                            $('.page_black .pagination').pagination({
                                currentPage: pageNumber,
                                items: $scope.blackTotalCount,
                                itemsOnPage: pageSize,
                                displayedPages: 3,
                                prevText: '上一页',
                                nextText: '下一页',
                                cssStyle: 'bootstrap-theme',
                                onPageClick: function (pageNumber) {
                                    $scope.getList(pageNumber);
                                }
                            });
                        }, 100);
                    }
                });
            };
            $scope.getList();


            //取消黑名单
            $scope.updBlack = function(x,index){
                $http({
                    method: 'POST',
                    url: '/admin/product/deleteBlackList',
                    data: $.param({id: x.id}),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
                }).success(function (response) {
                    if (response.success) {
                        if(confirm('确定删除该条记录？')) {
                            $scope.blackList.splice(index, 1);
                            $scope.blackTotalCount--;
                        }
                    }
                    else
                        new Alert(response.data, 'error');
                });
            }
        })
    })
})
