define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('date');
    var Alert = require('plugin/alert');
    var getQueryString = require('plugin/getQueryString');


    var $typeId = getQueryString('type');
    var $startTime = getQueryString('startDate');
    var $endTime = getQueryString('endDate');
    var $shopId = getQueryString('shopId');
    var startTime = '';
    var endTime = '';
    $('.highcharts-container').width('100%');

    //默认获取开始时间、结束时间
    var myDate = new Date();
    var endDate = myDate.getFullYear() + "-" + (myDate.getMonth() + 1) + "-" + myDate.getDate();
    myDate.setMonth(myDate.getMonth() - 11);
    var beginDate = myDate.getFullYear() + "-" + (myDate.getMonth() + 1) + "-01";


    //计算天数差的函数，通用
    function DateDiff(sDate1, sDate2) {    //sDate1和sDate2是2006-12-18格式
        var aDate, oDate1, oDate2, iDays
        aDate = sDate1.split("-")
        oDate1 = new Date(aDate[1] + '-' + aDate[2] + '-' + aDate[0])    //转换为12-18-2006格式
        aDate = sDate2.split("-")
        oDate2 = new Date(aDate[1] + '-' + aDate[2] + '-' + aDate[0])
        iDays = parseInt(Math.abs(oDate1 - oDate2) / 1000 / 60 / 60 / 24)    //把相差的毫秒数转换为天数
        return iDays
    }


    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('statisticsCtrl', function ($scope, $http, $timeout) {


            if ($typeId) {
                $scope.typeId = $typeId;
            }
            else {
                $scope.typeId = 'month';
            }

            if ($shopId) {
                $scope.shopID = $shopId;
            }
            else {
                $scope.shopID = '';
            }


            if ($startTime) {
                if ($scope.typeId == 'year')
                    $scope.beginDate = new Date($startTime).Format("yyyy");
                if ($scope.typeId == 'month')
                    $scope.beginDate = new Date($startTime).Format("yyyy-MM");
                if ($scope.typeId == 'day')
                    $scope.beginDate = new Date($startTime).Format("yyyy-MM-dd");
            }
            else {
                $scope.beginDate = new Date(beginDate).Format("yyyy-MM");
            }

            if ($endTime) {
                if ($scope.typeId == 'year')
                    $scope.endDate = new Date($endTime).Format("yyyy");
                if ($scope.typeId == 'month')
                    $scope.endDate = new Date($endTime).Format("yyyy-MM");
                if ($scope.typeId == 'day')
                    $scope.endDate = new Date($endTime).Format("yyyy-MM-dd");
            }
            else {
                $scope.endDate = new Date(endDate.replace(/-/g,'/')).Format("yyyy-MM");
            }


            //获取门店列表
            var url = '/storeshop/getlist.json';
            if ($.isTest)
                url = "/auth/getlist.json";
            $.get(url, function (response) {
                if (response.success) {
                    $scope.shopList = response.data;
                    $timeout(function () {
                        $scope.shopId = getQueryString('shopId');
                    }, 10)
                }
            });

            //获取列表
            $scope.getList = function () {
                startTime = new Date(beginDate).Format("yyyy-MM");
                endTime = new Date(endDate).Format("yyyy-MM");

                var url = '/admin/sales/view';
                if ($.isTest)
                    url = "/admin/statistics/sale/list.json";
                $http.get(url + '?type=' + $scope.typeId + '&startDate=' + $scope.beginDate + '&endDate=' + $scope.endDate + '&shopId=' + $scope.shopID).success(function (response) {
                    $scope.data = response.data;

                    //日期
                    var data = [];
                    $.each($scope.data, function (n, x) {
                        if ($typeId == 'year') {
                            data.push(new Date(x.date).Format("yyyy"));
                        }
                        else if ($typeId == 'month') {
                            data.push(new Date(x.date).Format("yyyy-MM"));
                        }
                        else if ($typeId == 'day') {
                            data.push(new Date(x.date).Format("yyyy-MM-dd"));
                        }
                        else {
                            data.push(new Date(x.date).Format("yyyy-MM"));
                        }
                    })

                    //商品销售量
                    var total = [];
                    $.each($scope.data, function (n, x) {
                        total.push(x.total)
                    })

                    //商品销售额
                    var amount = [];
                    $.each($scope.data, function (n, x) {
                        amount.push(parseFloat((x.amount / 10000).toFixed(4)))
                    })

                    //已支付订单数量
                    var order_quantity = [];
                    $.each($scope.data, function (n, x) {
                        order_quantity.push(x.orderquantity)
                    })


                    seajs.use('plugin/hcharts/highcharts', function () {

                        var chart;
                        var options;
                        //根据下拉选择的图表类型动态更新图表
                        $scope.updateChartType = function () {
                            $("#amount").highcharts(options);
                            chart = $('#amount').highcharts();
                            //通过遍历图表的series个数进行逐个更新
                            for (var i = 0; i < chart.series.length; i++) {
                                chart.series[i].update({
                                    type: $scope.selType,
                                    step: false
                                });
                            }

                            $("#total").highcharts(options);
                            chart = $('#total').highcharts();
                            //通过遍历图表的series个数进行逐个更新
                            for (var i = 0; i < chart.series.length; i++) {
                                chart.series[i].update({
                                    type: $scope.selType,
                                    step: false
                                });
                            }

                            $("#order_quantity").highcharts(options);
                            chart = $('#order_quantity').highcharts();
                            //通过遍历图表的series个数进行逐个更新
                            for (var i = 0; i < chart.series.length; i++) {
                                chart.series[i].update({
                                    type: $scope.selType,
                                    step: false
                                });
                            }
                        };

                        $('#amount').highcharts({
                            chart: {
                                type: 'column',
                                backgroundColor: '#ececec'
                            },
                            title: {
                                text: '销售额统计'
                            },
                            credits: {
                                enabled: false
                            },
                            xAxis: {
                                categories: data
                            },
                            yAxis: {
                                min: 0,
                                title: {
                                    text: '(万元) ',
                                    rotation: -90
                                }
                            },
                            tooltip: {
                                pointFormat: '销售额：{point.y} 万元'
                            },
                            legend: {
                                enabled: false
                            },
                            series: [{
                                name: '销售额',
                                data: amount,
                                dataLabels: {
                                    enabled: true,
                                    rotation: 0,
                                    color: '#E62121',
                                    align: 'center',
                                    x: 4,
                                    y: 10,
                                    style: {
                                        fontSize: '14px'
                                    }
                                }

                            }]
                        });
                        $('#total').highcharts({
                            chart: {
                                type: 'column',
                                backgroundColor: '#ececec'
                            },
                            title: {
                                text: '销售量统计'
                            },
                            credits: {
                                enabled: false
                            },
                            xAxis: {
                                categories: data
                            },
                            yAxis: {
                                min: 0,
                                title: {
                                    text: '(件)',
                                    rotation: -90
                                }
                            },
                            tooltip: {
                                pointFormat: '销售量：{point.y} 件'
                            },
                            legend: {
                                enabled: false
                            },
                            series: [{
                                name: '销售量',
                                data: total,
                                dataLabels: {
                                    enabled: true,
                                    rotation: 0,
                                    color: '#E62121',
                                    align: 'center',
                                    x: 4,
                                    y: 10,
                                    style: {
                                        fontSize: '14px'
                                    }
                                }
                            }]
                        });
                        $('#order_quantity').highcharts({
                            chart: {
                                type: 'column',
                                backgroundColor: '#ececec'
                            },
                            title: {
                                text: '已支付订单数量统计'
                            },
                            credits: {
                                enabled: false
                            },
                            xAxis: {
                                categories: data
                            },
                            yAxis: {
                                min: 0,
                                title: {
                                    text: '(个)',
                                    rotation: -90
                                }
                            },
                            legend: {
                                enabled: false
                            },
                            series: [{
                                name: '已支付订单数量',
                                data: order_quantity,
                                dataLabels: {
                                    enabled: true,
                                    rotation: 0,
                                    color: '#E62121',
                                    align: 'center',
                                    x: 4,
                                    y: 10,
                                    style: {
                                        fontSize: '14px'
                                    }
                                }
                            }]
                        });
                    })
                })

            }

            $scope.getList();


            //提交参数
            $scope.submit = function () {
                if ($scope.typeId == 'year') {
                    startTime = new Date($('.beginyy').val()).Format("yyyy");
                    endTime = new Date($('.endyy').val()).Format("yyyy");
                    location.href = "/admin/statistics/sale/index.html?type=" + $scope.typeId + '&startDate=' + startTime + '&endDate=' + endTime + '&shopId=' + $scope.shopId;

                }
                else if ($scope.typeId == 'month') {
                    startTime = new Date($('.beginyymm').val()).Format("yyyy-MM");
                    endTime = new Date($('.endyymm').val()).Format("yyyy-MM");
                    location.href = "/admin/statistics/sale/index.html?type=" + $scope.typeId + '&startDate=' + startTime + '&endDate=' + endTime + '&shopId=' + $scope.shopId;

                }
                else if ($scope.typeId == 'day') {
                    startTime = new Date($('.beginDate').val()).Format("yyyy-MM-dd");
                    endTime = new Date($('.endDate').val()).Format("yyyy-MM-dd");

                    //相差多少天
                    if (DateDiff(startTime, endTime) > 30) {
                        new Alert("相差" + DateDiff($('.beginDate').val(), $('.endDate').val()) + "天,请将时间范围控制在30天内哦！！！", 'error');
                        return;
                    }
                    else {
                        location.href = "/admin/statistics/sale/index.html?type=" + $scope.typeId + '&startDate=' + startTime + '&endDate=' + endTime + '&shopId=' + $scope.shopId;
                    }
                }
            }


            $scope.type = function () {
                $scope.typeId = $("#typeId option:selected").val();
                if($startTime && $startTime)
                {
                    if ($scope.typeId == 'year'){
                        $scope.beginDate = new Date($startTime).Format("yyyy");
                        $scope.endDate = new Date($endTime).Format("yyyy");
                    }

                    if ($scope.typeId == 'month'){
                        $scope.beginDate = new Date($startTime).Format("yyyy-MM");
                        $scope.endDate = new Date($endTime).Format("yyyy-MM");
                    }

                    if ($scope.typeId == 'day'){
                        $scope.beginDate = new Date($startTime).Format("yyyy-MM-dd");
                        $scope.endDate = new Date($endTime).Format("yyyy-MM-dd");
                    }

                }
                else
                {
                    if ($scope.typeId == 'year'){
                        $scope.beginDate = new Date(beginDate).Format("yyyy");
                        $scope.endDate = new Date(endDate.replace(/-/g,'/')).Format("yyyy");
                    }

                    if ($scope.typeId == 'month'){
                        $scope.beginDate = new Date(beginDate).Format("yyyy-MM");
                        $scope.endDate = new Date(endDate.replace(/-/g,'/')).Format("yyyy-MM");
                    }

                    if ($scope.typeId == 'day'){
                        $scope.beginDate = new Date(beginDate).Format("yyyy-MM-dd");
                        $scope.endDate = new Date(endDate.replace(/-/g,'/')).Format("yyyy-MM-dd");
                    }

                }
            }

            $scope.shop = function () {
                $scope.shopId = $("#shopId option:selected").val();
            }


        })

    })
})
