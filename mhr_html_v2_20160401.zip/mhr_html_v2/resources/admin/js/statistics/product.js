define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('date');
    var Alert = require('plugin/alert');
    var getQueryString = require('plugin/getQueryString');

    seajs.use('admin', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('productCtrl', function ($scope, $http, $timeout) {

            var url = '/admin/statistics/product/list.json';
            if ($.isTest)
                url = "/admin/statistics/product/list.json";
            $http.get(url + '?type=' + $scope.typeId + '&startDate=' + $scope.beginDate + '&endDate=' + $scope.endDate + '&shopId=' + $scope.shopID).success(function (response) {
                $scope.data = response.data;

                //商品销售量
                var total = [];
                var colcor;
                $.each($scope.data, function (n, x) {
                    switch (n){
                        case 0:
                            colcor = "#FF1D25";
                            break;
                        case 1:
                            colcor = "#FF931E";
                            break;
                        case 2:
                            colcor = "#7AC943";
                            break;
                        default :
                            colcor = "#DFDFDF";
                            break;
                    }
                    total.push({color:colcor,y: x.total})
                })

                //商品名称
                var name = [];
                $.each($scope.data, function (n, x) {
                    name.push(x.name)
                })

                seajs.use(['plugin/hcharts/highcharts','http://www.hcharts.cn/demo/js/exporting.js','http://www.hcharts.cn/demo/js/export-excel.js'], function () {
                    Highcharts.setOptions({
                        lang: {
                            printChart:"打印图表",
                            downloadJPEG: "下载JPEG 图片" ,
                            downloadPDF: "下载PDF文档"  ,
                            downloadPNG: "下载PNG 图片"  ,
                            downloadSVG: "下载SVG 矢量图" ,
                            exportButtonTitle: "导出图片"
                        }
                    });

                    var chart = new Highcharts.Chart({
                        chart: {
                            type: 'bar',
                            renderTo: 'container'
                        },
                        title: {
                            text: '商品销售排行榜'
                        },
                        credits: {
                            enabled: false
                        },
                        xAxis: {
                            categories: name,
                        },
                        yAxis: {
                            min: 0,
                            title: {
                                text: '',
                                align: 'high'
                            },
                            labels: {
                                format: '{value} 件'
                            }
                        },
                        tooltip: {
                            valueSuffix: '件'
                        },
                        plotOptions: {
                            bar: {
                                dataLabels: {
                                    enabled: true
                                }
                            },
                            series: {
                                animation: {
                                    duration: 2000
                                }
                            }
                        },
                        legend: {
                            enabled: false,
                            reversed : true
                        },
                        series: [{
                            name: '商品销售量',
                            data: total
                        }]
                    })

                    var each = Highcharts.each;





                    $scope.getcsv = function (){
                        chart.getCSV = function () {
                            var columns = [],
                                line,
                                tempLine,
                                csv = "",
                                row,
                                col,
                                options = (this.options.exporting || {}).csv || {},


                            // Options
                                dateFormat = options.dateFormat || '%Y-%m-%d %H:%M:%S',
                                itemDelimiter = options.itemDelimiter || ',', // use ';' for direct import to Excel
                                lineDelimiter = options.lineDelimeter || '\n';


                            each (this.series, function (series) {
                                if (series.options.includeInCSVExport !== false) {
                                    if (series.xAxis) {
                                        var xData = series.xData.slice(),
                                            xTitle = 'X values';
                                       if (series.xAxis.categories) {
                                            xData = Highcharts.map(xData, function (x) {
                                                return Highcharts.pick(series.xAxis.categories[x], x);
                                            });
                                            xTitle = '商品名称';
                                        }
                                        columns.push(xData);
                                        columns[columns.length - 1].unshift(xTitle);
                                    }
                                    columns.push(series.yData.slice());
                                    columns[columns.length - 1].unshift(series.name);
                                }
                            });

                                        //新增工作簿
                            var ExcelSheet = xlBook.Worksheets(1);

                            // Transform the columns to CSV
                            for (row =0; row < columns[0].length; row++) {
                                line = [];
                                for (col =0; col < columns.length; col++) {
                                    line.push(columns[col][row]);
                                }
                                csv += line.join(itemDelimiter) + lineDelimiter;
                            }

                            //for (var i = 0; i < seriesObj.length; i++) {
                            //    //动态设置第一列的series名称
                            //    oSheet.Cells(i + 2, 1).value = seriesObj[i].name;
                            //    //动态获取每一sereis 每一个点y轴上的数据值
                            //    for (var j = 0; j < categoriesObj.length; j++) {
                            //        oSheet.Cells(i + 2, j + 2).value = seriesObj[i].yData[j];
                            //    }
                            //}

                            return csv;
                            console.log(csv)
                        };
                        console.log(chart.getCSV());
                    }

                    $scope.download = function (){
                        Highcharts.post('http://export.hcharts.cn/cvs.php', {
                            csv: chart.getCSV()
                        });

                    }



                })
        })

       })
    })
})