/**
 * Created by sg009 on 15/六月/23.
 */
define(function (require, exports, module) {
    require('angularJs');
    require('plugin/angular/angular-route.sea.js');
    require('jquery');
    require('token');//令牌，POST时必须调用
    require('cookie');
    require('plugin/message');
    require('placeholder');

    $.timestamp = function () { return new Date().getTime(); };
    $.isTest = location.hostname == 'localhost' || location.hostname.indexOf('192.168.') > -1 || location.hostname.indexOf('172.') > -1;

    //IE9以下检测
    var b_version = navigator.appVersion;
    var version = b_version.split(";");
    if (version.length > 1) {
        var trim_Version = parseInt(version[1].replace(/[ ]/g, "").replace(/MSIE/g, ""));

        if (parseInt(trim_Version) == 9) {
            //侧边栏购物车自适应高度
            setInterval(function () {
                var sidebar = document.getElementById('sidebar');
                if (sidebar) {
                    var shop_cart_list = document.getElementById('shop_cart_list');
                    shop_cart_list.style.height = Math.max(sidebar.clientHeight, 500) + 'px';
                }
            }, 100);
        }

        if (parseInt(trim_Version) < 9) {
            window.location.href = "version.html";
        }
    }

    var setUrlParam = require('plugin/setUrlParam');
    var getQueryString = require('plugin/getQueryString');
    //var addr = require('share/js/addr');
    var $delegate = require('plugin/delegateEvent');

    //点击空白，关闭弹窗
    $(document).bind("click", function (e) {
        var target = $(e.target);//表示当前对象，切记，如果没有e这个参数，即表示整个BODY对象
        if (target.closest("#sidebar,#banner").length == 0) {
            $("#sidebar .shop_cart_list").addClass('hide');
            $("#sidebar .shopCart").removeClass('active');
            $(".quick_links_panel .themes").show();
        }
    });

    //header,weixin
    $delegate('.sn-login-info .weixin', {
        'mouseenter': function () {
            $(this).children("#ewm_Code").animate({top: 20, queue: true});
            $(this).children("#ewm_Code").css("visibility", "visible");
            $(this).children("#ewm_Code").css("display", "block");
        },
        'mouseleave': function () {
            $(this).children("#ewm_Code").css("visibility", "hidden");
            $(this).children("#ewm_Code").animate({top: -20, queue: true});
            $(this).children("#ewm_Code").css("display", "none");
        }
    });

    //sidebar,tooltip
    $delegate('.quick_links_panel li', {
        'mouseenter': function () {
            //$(this).children(".mp_tooltip").animate({
            //    left: $(this).children(".mp_tooltip").attr('on-left') || -102,
            //    queue: true
            //});
            $(this).children(".mp_tooltip").css("visibility", "visible");
            $(this).children(".ibar_login_box").css("display", "block");
        },
        'mouseleave': function () {
            $(this).children(".mp_tooltip").css("visibility", "hidden");
            //$(this).children(".mp_tooltip").animate({
            //    left: $(this).children(".mp_tooltip").attr('off-left') || -131,
            //    queue: true
            //});
            $(this).children(".ibar_login_box").css("display", "none");
        }
    });

    //sidebar,qrcode
    $delegate(".quick_toggle li", {
        'mouseenter': function () {
            $(this).children(".mp_qrcode").show();
        },
        'mouseleave': function () {
            $(this).children(".mp_qrcode").hide();
        }
    });

    $.pageLoading = function (type) {
        var $pageLoading = $('.page-loading');
        type = type || 'hide';
        if (type == 'hide')
            $pageLoading.hide();
        else
            $pageLoading.show();
    };

    // 跳转登录
    $.redirectLogin = function (redirectUrl) {
        var href = "/auth/login.html";
        if (redirectUrl != null) {
            href += "?redirectUrl=" + encodeURIComponent(redirectUrl);
        }
        location.href = href;
    };

    //表单序列化为JSON
    $.fn.serializeObject = function () {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };

    //商品搜索表单，内容为空不提交
    $delegate("#productSearchForm", {
        'submit': function () {
            event.preventDefault();
            var $keyword = $("input", this);
            if ($.trim($keyword.val()) == "" && location.href.indexOf('/product/list.html') == -1) {
                $keyword.focus();
            }
            else {
                var url = location.href;
                if (location.search) {
                    if (location.search.indexOf('page') > -1) {
                        url = setUrlParam(url, 'page', '1');
                    }
                    url = '?' + url.split('?')[1];
                    location.href = '/product/list.html' + setUrlParam(url, 'keyword', encodeURI($keyword.val()));
                }
                else {
                    location.href = '/product/list.html?keyword=' + encodeURI($keyword.val());
                }
            }
        }
    });

    //回到顶部
    $delegate(".back2top", {
        'click': function () {
            $("html, body").animate({scrollTop: 0}, 200);
        }
    });

    var winTop = $(window).scrollTop();
    if (winTop >= 90)
        $('body').addClass('sticky-header');
    $(window).scroll(function () {
        var winTop = $(window).scrollTop();
        if (winTop >= 90) {
            $('body').addClass('sticky-header');
        } else {
            $('body').removeClass('sticky-header');
        }
    });

    //数字加逗号,
    function addCommas(nStr) {
        nStr += '';
        x = nStr.split('.');
        x1 = x[0];
        x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        }
        return x1 + x2;
    }

    //初始化会员中心左边栏
    function InitMeSidebar() {
        //会员中心左侧边栏高亮
        if ($('.incl_me_sidebar')[0] && !$('.incl_me_sidebar li.active')[0]) {
            //商品分类改为点击展开，离开隐藏
            $('.shop-cate').addClass('toggle').click(function () {
                $(this).toggleClass('open');
            }).hover(null, function () {
                $(this).removeClass('open');
            });

            var thisUrl = location.href;
            $('.incl_me_sidebar li[nav]').each(function () {
                var el = $(this);
                var nav = el.attr('nav');
                if (thisUrl.indexOf(nav) > -1) {
                    $('.incl_me_sidebar li').removeClass('active');
                    el.addClass('active');

                    var url = $('a', el).attr('href');
                    $('a', el).attr('href', setUrlParam(url, 's', new Date().getMilliseconds()));
                }
            });
            clearTimeout(_InitMeSidebar);
        }
        var _InitMeSidebar = setTimeout(function () {
            InitMeSidebar();
        }, 100);
    }

    //myApp
    var myApp = angular.module("myApp", ['ngRoute']);

    //ajax请求全局配置
    myApp.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.defaults.headers.common['token'] = $.cookie('token') || 0;
        $httpProvider.defaults.headers.common['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
        $httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
    }]);

    //输出的html
    myApp.filter(
        //格式化html标签
        'to_trusted', ['$sce', function ($sce) {
            return function (text) {
                return $sce.trustAsHtml(text);
            }
        }]
    );
    myApp.filter(
        //加星，如13******88
        'to_asterisk', ['$sce', function () {
            return function (text, param1, param2, param3) {
                var len = text.length;
                param1 = param1 || 2;//头部保留数
                param2 = param2 || 2;//尾部保留数
                param3 = param3 || 6;//星号个数
                if (len > param1 + param2) {
                    var s = text.substring(0, param1);
                    var e = text.substring(len - param2, len);
                    var n = '';
                    for (var i = 0; i < Math.min(len - param1 - param2, param3); i++)
                        n += '*';
                    return s + n + e;
                }
                return text;
            }
        }]
    );
    myApp.filter(
        //截取字串加...//substring:0:10
        'substring', ['$sce', function () {
            return function (text, param1, param2) {
                param1 = param1 || 0;
                param2 = param2 || text.length;
                if (text.length > param2) {
                    return text.substring(param1, param2) + '...';
                }
                return text;
            }
        }]
    );

    //登录状态
    myApp.controller("LoginStateCtrl", function ($scope) {
        if (!$.checkLogin() && !$.isTest) { //需登录才能访问的页面
            $.removeCookie('username');
            var pathName = location.pathname;
            if ((pathName.indexOf('/member/') > -1 || pathName.indexOf('/order/') > -1) && location.hostname.indexOf('localhost') == -1) {
                $.redirectLogin(location.href);
            }
        }
        else {
            $scope.loginName = $.cookie('username');
        }
        if($.isTest)
            $scope.loginName = 13588888888;
    });



    myApp.controller("bodyCtrl", function ($scope, $http, $timeout,$interval) {
        var keyword = getQueryString('keyword');
        $scope.keyword = keyword;
        //搜索
        $scope.search = function(){
            var searchVal = $('.search-form input[name="search"]').val();
            if (searchVal)
                location.href = "/search.html?keyword="+ encodeURI(searchVal);
            else
                $('.search-form input[name="search"]').focus();
        };


        var isLocal = (location.hostname == 'localhost');

        ////获取tag主题
        //var url = '/common/getTagList.json?type=product';
        //if (isLocal)
        //    url = '/product/getTagList.json';
        //$http.get(url).success(function (response) {
        //    if (response.success) {
        //        $scope.TagList = response.data;
        //    }
        //});
        //
        ////搜索
        //$scope.recall = function () {
        //    $scope.$broadcast('recall', $('#keyword').val());
        //};
        //
        ////只在首页显示搜索框和主题锚点
        //$interval(function () {
        //    if (location.pathname == '/' || location.pathname.toLowerCase() == '/index.html') {
        //        $('#search').removeClass('ng-hide');
        //    }
        //    else {
        //        $('#helpInfo').removeClass('ng-hide');
        //    }
        //}, 100);

        //百度商桥
        $scope.qiaoBaidu = function () {
            window.open('http://webim.qiao.baidu.com//im/index?siteid=7082486&ucid=1078847', '在线咨询', 'height=600, width=800, toolbar=no, menubar=no, scrollbars=no, resizable=no, location=no, status=no');
        };

        //退出系统
        $scope.logout = function () {
            $http.get('/logout').success(function () {
                location.href = '/auth/login.html';
            }).error(function () {
                location.href = '/auth/login.html';
            });
        };

        //购物车列表不显示导航的购物车
        var path = location.pathname.toLowerCase();
        $scope.isCartList = true;
        if (path.indexOf('/cart/') != -1 || path.indexOf('/member/order/info') != -1 || path.indexOf('/member/order/detail') != -1) {
            $scope.isCartList = false;
        }

        $scope.searchKeyword = decodeURI(getQueryString('keyword'));
        if ($scope.isCartList) {
            //统计数量
            $scope.cartNum = 0;

            //统计金额
            $scope.totalPrice = function () {
                var effectivePrice = 0.00;
                var effectivePriceCNY = 0.00;
                if ($scope.cartList && $scope.cartList.length > 0) {
                    $.each($scope.cartList, function (n, v) {
                        var x = $scope.cartList[n];
                        if (!x.isDel) {
                            effectivePrice += x.price * x.quantity;
                            effectivePriceCNY += x.price * x.quantity;
                        }
                    });
                    $('.cart-total .effectivePrice').text('$' + addCommas(effectivePrice.toFixed(2)));
                    $('.cart-total .effectivePriceCNY').text(addCommas(effectivePriceCNY.toFixed(2)));
                }
            };


            //刷新购物车列表
            $scope.refreshNavShopCart = function () {
                var $shop_cart_list = $(".shop_cart_list");
                var $btnShopCart = $('.sb_shopCart');
                $btnShopCart.toggleClass('active');
                $shop_cart_list.toggleClass('hide');
                if (!$btnShopCart.hasClass('active'))//关闭时不执行
                    return;

                $scope.cartListLoading = true;
                var $cartListLoading = $('[ng-hide="cartListLoading"]');

                //列表
                $http.get('/cart/getCartList.json?stamp=' + new Date().getTime()).success(function (response) {
                    $cartListLoading.remove();
                    if (response.success) {
                        $scope.cartList = response.items;

                        //统计总和
                        $scope.cartNum = 0;
                        if ($scope.cartList && $scope.cartList.length > 0) {
                            $.each($scope.cartList, function (n, v) {
                                var x = $scope.cartList[n];
                                x.isDel = false;
                                $scope.cartNum++;
                            });
                            $scope.totalPrice();
                        }
                        if ($scope.cartNum == 0)
                            $('.shop_cart_list .cart_empty').removeClass('hide');
                        else
                            $('.shop_cart_list .cart_empty').addClass('hide');
                    }
                });

                $timeout(function () {
                    $cartListLoading.remove();
                }, 1000)
            };



            //统计数量
            $scope.cartNum = 0;
            $scope.countNavShopCart = function () {
                $http.get('/cart/getCount.json?stamp=' + new Date().getTime()).success(function (response) {
                    if (response.success) {
                        $scope.cartNum = response.data;
                        if ($scope.cartNum == 0)
                            $('.shop_cart_list .cart_empty').removeClass('hide');
                        else
                            $('.shop_cart_list .cart_empty').addClass('hide');
                    }
                });
            };
            $scope.isCartList = true;
            $scope.countNavShopCart();

            //删除商品
            $scope.deleteNavShopCart = function (el, x) {
                el = el.target;
                var pt = $(el).parents('li,tr').eq(0);
                var cartNum = parseInt($('#cartCount').text()) - 1;
                var id = x.itemId;
                if (confirm('您确定要删除吗？')) {
                    $.post('/cart/delete', {
                        id: id
                    }, function (response) {
                        if (response.success) {

                            $('#cartCount').text(cartNum);
                            x.isDel = true;
                            $scope.totalPrice();

                            //剔除购物车cookie
                            var c_cartItems = $.cookie('checked_cart_items');
                            c_cartItems = eval('([' + c_cartItems + '])');
                            if (c_cartItems.length > 0) {
                                var new_cartItems = [];
                                $.each(c_cartItems, function (n, v) {
                                    if (v != id)
                                        new_cartItems.push(v);
                                });
                                $.cookie('checked_cart_items', new_cartItems, {path: '/'});
                            }

                            pt.fadeOut(800, function () {
                                $(this).remove();
                                if (cartNum == 0)
                                    $('.shop_cart_list .cart_empty').removeClass('hide');
                            });
                        } else {
                            $.message('error', response.data);
                        }
                    }, 'json').error(function (err) {
                        var msg = err.status || err;
                        $.message('error', '@' + msg);
                    });
                }
            };

            //向上广播事件
            /* 子控制器调用方法：$scope.$emit('countNavShopCart');*/
            $scope.$on('countNavShopCart', function () {
                $scope.countNavShopCart();
            });

            $timeout(function () {
                InitMeSidebar();
            }, 100);

            $timeout(function () {
                $.pageLoading('hide');
                require('placeholder');
            }, 500);

        }
    });

    //模块输出
    module.exports = {
        myApp: myApp,
        fn: function () {
        }
    };


});