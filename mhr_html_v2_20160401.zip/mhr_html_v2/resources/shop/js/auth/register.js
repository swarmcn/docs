/**
 * Created by sg009 on 15/六月/19.
 */
define(function(require,exports) {
    require('angularJs');
    require('jquery');
    require('token');//令牌，POST时必须调用
    require('validate');
    require('placeholder');
    require('plugin/message');
    var Guid = require('plugin/guid');
    var circle = require('plugin/circle');

    //$('input, textarea').placeholder();
    var $registerForm = $("#registerForm");
    var $shopId = $("#shopId");
    var $username = $("#username").focus();
    var $password = $("#password");
    //var $areaId = $("#areaId");
    //var $captcha = $("#captcha");

    var captchaId = Guid();//验证码标识
    var $captchaImage = $("#captchaImage");
    var $submit = $(":submit");
    var $randomCode = $("#randomCode");
    var $sendRandomCode = $("#sendRandomCode");
    var $agreement = $("#agreement");
    var $protocol= $("#protocol");
    var $mask= $("#mask");
    var $close= $("#close");

    //获取注册协议
    $.get('/register/getRegisterAgreement.json', function (response) {
        if(response.success)
            $agreement.html(response.data);
    },'json');
    $protocol.click(function(){
        $mask.show();
    });
    $close.click(function(){
        $mask.hide();
    });
    $mask.click(function(){
        $mask.hide();
    });

    //获取门店列表
    $.get('/storeshop/getlist.json', function (response) {
        if(response.success){
            var option = '<option value="">请选择注册所在门店</option>';
            $.each(response.data, function (n,shop) {
                option += '<option value="'+shop.id+'">'+shop.name+'</option>';
            });
            $shopId.html(option);
        }
    });

    //发送验证码
    $sendRandomCode.click(function () {
        var el = $(this);
        var mobile = $username.val();
        var isMob = /^((\+?86)|(\(\+86\)))?(1[3-8][0-9]{9})$/;
        if (!isMob.test(mobile)) {
            $.message('error','请输入有效的手机号码！');
            $username.focus();
            return false;
        }
        if(!el.hasClass('gray_meg_btn')) {
            el.addClass('gray_meg_btn');
            $.post('/register/saveRandomCode', {
                username: mobile
            }, function (message) {
                $.message(message);
                if(message.type == 'success') {
                    circle({
                        'times': 60,
                        'fn': function () {
                            el.text('(' + this.times + ')秒后重试');
                        },

                        'afterfn': function () {
                            el.removeClass('gray_meg_btn');
                            el.text('点击获取短信验证码');
                        }
                    });
                }
                else
                    el.removeClass('gray_meg_btn');
            }, 'json');
        }
    });

    ////更换验证码
    //$captchaImage.click(function() {
    //    $(this).removeClass('hide').attr("src", "/common/captcha?captchaId=" + captchaId + "&timestamp=" + new Date().getTime());
    //}).click();//初始化

    // 表单验证
    $registerForm.validate({
        rules: {
            username: {
                required: true,
                pattern: /^1[3-8]+\d{9}/,
                minlength: 11,
                remote: {
                    url: "/register/check_username",
                    cache: false
                }
            },
            password: {
                required: true,
                pattern: /^[^\s&\"<>]+$/,
                minlength: 6
            },
            rePassword: {
                required: true,
                equalTo: "#password"
            },
            agree: {
                required: true
            },
            randomCode:"required"
            //,
            //captcha: "required"
        },
        messages: {
            username: {
                pattern: "格式错误",
                remote: "手机号已被注册"
            },
            password: {
                pattern: "密码包含非法字符"
            }
        },
        submitHandler: function(form) {

            //获取公钥
            $.ajax({
                url: "/common/public_key",
                type: "GET",
                dataType: "json",
                cache: false,
                beforeSend: function() {
                    $submit.prop("disabled", true);
                },
                success: function(data) {

                    //调用加密
                    seajs.use("plugin/encrypt/secret", function () {
                        var rsaKey = new RSAKey();
                        rsaKey.setPublic(b64tohex(data.modulus), b64tohex(data.exponent));
                        var enPassword = hex2b64(rsaKey.encrypt($password.val()));

                        //提交表单
                        $.ajax({
                            url: '/register/submit',
                            type: "POST",
                            data: {
                                shopId: $shopId.val(),
                                username: $username.val(),
                                enPassword: enPassword,
                                randomCode: $randomCode.val()
                                //,
                                //captchaId: captchaId
                                //,
                                //captcha: $captcha.val(),
                            },
                            dataType: "json",
                            cache: false,
                            success: function (message) {
                                $.message(message);
                                if (message.type == "success") {
                                    setTimeout(function () {
                                        $submit.prop("disabled", false);
                                        location.href = "/";
                                    }, 1000);
                                } else {
                                    //$captcha.val("");
                                    $captchaImage.click();
                                    $submit.prop("disabled", false);
                                }
                            }
                        });
                    });

                }
            });
        }
    });
});