/**
 * Created by sg009 on 15/六月/19.
 */
define(function (require, exports) {
    require('angularJs');
    require('jquery');
    require('token');//令牌，POST时必须调用
    require('cookie');
    require('validate');
    require('placeholder');
    require('plugin/message');
    var Guid = require('plugin/guid');
    var getQueryString = require('plugin/getQueryString');
    var Validate = require('plugin/validate.el');
    var isTest = (location.hostname == 'localhost' || location.hostname.indexOf('192.168.2') > -1 || location.hostname.indexOf('172.') > -1);
    var $submit = $("#btn-send");

    //初始验证码
    function getCaptcha(callback) {
        if (!$('#slideValidate').hasClass('open')) {
            $.getScript('//api.geetest.com/get.php?callback=startCaptcha', function () {
                window.startCaptcha = function () {
                    var url = '/common/startCaptcha';
                    if (isTest)
                        url = '/demo/startCaptchaServlet.json';
                    $.get(url, function (response) {
                        if (response.success) {
                            var data = {
                                gt: response.gt,
                                challenge: response.challenge,
                                product: "popup"
                            };
                            if (isTest)
                                delete data.challenge;
                            window.gt_captcha_obj = new window.Geetest(data)
                                .appendTo("#slideValidate").bindOn('#btn-send')
                                .onSuccess(function () {
                                    var validate = gt_captcha_obj.getValidate();
                                    if (typeof callback == 'function') {
                                        callback.call(this, validate);
                                    }
                                })
                                .onRefresh(function () {
                                    $submit.data('geetest', false);
                                });

                            $('#slideValidate').addClass('open');
                            var autoClick = setInterval(function () {
                                if ($('#origin_btn-send').length == 0) {
                                    setTimeout(function () {
                                        $('#btn-send').click();
                                    }, 100);
                                } else
                                    clearInterval(autoClick);
                            }, 10);
                        }
                    }, 'json');
                };
            });
        }
    }

    //placeholder
    //$('input, textarea').placeholder();

    //判断手机端，重定向至微商城
    var uaRedirect = require('plugin/uaredirect');
    uaRedirect('/weixin/index.html');

    var $loginForm = $("#loginForm");
    var $username = $("#username");
    var $password = $("#password");
    var $captcha = $("#captcha");
    var $captchaImage = $("#captchaImage");
    var captchaId = Guid();//验证码标识
    var $rememberMe = $("#rememberMe");


    var $UN = $("#UN");
    var $PWD = $("#PWD");
    var cookie_username = $.cookie("rememberMe");

    //避免浏览器自动加载密码
    $PWD.focus(function () {
        $(this).hide();
        $password.val("").show().css("backgroundColor", "#fff").focus();
    });
    $UN.focus(function () {
        $(this).hide();
        $username.val(cookie_username || '').show().css("backgroundColor", "#fff").focus();
    });
    $submit.hover(function () {
        $PWD.focus();
        $UN.focus();
    });

    //记住用户名
    if (cookie_username != null) {
        $rememberMe.prop("checked", true);
        $UN.val(cookie_username);
        $username.val(cookie_username);
        setTimeout(function () {
            $PWD.focus();
            $password.focus();
        }, 200)
    } else {
        $rememberMe.prop("checked", false);
        setTimeout(function () {
            $UN.focus();
        }, 200)
    }

    //广告位
    var myApp = angular.module("myApp", []);

    //ajax请求全局配置
    myApp.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.defaults.headers.common['token'] = $.cookie('token') || 0;
        $httpProvider.defaults.headers.common['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
        $httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
    }]);

    myApp.controller('pictureCtrl', function ($scope, $http) {
        var url = "/picture/getDetail.json";
        if (location.hostname == 'localhost')
            url = '/admin/operate/picture/getDetail.json';
        $http.get(url + '?type=loginPage').success(function (response) {
            if (response.success)
                $scope.picture = response.data;
        })
    });

    ////更换验证码
    //$captchaImage.click(function () {
    //    $(this).removeClass('hide').attr("src", "/common/captcha?captchaId=" + captchaId + "&timestamp=" + new Date().getTime());
    //}).click();//初始化

    //表单验证
    $loginForm.validate({
        rules: {
            username: {
                required: true,
                pattern: /^1[3-8]+\d{9}/,
                minlength: 11
            }
        },
        submitHandler: function () {
            getCaptcha(function (validate) {
                //获取公钥
                $.ajax({
                    url: "/common/public_key",
                    type: "GET",
                    dataType: "json",
                    cache: false,
                    beforeSend: function () {
                        $submit.prop("disabled", true);
                    },
                    success: function (data) {

                        //调用加密
                        seajs.use("plugin/encrypt/secret", function () {
                                var rsaKey = new RSAKey();
                                rsaKey.setPublic(b64tohex(data.modulus), b64tohex(data.exponent));
                                var enPassword = hex2b64(rsaKey.encrypt($password.val()));
                                //提交表单
                                $.ajax({
                                    url: '/login/submit',
                                    type: "POST",
                                    data: {
                                        username: $username.val(),
                                        enPassword: enPassword,
                                        geetest_challenge: validate.geetest_challenge,
                                        geetest_validate: validate.geetest_validate,
                                        geetest_seccode: validate.geetest_seccode
                                    },
                                    dataType: "json",
                                    cache: false,
                                    success: function (message) {
                                        if ($rememberMe.prop("checked")) {
                                            $.cookie('rememberMe', $username.val(), {expires: 7, path: '/'});
                                        } else {
                                            $.removeCookie('rememberMe');
                                        }
                                        if (message.type == "success") {
                                            setTimeout(function () {
                                                var redirectUrl = decodeURIComponent(getQueryString('redirectUrl', null, true));
                                                if (redirectUrl)
                                                    location.href = redirectUrl;
                                                else
                                                    location.href = "/";
                                            }, 500);
                                        } else {
                                            $.message(message);
                                            //$captcha.val("");
                                            //$captchaImage.click();
                                            $submit.prop("disabled", false);

                                            //手动刷新
                                            window.gt_captcha_obj.refresh();
                                        }
                                    }
                                });
                            }
                        );
                    }
                });
            });

        }
    });
});