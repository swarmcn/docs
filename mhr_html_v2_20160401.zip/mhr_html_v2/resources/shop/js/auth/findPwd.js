/**
 * Created by sg009 on 15/六月/23.
 */
define(function(require,exports) {
    require('angularJs');
    require('jquery');
    require('token');//令牌，POST时必须调用
    require('validate');
    require('placeholder');
    require('plugin/message');
    var Guid = require('plugin/guid');
    var circle = require('plugin/circle');

    $('input').placeholder();
    var $passwordForm = $("#passwordForm");
    var $username = $("#username");
    var $captcha = $("#captcha");
    var captchaId = Guid();//验证码标识
    var $captchaImage = $("#captchaImage");
    var $submit = $(":submit");
    var $sendRandomCode = $("#sendRandomCode");
    //var $randomCode = $("#randomCode");
    //var $newPassword = $("#newPassword");
    //var $rePassword = $("#rePassword");

    //发送验证码
    $sendRandomCode.click(function () {
        var el = $(this);
        var mobile = $username.val();
        var isMob = /^((\+?86)|(\(\+86\)))?(1[3-8][0-9]{9})$/;
        if (!isMob.test(mobile)) {
            $.message('error','请输入有效的手机号码');
            $username.focus();
            return false;
        }

        if(!el.hasClass('gray_meg_btn')) {
            el.addClass('gray_meg_btn');
            $.post('/password/saveRandomCode?username=' + mobile,
                function (message) {
                    $.message(message);
                    if(message.type == 'success') {
                        circle({
                            'times': 60,

                            'fn': function () {
                                el.text('(' + this.times + ')秒后重试');
                            },

                            'afterfn': function () {
                                el.removeClass('gray_meg_btn');
                                el.text('点击获取短信验证码');
                            }
                        });
                    }
                    else
                        el.removeClass('gray_meg_btn');
                }, 'json'
            );
        }
    });

    ////更换验证码
    //$captchaImage.click(function() {
    //    $(this).removeClass('hide').attr("src", "/common/captcha?captchaId=" + captchaId + "&timestamp=" + new Date().getTime());
    //}).click();//初始化

    // 表单验证
    $passwordForm.validate({
        rules: {
            username: {
                required: true,
                pattern: /^1[3-8]+\d{9}/,
                minlength: 11
            },
            newPassword: {
                required: true,
                pattern: /^[^\s&\"<>]+$/,
                minlength: 6,
                maxlength: 20
            },
            rePassword: {
                required: true,
                equalTo: "#newPassword"
            },
            randomCode: "required"
            //,
            //captcha: "required"
        },messages: {
            username: {
                pattern: "格式错误",
                remote: "手机号未注册"
            },
            password: {
                pattern: "密码包含非法字符"
            }
        },
        submitHandler: function (form) {
            //$("#captchaId").val(captchaId);
            $.ajax({
                url: '/password/find',
                type: "POST",
                data: $passwordForm.serialize(),
                dataType: "json",
                cache: false,
                beforeSend: function() {
                    $submit.prop("disabled", true);
                },
                success: function(message) {
                    $.message(message);
                    if (message.type == "success") {
                        setTimeout(function() {
                            $submit.prop("disabled", false);
                            location.href = "/";
                        }, 1000);
                    } else {
                        $submit.prop("disabled", false);
                        $captcha.val("");
                        $captchaImage.click();
                    }
                }
            });
        }
    });
});