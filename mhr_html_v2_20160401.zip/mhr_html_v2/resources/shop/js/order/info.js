define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('token');//令牌，POST时必须调用
    require('plugin/message');
    require('bootstrap');
    require('plugin/icheck/icheck.sea');
    require('plugin/validate.el');
    require('placeholder');


    var base64 = require('plugin/encrypt/base64');
    var getQueryString = require('plugin/getQueryString');
    var $effectivePriceCNY = $('#effectivePriceCNY');
    var $mj = $('#mj');

    var $select = $('.selectArea select');
    var areaSelect = require('share/js/addrSelect');
    var $addressForm = $('#addressForm');
    var Validate = require('plugin/validate.el');
    var $addressShow = $(".address-show");
    var $showOrderMulti = $('.showOrderMulti');
    var $close = $(".close");


    function addCommas(nStr) {
        //nStr = nStr.toFixed(2);
        nStr += '';
        x = nStr.split('.');
        x1 = x[0];
        x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        }
        return x1 + x2;
    }

    $('.icheckbox_square-blue').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '0%' // optional
    });

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller("OrderInfoCtrl", function ($scope, $http, $timeout) {

            $scope.Agreement = true;

            $("[data-toggle='tooltip']").tooltip();

            $scope.changeAgreement = function () {

                //$scope.Agreement = false;
                alert($scope.Agreement)
            }


            //立即购买参数解密
            var buy = getQueryString('b');
            if (buy) {
                try {
                    $scope.fastBuy = eval('(' + base64.decode(getQueryString('b')) + ')');
                    $('.step1-done').text('立即购买');
                }
                catch (ex) {
                    $.message('error', '参数有误！');
                    $scope.errorMsg = '参数有误！';
                    setTimeout(function () {
                        location.href = '/';
                    }, 2000);
                    return;
                }
            }

            $timeout(function () {
                //不显示导航购物车
                $('.shop-cart').remove();

            }, 100);
            $scope.weight = 0.00;//重量
            $scope.freight = 0.00;//运费
            $scope.subtract = 0.00;//满减
            $scope.amount = 0.00;//商品金额


            $scope.effectivePrice = 0.00;
            $scope.effectivePriceCNY = 0.00;

            //门店列表
            var url = '/storeshop/getlist.json';
            if ($.isTest)
                url = '/admin/store/getList.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.shopList = response;
                }
            });

            //满减
            $scope.getFullCut = function (callback) {

                var amount = $scope.amount.toFixed(2);
                //满减
                var url = '/promotion/getFullSubtract.json';
                if ($.isTest)
                    url = '/weixin/member/getFullSubtract.json';
                $http.get(url).success(function (response) {
                    if (response.success) {
                        $scope.fullCut = response.data;
                        var fullCutItems = $scope.fullCut;
                        $mj.text(0.00);
                        $scope.subtract = 0.00;
                        for (var i = 0; i < fullCutItems.length; i++) {
                            var item = fullCutItems[i];
                            if (amount >= item.fullAmount) {
                                $scope.subtract = item.subtractAmount.toFixed(2);
                                if (typeof callback == 'function')
                                    callback();
                                return;
                            }
                        }
                        if (typeof callback == 'function')
                            callback();
                    }
                });
            };


            //获取运费
            $scope.getFreight = function (callback) {
                if (!$scope.receiverId) {
                    $scope.getReceiver(function () {
                        $scope.receiverId = $('#receiver>.current [name="receiverId"]').val();
                        if ($scope.receiverId == null)
                            $scope.receiverId = $('#receiver>.default [name="receiverId"]').val();
                        $scope.getFreight(callback);
                    })
                } else {
                    $http.get('/member/order/getFreight.json', {
                        params: {
                            receiverId: $scope.receiverId,
                            weight: $scope.weight || 0,
                            amount: $scope.amount || 0,
                            stamp: new Date().getTime()
                        }
                    }).success(function (response) {
                        if (response.success) {
                            $scope.freight = response.data;
                            if (typeof callback == 'function')
                                callback();
                        }
                    })
                }
            };


            //优惠券
            $scope.getVoucher = function () {
                var url = '/member/voucher/getVoucher.json';
                if ($.isTest)
                    url = '/weixin/member/getVoucher.json';
                $http.get(url).success(function (response) {
                    if (response.success) {
                        $scope.Voucher = response.data;
                        var voucherItems = $scope.Voucher;
                        var couponDiscount = 0.00;
                        for (var i = 0; i < voucherItems.length; i++) {
                            var item = voucherItems[i];
                            if ($scope.amount - $scope.subtract + $scope.freight >= item.minOrderAmount) {
                                couponDiscount = item.discountAmount;
                                $scope.InfoList.couponDiscount = couponDiscount
                                $scope.couponDiscount = couponDiscount || 0;
                                $scope.couponName = item.name;
                                $timeout(function () {
                                    $('.couponDiscount option').each(function () {
                                        if ($(this).text().length == 0)
                                            $(this).remove();
                                    });
                                }, 100);
                                return;
                            }
                        }
                        $scope.InfoList.couponDiscount = couponDiscount || 0;
                        $scope.couponDiscount = couponDiscount || 0;
                    }
                });
            };


            //绑定收货地址列表
            $scope.getReceiver = function (callback) {
                $http.get('/member/receiver/getlist.json').success(function (response) {
                    if (response.success) {
                        $scope.addressList = response.data;

                        var hasDefault = false;
                        $.each($scope.addressList, function (n, x) {
                            x.isSelected = x.isDefault;
                            if (x.isDefault)
                                hasDefault = true;
                        });
                        $timeout(function () {
                            console.log('areaSelect');
                            //areaSelect($select);
                            $.pageLoading('hide');
                            if (hasDefault == false) {
                                $('#receiver>div:eq(0)').addClass('current');
                                $scope.addressList[0].isSelected = true;
                            }
                            if (typeof callback == 'function')
                                callback();
                        }, 100);
                    }
                });
            };
            $scope.getReceiver();

            //编辑
            $scope.editAddr = function (index) {
                $addressShow.fadeIn(300);
                $scope.incomplete = false;
                var o = $scope.addressList[index];
                if (index == null)
                    o = {
                        id: null,
                        areaCode1: null,
                        areaCode2: null,
                        areaCode3: null,
                        address: null,
                        idCard: null,
                        phone: null,
                        zipCode: null,
                        consignee: null,
                        isDefault: null
                    };
                $scope.id = o.id;
                $scope.areaCode1 = o.areaCode1;
                $scope.areaCode2 = o.areaCode2;
                $scope.areaCode3 = o.areaCode3;
                $scope.address = o.address;
                $scope.idCard = o.idCard;
                $scope.phone = o.phone;
                $scope.zipCode = o.zipCode;
                $scope.consignee = o.consignee;
                $scope.isDefault = o.isDefault;
                //if ($scope.areaCode3 != $select.last().val()) {
                    $timeout(function () {
                        areaSelect($select);
                    }, 100);
                //}
            };

            //保存
            $scope.saveAddr = function () {

                if (!$scope.address) {
                    $('[name="address"]').focus();
                    $.message('warn', '详细地址不能为空！');
                    return;
                }
                else if (!$scope.zipCode) {
                    $('[name="zipCode"]').focus();
                    $.message('warn', '邮政编码不能为空！');
                    return;
                }
                else if (!$scope.idCard) {
                    $('[name="idCard"]').focus();
                    $.message('warn', '身份证号不能为空！');
                    return;
                }
                else if (!$scope.consignee) {
                    $('[name="consignee"]').focus();
                    $.message('warn', '收货人姓名不能为空！');
                    return;
                }
                else if (!$scope.phone) {
                    $('[name="phone"]').focus();
                    $.message('warn', '电话/手机不能为空！');
                    return;
                }
                else {
                    if ($scope.addressList == 20) {
                        $.message('warn', '收货地址数量已到上限');
                        return;
                    }
                    var resIdCard = Validate.checkformat('.idCard');
                    if (!resIdCard.res) {
                        $.message('warn', resIdCard.msg + '不正确');
                        return false;
                    }
                    var resPhone = Validate.checkformat('.phone');
                    if (!resPhone.res) {
                        $.message('warn', resPhone.msg + '不正确');
                        return false;
                    }
                }

                var url = '/member/receiver/update.json';//更新
                var data = $addressForm.serializeObject();
                data.isDefault = $scope.isDefault ? true : false;
                data.areaCode3 = $('[name="areaCode3"]').val() || 0;
                $.post(url, data, function (response) {
                    if (response.success) {
                        $.message('success', '保存成功');
                        if (sessionStorage.getItem('WXDebug'))
                            return;
                        $timeout(function () {
                            $scope.getReceiver();
                            $addressShow.fadeOut(300);
                        }, 1000);
                    }
                    else
                        $.message('error', response.data);
                }, 'json');
            };


            //商品列表
            if ($scope.fastBuy) {
                //立即购买
                $http.get('/member/order/getOrderInfo.json', {
                    params: $scope.fastBuy
                }).success(function (response) {
                    if (response.success) {
                        $scope.InfoList = eval('([' + JSON.stringify(response.data) + '])');
                        var info = $scope.InfoList[0];
                        info.quantity = $scope.fastBuy.quantity;
                        info.productId = $scope.fastBuy.productId;
                        $scope.amount = info.price * info.quantity;
                        $scope.weight = info.weight * info.quantity;
                        $scope.getFullCut(function () {
                            $scope.getFreight(function () {
                                $scope.getVoucher();
                            });
                        });
                    } else {
                        $scope.errorMsg = response.data;
                    }
                });
            } else {
                //购物车购买
                $http.get('/member/order/getCartOrderInfo.json').success(function (response) {
                    if (response.success) {
                        $scope.InfoList = response.items;
                        $scope.orderToken = response.orderToken;
                        $scope.products = [];
                        $.each($scope.InfoList, function (n, x) {
                            $scope.amount += x.price * x.quantity;
                            $scope.weight += x.weight * x.quantity;
                            $scope.products.push({"itemId": x.itemId, "pid": x.productId, "quantity": x.quantity});
                        });
                        $scope.getFullCut(function () {
                            $scope.getFreight(function () {
                                $scope.getVoucher();
                            });
                        });

                    } else {
                        $scope.errorMsg = response.data;
                    }
                });
            }

            //设为默认
            $scope.setSelected = function (el, sn) {
                sn = parseInt(sn);
                var $this = $scope.addressList[sn];

                //设为默认
                $this.isSelected = true;
                $scope.receiverId = $this.id;
                $scope.getFreight();

                //清除默认选中
                $.each($scope.addressList, function (n, x) {
                    if (sn != n && x.isSelected)
                        x.isSelected = false;
                });
            };


            //提交订单
            $scope.confirmOrder = function () {
                var receiverId = $('#receiver>.current [name="receiverId"]').val();
                if (receiverId == null) {
                    receiverId = $('#receiver>.default [name="receiverId"]').val();
                }
                if (receiverId == null) {
                    $.message('warn', '收货地址不能为空');
                    return;
                }

                if (!$('[name="Agreement"]').prop("checked")) {
                    $.message('warn', '请授权个人委托申报协议');
                    return;
                }

                //是否使用优惠券
                if ($scope.InfoList.couponDiscount == '0' || !$scope.InfoList.couponDiscount)
                    $scope.isUseVoucher = false;
                else
                    $scope.isUseVoucher = true;


                var shopId = $('#shopId').val();
                var memo = $('[name="memo"]').val();
                if ($scope.fastBuy) {
                    //立即购买
                    $.post('/member/order/submitImmediateOrder', {
                        shopId: shopId,
                        receiverId: receiverId,
                        productId: $scope.fastBuy.productId,
                        quantity: $scope.fastBuy.quantity,
                        memo: memo,
                        isUseVoucher: $scope.isUseVoucher
                    }, function (response) {
                        if (response.success) {
                            $.postForm('/payment/submit', {id: response.data});
                            //location.href = '/member/order/payment.html?sn=' + response.data;
                        } else {
                            $.message('error', response.data);
                        }
                    }, 'json');
                } else {
                    //购物车购买
                    $.post('/member/order/submitOrder', {
                        shopId: shopId,
                        receiverId: receiverId,
                        orderToken: $scope.orderToken,
                        products: JSON.stringify($scope.products).replace(/"/g, "'"),
                        memo: memo,
                        isUseVoucher: $scope.isUseVoucher
                    }, function (response) {
                        if (response.success) {
                            //大于一表示拆单
                            if (response.orderCount && response.orderCount > 1) {
                                $showOrderMulti.fadeIn(300);
                            }
                            else
                                $.postForm('/payment/submit', {id: response.orderId})
                        } else {
                            $.message('error', response.data);
                        }
                    }, 'json');
                }
            }


            $close.click(function () {
                $addressShow.fadeOut(300);
            });


        })


    });

})