define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('plugin/validate.el');
    require('placeholder');
    require('plugin/message');
    require('token');//令牌，POST时必须调用
    var getQueryString = require('plugin/getQueryString');

    var returnedForm = $('#returnedForm');
    var pathName = location.pathname;


    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('paymentCtrl', function ($scope, $http, $timeout) {

            var ordeSN = parseInt(getQueryString('id'));
            if (isNaN(ordeSN)) {
                $.message('error', '订单信息有误！');
                $timeout(function () {
                    location.href = "/member/order/index.html";
                }, 3000);
                return;
            }

            //订单状态提示
            $scope.validateOrder = function (order) {
                var isStatus = false;

                if (order.expired || order.orderStatus == "cancel")//交易关闭
                {
                    isStatus = (pathName.indexOf('cancel.html') > -1);
                    order.statusTip = order.expireDate;
                }
                else if (order.paymentStatus == "unpaid") {//已下单-代付款
                    isStatus = (pathName.indexOf('unpaid.html') > -1);
                    if (isStatus)
                        order.statusTip = order.expireDate;
                    else
                        location.href = "sendgoods.html";
                }
                else if (order.PaymentStatus == "paid")//已下单-已付款-等待发货
                {
                    isStatus = (pathName.indexOf('sendgoods.html') > -1);
                    if (isStatus)
                        order.statusTip = order.expireDate;
                    else
                        location.href = "confirm.html";
                }
                else if (order.expireDate == "shipped")//已下单-已付款-已发货-确认收货
                {
                    isStatus = (pathName.indexOf('confirm.html') > -1);
                    order.statusTip = order.expireDate;
                }

                else if (order.shippingStatus == "unshipped")//退款、货页面
                {
                    isStatus = (pathName.indexOf('returned_apply.html') > -1);
                }

                if (!isStatus) {
                    location.href = "/member/order/index.html";
                }
            }

            //立即付款
            $scope.toPayment = function (orderId) {
                $.postForm('/payment/submit', {id: orderId});
            };

            //订单详情
            $http.get('/member/order/getOrderDetail.json?id=' + ordeSN).success(function (response) {
                if (response.success) {
                    $scope.order = response.data;
                    $scope.validateOrder($scope.order);


                    $scope.incomplete = false;

                    //申请退款页面监听变动
                    $scope.type = '';
                    $scope.reason = '';
                    $scope.price = '';

                    $scope.$watch('type', function () {
                        $scope.test();
                    });
                    $scope.$watch('reason', function () {
                        $scope.test();
                    });
                    $scope.$watch('price', function () {
                        $scope.test();
                    });

                    var typeHide = $('#typeHide');
                    if ($scope.order.paymentStatus == 'drawBack') {
                        typeHide.hide();
                        $scope.test = function () {
                            $scope.incomplete = false;
                            if (!$scope.reason.length || !$scope.price.length) {
                                $scope.incomplete = true;
                            }
                        };
                    }
                    else {
                        $scope.test = function () {
                            $scope.incomplete = false;
                            if (!$scope.type.length || !$scope.reason.length || !$scope.price.length) {
                                $scope.incomplete = true;
                            }
                        };
                    }


                    //将时间格式化
                    if ($scope.order.expireDate) {
                        $scope.order.expireDate = new Date($scope.order.expireDate).getTime();
                    }
                }
                else {
                    $.message('error', response.data);
                    $timeout(function () {
                        location.href = "/member/order/index.html";
                    }, 3000);
                }
            });

            //取消订单
            $scope.deleteOrder = function () {
                if (confirm('您确定要取消订单吗？')) {
                    $.ajax({
                        url: '/member/order/cancel',
                        type: "POST",
                        dataType: "json",
                        data: {id: ordeSN},
                        success: function (response) {
                            $.message(response);
                            if (response.type == "success") {
                                $timeout(function () {
                                    location.href = "/member/order/index.html";
                                }, 3000);
                            }
                        }
                    });
                }
            }


            //提交退款信息*******************************************
            $scope.SubmitApply = function () {
                if (!$scope.incomplete) {
                    $.ajax({
                        url: '/member/order/add',
                        type: "POST",
                        dataType: "json",
                        data: returnedForm.serializeObject(),
                        success: function (response) {
                            if (response.success) {
                                $.message("success", response.data);
                                $timeout(function () {
                                    location.href = "/member/order/index.html";
                                }, 3000);
                            }
                            else {
                                $.message("error", response.data);
                            }
                        }
                    });

                }
            };
        })
    });
});