define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('owl-carousel');
    require('plugin/unslider');
    require('token');//令牌，POST时必须调用
    require('plugin/banner.js');


    //图片轮播
    //(function ($, window) {
    //    'use strict';
    //    function zA7n($ul, opt) {
    //        var ul_width,
    //            $li = $('li', $ul),
    //            li_length,
    //            start_width,
    //            firstIndex,
    //            timeout_Center;
    //
    //        var animate_time = 5000;
    //        li_length = $li.length;
    //
    //        firstIndex = Math.round(li_length / 2) - 1;
    //        function setVars() {
    //            ul_width = $ul.width();
    //            start_width = ul_width / li_length;
    //            $li.css({'width': start_width + 'px'});
    //        }
    //
    //        function setItemCenter(except) {
    //            $li.each(function () {
    //                var $item = $(this);
    //                if ($(except).attr('index') != $item.attr('index') || except == null) {
    //                    var $imgWidth = $('img', $item).width();
    //                    $item.find('a').css({'margin-left': ($imgWidth - start_width / 2) / 2 * -1});
    //                }
    //            });
    //        }
    //
    //        function moveItems() {
    //            if (!$li.hasClass('hover')) {
    //                var $liActive = $('li.active', $ul);
    //                if ($liActive[0]) {
    //                    var index = $liActive.index();
    //                    if (index + 1 < li_length) {
    //                        $liActive.next().click();
    //                    } else {
    //                        $li.eq(0).click();
    //                    }
    //                } else {
    //                    $li.eq(0).click();
    //                }
    //            }
    //        }
    //
    //        $li.each(function (index) {
    //            var $item = $(this), item_width;
    //            item_width = $item.width();
    //
    //            $item.attr('index', index);
    //            function openItem($item) {
    //                $li.removeClass('active').removeClass('hover').css({'width': ((ul_width - item_width) / (li_length - 1)) + 'px'});
    //                $item.addClass('active').css({'width': item_width + 'px'});
    //
    //                setItemCenter($item);
    //                $item.find('a').css({'margin-left': 0});
    //            }
    //
    //            $item.click(function () {
    //                openItem($item);
    //                clearTimeout(timeout_Center);
    //                timeout_Center = setTimeout(function () {
    //                    moveItems();
    //                }, animate_time);
    //            }).hover(function () {
    //                //mouseover
    //                openItem($item);
    //                $item.addClass('hover');
    //
    //                // interval_Center = clearInterval(interval_Center);
    //            }, function () {
    //                //mouseout
    //                $li.css({'width': start_width + 'px'});
    //                $item.removeClass('hover');
    //                //clearInterval(interval_Center);
    //            });
    //        });
    //
    //        $ul.on({
    //            'mouseout': function (event) {
    //                //interval_Center = clearInterval(interval_Center);
    //                //setTimeout(function () {
    //                //   // moveItems();
    //                //    interval_Center = setInterval(function () {
    //                //        moveItems();
    //                //    }, animate_time);
    //                //},500);
    //                clearTimeout(timeout_Center);
    //                setTimeout(function () {
    //                    $ul.find('li.active').click();
    //                }, 500);
    //                //timeout_Center = setTimeout(function () {
    //                //    moveItems();
    //                //},animate_time);
    //            }
    //        });
    //
    //        setVars();
    //
    //        $(window).on('resize', function () {
    //            setVars();
    //        }.debounce(150));
    //
    //        //默认展开
    //        $li.eq(firstIndex).click();
    //
    //        //自动轮播
    //        //interval_Center = setInterval(function () {
    //        //    moveItems();
    //        //}, animate_time);
    //    }
    //
    //    $.fn.zA7n = function (o) {
    //        var opt = $.extend({}, o);
    //        return this.each(function () {
    //            var $ul = $(this);
    //            if ($ul.data('zAc6n')) {
    //                return;
    //            }
    //            zA7n($ul, opt);
    //            $ul.data('zAc6n', 1).addClass('_create');
    //        });
    //    };
    //}(jQuery, this));


    //判断手机端，重定向至微商城
    var uaRedirect = require('plugin/uaredirect');
    uaRedirect('/weixin/index.html');

    function initFlexslider() {
        $('.unslider').fadeIn(300).each(function () {
            var unslider = $(this).unslider({
                speed: 500,               //  The speed to animate each slide (in milliseconds)
                delay: false,              //  The delay between slide animations (in milliseconds)
                keys: false,               //  Enable keyboard (left, right) arrow shortcuts
                dots: false,               //  Display dot navigation
                fluid: false
            });
            $('.unslider-arrow', unslider).click(function () {
                var fn = this.className.split(' ')[1];
                //  Either do unslider.data('unslider').next() or .prev() depending on the className
                unslider.data('unslider')[fn]();
            });
        });
    }

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        //图片轮播
        myApp.controller("BannerCtrl", function ($scope, $http, $timeout) {
            var url = '/common/getBanner.json?typeId=0';
            if ($.isTest)
                url = '/admin/operate/banner/getBanner.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.BannerList = response.data;

                    //图片轮播
                    $timeout(function () {
                        if ($('.owl-carousel.banner img').length > 1) {
                            $('.owl-carousel.banner').owlCarousel({
                                margin: 0,
                                center: true,
                                items: 1,
                                nav: true,
                                loop: true,
                                animateOut: 'fadeOut',
                                lazyLoad: true,
                                autoplay: true,
                                autoplayTimeout: 5000,
                                autoplayHoverPause: true
                            });
                        } else {
                            $('.owl-carousel.banner').owlCarousel({
                                margin: 0,
                                center: true,
                                items: 1,
                                nav: false,
                                dots: false,
                                loop: false,
                                lazyLoad: true
                            });
                        }

                        $('.owl-carousel .item').each(function () {
                            $(this).parent().css('background-color', $(this).attr('bg'));
                        });
                    }, 100)
                    //$timeout(function () {
                    //    $('#banner').zA7n({});
                    //}, 500)
                }
            })
        });


        myApp.controller("themesCtrl", function ($scope, $http, $timeout) {

            //主题推荐URL
            var url = '/theme/recommend/getList.json';
            if ($.isTest)
                url = '/theme/getList.json';


            //今日热推:10
            $http.get(url + '?tagId=10&pageSize=3&isHasProducts=true').success(function (response) {
                if (response.success) {
                    $scope.todayList = response.data;
                    $timeout(function () {
                        initFlexslider();
                    }, 100)
                }
            });

            //健康精选:11
            $http.get(url + '?tagId=11&pageSize=3&isHasProducts=false').success(function (response) {
                if (response.success) {
                    $scope.healthList = response.data;
                }
            });

            //小编推荐:12
            $http.get(url + '?tagId=12&pageSize=4&isHasProducts=false').success(function (response) {
                if (response.success) {
                    $scope.recommendList = response.data;
                }
            });

            //更多推荐:13
            $scope.themeList = [];
            var isCanScroll = true;
            var $pageSize = 5;
            $scope.pageSize = $pageSize;
            $scope.currentPage = 0;
            var old_pageSize = 0;
            var old_currentPage = 0;
            var cookiePageNumber = parseInt(sessionStorage.getItem("pc-index-page") || 1);
            $scope.getMoreThemesList = function () {
                isCanScroll = false;
                var pageSize = $scope.pageSize;
                if ($scope.themeList.length == 0) {
                    pageSize = $scope.pageSize * cookiePageNumber;
                }
                if (pageSize == 0)
                    pageSize = $pageSize;
                $http({
                    method: 'get',
                    url: url,
                    params: {
                        tagId: 13,
                        //isIndex:true,
                        isHasProducts: true,
                        pageNumber: $scope.currentPage + 1,
                        pageSize: pageSize,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    if (response.success && response.data) {
                        $.each(response.data, function (n, x) {
                            if(!$('.more-container li.theme'+ x.id)[0])
                                $scope.themeList.push(x);
                        });
                        //if ($scope.themeList.length >= response.totalCount)
                        //    isCanScroll = false;
                        //else {
                        isCanScroll = true;
                        if (pageSize > $pageSize)
                            $scope.currentPage += pageSize / $pageSize;
                        else
                            $scope.currentPage++;
                        //}
                        old_currentPage = $scope.currentPage;
                        if (window.sessionStorage)
                            sessionStorage.setItem("pc-index-page", $scope.currentPage);

                        $timeout(function () {
                            initFlexslider();
                        }, 100)
                    } else {
                        //if (response.totalCount == 0) {
                        isCanScroll = false;
                        //}
                    }
                })
            };
            $scope.getMoreThemesList();

            //滚动加载
            $(window).scroll(function () {
                var ds = $(document).scrollTop();//滚动条到顶部的垂直高度
                var dh = $(document).height() - 350;//页面的文档高度
                var wh = $(window).height();//浏览器的高度
                if (ds + wh >= dh && isCanScroll)//当文档的高度小于或者等于总的高度的时候，开始动态加载数据
                {
                    $scope.getMoreThemesList();
                    isCanScroll = false;
                }
            });

            //加入购物车
            $scope.addCart = function (x, event) {
                $.post('/cart/add', {
                    id: x.productId,
                    quantity: 1
                }, function (response) {
                    $.message(response);
                    if (response.type == "success") {

                        //飞入购物车
                        seajs.use('plugin/jquery/jquery.fly.min', function () {
                            var offset = $(".cart_num").offset();//抛物体终点
                            var scrollTop = $(window).scrollTop();
                            var flyer = $('<img class="flyer-img" src="' + x.wxImg + '">');//抛物体对象//获取当前点击图片链接
                            flyer.fly({
                                start: {
                                    left: event.pageX, //抛物体起点横坐标
                                    top: event.pageY - scrollTop////抛物体起点纵坐标
                                },
                                end: {
                                    left: offset.left, //抛物体终点横坐标
                                    top: offset.top - scrollTop + 5 //抛物体终点纵坐标
                                },
                                onEnd: function () {
                                    this.destory();//销毁抛物体
                                }
                            });
                        });

                        //统计购物车
                        $scope.$emit('countNavShopCart');
                    }
                }, 'json');
            };
        })

    })

});