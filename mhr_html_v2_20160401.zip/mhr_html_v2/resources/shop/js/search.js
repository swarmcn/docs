define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('highlight');
    require('token');//令牌，POST时必须调用
    require('unveil');

    var getQueryString = require('plugin/getQueryString');
    var keyword = getQueryString('keyword');

        //搜索内容为空时跳转到首页
    if (!keyword) {
        location.href = '/index.html';
    }

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;
        myApp.controller("ListCtrl", function ($scope, $http, $timeout) {
            $scope.keyword = keyword;
            $scope.hasTheme = true;
            $scope.hasProduct = true;

            //主题分类
            var url = '/theme/type/getList.json';
            if ($.isTest)
                url = '/theme/typeList.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.themeTypeList = response.data;
                }
            });

            //搜索为空时相关主题推荐
            $scope.getThemeHotHits =function(typeId){
                var url = '/theme/getHotHits.json';
                $http({
                    method: 'get',
                    url: url,
                    params: {
                        pageSize: 5,
                        typeId: typeId,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.hotHitsThemeList = response.data;
                    }
                });
            }

            //主题列表
            $scope.getThemesList = function (typeId) {
                var url = '/theme/getList.json';
                if ($.isTest)
                    url = '/theme/getList.json';
                $http({
                    method: 'get',
                    url: url,
                    params: {
                        keyword: keyword,
                        typeId: typeId,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.themeList = response.data;
                        $scope.themTotalCount = response.totalCount;

                        //返回结果为空时显示主题推荐
                        $scope.getThemeHotHits(typeId);
                        if ($scope.themTotalCount == 0) {
                            if (!typeId){
                                $scope.hasTheme = false;
                            }
                        }


                        //关键字检索
                        if ($scope.keyword) {
                            $timeout(function () {
                                $('.themes-list').highlight(keyword);
                            }, 100)
                        }
                        else
                            return false;

                    }
                })
            };
            $scope.getThemesList();

            //筛选主题列表
            $scope.changeThemeType = function (typeId) {
                $scope.themeTypeId = typeId;
                $scope.getThemesList(typeId);
            };

            //商品分类
            var url = '/product_category/getList.json';
            if ($.isTest)
                url = '/theme/typeList.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.productTypeList = response.data;
                }
            });

            //搜索为空时相关商品推荐
            $scope.getProductHotHits =function(typeId){
                var url = '/product/getHotHits.json';
                $http({
                    method: 'get',
                    url: url,
                    params: {
                        pageSize: 5,
                        typeId: typeId,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.hotHitsProductList = response.data;
                    }
                });
            }

            //商品列表
            $scope.getProductList = function (typeId) {
                var url = '/product/getList.json';
                if ($.isTest)
                    url = '/product/getProductList.json';
                //绑定列表
                $http({
                    method: 'get',
                    url: url,
                    params: {
                        keyword: keyword,
                        typeId: typeId,
                        stamp: $.timestamp()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.productList = response.data;
                        $scope.proTotalCount = response.totalCount;

                        //返回结果为空时显示商品推荐
                        if(response.totalCount == 0){
                            $scope.getProductHotHits(typeId);
                            if(!typeId){
                                $scope.hasProduct = false;
                            }
                        }

                        if ($scope.keyword) {
                            $timeout(function () {
                                $('.product-list li a .product-name').highlight(keyword);
                            }, 100)
                        }
                        else
                            return false;

                    }
                });
            };
            $scope.getProductList();

            //筛选商品列表
            $scope.changeProductType = function (typeId) {
                $scope.productTypeId = typeId;
                $scope.getProductList(typeId);
            };

            //加入购物车
            $scope.addCart = function (event,x) {
                $.post('/cart/add', {
                    id: x.id,
                    quantity: 1
                }, function (message) {
                    $.message(message);
                    if (message.type = "success") {
                        //飞入购物车
                        seajs.use('plugin/jquery/jquery.fly.min', function () {
                            var off_set = $("#sidebar .sb_shopCart  s").offset();//抛物体终点
                            var scroll_Top = $(window).scrollTop();
                            var flyer = $('<img class="flyer-img" src="' + $scope.productList[0].mediumUrl + '">');//抛物体对象//获取当前点击图片链接
                            flyer.fly({
                                start: {
                                    left: event.pageX, //抛物体起点横坐标
                                    top: event.pageY - scroll_Top////抛物体起点纵坐标
                                },
                                end: {
                                    left: off_set.left, //抛物体终点横坐标
                                    top: off_set.top - scroll_Top + 5 //抛物体终点纵坐标
                                },
                                onEnd: function () {
                                    this.destory();//销毁抛物体
                                }
                            });
                        });
                        $scope.$emit('countNavShopCart');
                    }
                });
            }


        })

    })
})

