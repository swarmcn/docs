define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('plugin/validate.el');
    require('placeholder');
    require('plugin/message');
    require('token');//令牌，POST时必须调用
    require('bootstrap');
    require('date');
    var getQueryString = require('plugin/getQueryString');

    function checkTime(i) {
        if (i < 10) {
            i = "0" + i;
        }
        return i;
    }

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('OrderDetailCtrl', function ($scope, $http, $timeout) {

            var orderId = parseInt(getQueryString('id'));
            if (isNaN(orderId)) {
                $.message('error', '订单信息有误！');
                $timeout(function () {
                    location.href = "/member/order/index.html";
                }, 3000);
                return;
            }

            //订单状态提示
            $scope.validateOrder = function (order) {
                if (['paid', 'partialRefunds', 'drawBack'].indexOf(order.paymentStatus) > -1) {
                    if (['received', 'applyReturn', 'partialReturns'].indexOf(order.shippingStatus) > -1 && order.receiveDate)
                        location.href = "confirm.html?id=" + orderId;
                }
                else {
                    location.href = "/member/order/index.html";
                }
            };

            //倒计时
            $scope.timer = function () {
                var obj = $('[data-timer]');
                var time = obj.attr('data-timer');
                var ts = (time) - (new Date());//计算剩余的毫秒数
                var dd = parseInt(ts / 1000 / 60 / 60 / 24, 10);//计算剩余的天数
                var hh = parseInt(ts / 1000 / 60 / 60 % 24, 10);//计算剩余的小时数
                var mm = parseInt(ts / 1000 / 60 % 60, 10);//计算剩余的分钟数
                var ss = parseInt(ts / 1000 % 60, 10);//计算剩余的秒数
                if (dd >= 0) {
                    dd = checkTime(dd);
                    hh = checkTime(hh);
                    mm = checkTime(mm);
                    ss = checkTime(ss);
                    $(obj).text(dd + "天" + hh + "时" + mm + "分" + ss + "秒");
                    setTimeout(function () {
                        $scope.timer();
                    }, 1000);
                }
                else {
                    $(obj).text('');
                }
            };

            //订单详情
            var url = '/member/order/getOrderDetail.json';
            if (location.host == 'localhost')
                url = '/member/order/json/getShipped.json';
            $http.get(url + '?id=' + orderId).success(function (response) {
                if (response.success) {
                    $scope.order = response.data;
                    $scope.order.expireDate = new Date($scope.order.expireDate).getTime();
                    //判断国内和国外发货时间
                    if ($scope.order.shippingDate) {
                        var shippingDate = new Date($scope.order.shippingDate.replace(/-/g, '/')).Format("yyyy-MM-dd hh:mm:ss");
                        $scope.shippingNewDate = shippingDate;
                    }

                    if ($scope.order.airDate) {
                        var airDate = new Date($scope.order.airDate.replace(/-/g, '/')).Format("yyyy-MM-dd hh:mm:ss");
                        $scope.shippingNewDate = airDate;

                    }

                    if ($scope.order.shippingDate && $scope.order.airDate) {
                        if (shippingDate > airDate)
                            $scope.shippingNewDate = airDate;
                        else
                            $scope.shippingNewDate = shippingDate;
                    }

                    //console.log(shippingDate + "/" + airDate)
                    //console.log($scope.shippingNewDate)
                    $scope.validateOrder($scope.order);
                    $timeout(function () {
                        $scope.timer();

                        //提示工具
                        $("[data-toggle='tooltip']").tooltip();
                    }, 100);
                }
                else {
                    $.message('error', response.data);
                    $timeout(function () {
                        location.href = "/member/order/index.html";
                    }, 3000);
                }
            });

            //确认收货
            $scope.shippedSubmit = function () {
                if (confirm('您确定要收货吗？\r\n请收到货后，再确认收货！？')) {
                    $.post('/member/order/receive', {
                        id: orderId
                    }, function (response) {
                        if (response.success) {
                            //$.message('success', response.data);
                            setTimeout(function () {
                                location.href = "confirm.html?id=" + orderId;
                            }, 1500);
                        }
                        else {
                            $.message('error', response.data);
                        }
                    }, 'json').error(function (err) {
                        var msg = err.status || err;
                        $.message('error', msg);
                    });
                }
            }

            //物流信息
            $scope.status = {
                "0": "查询出错",
                "1": "暂无记录",
                "2": "在途中",
                "3": "派送中",
                "4": "已签收",
                "5": "拒收",
                "6": "疑难件",
                "7": "退回"
            };
            $scope.getDelivery = function () {
                var url = '/member/order/getDelivery.json';
                if ($.isTest)
                    url = '/member/order/getAiKD.json';
                $http({
                    method: 'get',
                    url: url,
                    params: {
                        orderId: orderId,
                        order: 'desc',
                        stamp: $.timestamp()
                    }
                }).success(function (response) {
                    //alert('success'+JSON.stringify(response))
                    if (response.data && response.data.length > 0) {
                        $scope.deliveryStatus = response.status +'';
                        $scope.deliveryList = response.data;
                        $('.container-fluid').fadeIn(300);
                    }
                }).error(function (err) {
                    alert('err'+JSON.stringify(err))
                })
            }
            $scope.getDelivery();


        })
    });
});
