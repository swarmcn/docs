define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('plugin/validate.el');
    require('placeholder');
    require('plugin/message');
    require('token');//令牌，POST时必须调用
    require('bootstrap');
    var getQueryString = require('plugin/getQueryString');
    var $showAddress = $("#showAddress");
    var $addressForm = $("#addreeForm");
    var $close = $(".close");
    var returnedForm = $('#returnedForm');
    var $sendRemind = $('#Remind');//提醒按钮


    $sendRemind.click(function () {
        alert("提醒发送成功！");
    });

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('OrderDetailCtrl', function ($scope, $http, $timeout) {

            var orderId = parseInt(getQueryString('id'));
            if (isNaN(orderId)) {
                $.message('error', '订单信息有误！');
                $timeout(function () {
                    location.href = "/member/order/index.html";
                }, 3000);
                return;
            }

            //订单状态提示
            $scope.validateOrder = function (order) {
                if (['paid','partialRefunds','drawBack'].indexOf(order.paymentStatus) > -1) {
                    document.title = '待发货-订单详情';
                    order.orderStatus = "买家已付款，等待卖家发货";
                    order.statusTip = "尊敬的客户，您的订单正在等待发货，请您耐心等待！";
                    if (order.shippingStatus == 'shipped')
                        location.href = "shipped.html?id=" + orderId;
                }
                //else if (order.paymentStatus == "drawBack") {
                //    document.title = '待退款处理-订单详情';
                //    order.orderStatus = "退款处理中！";
                //    order.statusTip = "尊敬的客户，您的订单正在处理退款，请您耐心等待！"
                //}
                else if (order.paymentStatus == "refunded")
                    location.href = "cancel.html?id=" + orderId;
                else {
                    location.href = "/member/order/index.html";
                }
                console.log($scope.statusTip)
            };


            //地址弹窗
            $showAddress.click(function () {
                //绑定收货地址列表
                $http.get('/member/receiver/getlist.json').success(function (response) {
                    if (response.success) {
                        $scope.addressList = response.data;
                        $addressForm.fadeIn(300);
                    }
                });
            });

            $close.click(function () {
                $('input:radio[name="receiverId"]:checked').attr("checked", false);
                $addressForm.fadeOut(300);
            });

            //修改保存收货地址
            $scope.saveAddress = function () {
                var AddressID = $('input:radio[name="receiverId"]:checked').val();
                if (AddressID == null) {
                    $.message('warn', '请选择要修改的地址！');
                    return false;
                }
                $http({
                    method: 'POST',
                    url: '/member/order/switchReceiver',
                    data: $addressForm.serialize(),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
                }).success(function (response) {
                    if (response.success) {
                        location.reload(true);
                        //location.href = "/member/order/detail/sendgoods.html?id=" + orderId;
                    } else {
                        $.message("error", response.data);
                    }
                });
            };

            //订单详情
            var url = '/member/order/getOrderDetail.json';
            if (location.host == 'localhost')
                url = '/member/order/json/getSendGoods.json';
            $http.get(url + '?id=' + orderId).success(function (response) {
                if (response.success) {
                    $scope.order = response.data;
                    $scope.validateOrder($scope.order);

                    $timeout(function () {
                        //提示工具
                        $("[data-toggle='tooltip']").tooltip();
                    }, 100);
                }
                else {
                    $.message('error', response.data);
                    $timeout(function () {
                        location.href = "/member/order/index.html";
                    }, 3000);
                }
            });

        })
    });
});