define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('placeholder');
    require('plugin/message');
    require('token');//令牌，POST时必须调用
    require('bootstrap');
    var getQueryString = require('plugin/getQueryString');

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('OrderDetailCtrl', function ($scope, $http, $timeout) {

            var orderId = parseInt(getQueryString('id'));
            if (isNaN(orderId)) {
                $.message('error', '订单信息有误！');
                $timeout(function () {
                    location.href = "/member/order/index.html";
                }, 3000);
                return;
            }

            //订单状态验证
            $scope.validateOrder = function (order) {

                if (order.expired) {
                    document.title = '已过期-订单详情';
                    order.statusTitle="已过期订单";
                    order.orderSta = "已过期！";
                    order.statusTip ="尊敬的客户，您的订单已过期，祝您购物愉快！";
                }
                else if(order.orderStatus == "cancelled") {
                    document.title = '已取消-订单详情';
                    order.statusTitle="已取消订单";
                    order.orderSta = "已取消！";
                    order.statusTip ="尊敬的客户，您的订单已取消，祝您购物愉快！";
                }
                else if(order.paymentStatus == "refunded") {
                    document.title = '已退款-订单详情';
                    order.statusTitle="已退款订单";
                    order.orderSta = "已退款！";
                    order.statusTip ="尊敬的客户，您的订单已退款，祝您购物愉快！";
                }
                else if(order.shippingStatus == "returned") {
                    document.title = '已退货-订单详情';
                    order.statusTitle="已退货订单";
                    order.orderSta = "已退货！";
                    order.statusTip ="尊敬的客户，您的订单已退货，祝您购物愉快！";
                }
            };

            //订单详情
            var url = '/member/order/getOrderDetail.json';
            $http.get(url + '?id=' + orderId).success(function (response) {
                if (response.success) {
                    $scope.order = response.data;
                    $scope.validateOrder($scope.order);

                    $timeout(function () {
                        //提示工具
                        $("[data-toggle='tooltip']").tooltip();
                    },100);
                }
                else {
                    $.message('error', response.data);
                    $timeout(function () {
                        location.href = "/member/order/index.html";
                    }, 3000);
                }
            });

        })
    });
});