define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('plugin/validate.el');
    require('placeholder');
    require('plugin/message');
    require('token');//令牌，POST时必须调用
    require('bootstrap');
    var getQueryString = require('plugin/getQueryString');

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('OrderDetailCtrl', function ($scope, $http, $timeout) {

            var orderId = parseInt(getQueryString('id'));
            if (isNaN(orderId)) {
                $.message('error', '订单信息有误！');
                $timeout(function () {
                    location.href = "/member/order/index.html";
                }, 3000);
                return;
            }

            //订单状态提示
            $scope.validateOrder = function (order) {
                if (['paid','partialRefunds','drawBack'].indexOf(order.paymentStatus) > -1) {
                    document.title = '交易完成-订单详情';
                    order.orderStatus = "交易完成！";
                    order.statusTip = "尊敬的客户，您的订单已完成，祝您购物愉快！";

                    //if (order.shippingStatus == "applyReturn") {
                    //    document.title = '退货订单-订单详情';
                    //
                    //    order.orderStatus = "退货处理中！";
                    //    order.statusTip = "尊敬的客户，您的订单正在处理退货，请您耐心等待！"
                    //}
                    //else if (order.shippingStatus == "commented")
                    //    location.href = "comment.html?id=" + orderId;
                }
                else {
                    location.href = "/member/order/index.html";
                }
            }

            //订单详情
            var url = '/member/order/getOrderDetail.json';
            if (location.host == 'localhost')
                url = '/member/order/json/getConfirm.json';
            $http.get(url + '?id=' + orderId).success(function (response) {
                if (response.success) {
                    $scope.order = response.data;
                    $scope.validateOrder($scope.order);

                    $scope.order.isExpiredReceived = false;
                    if($scope.order.receiveDate){
                        var receiveDate = new Date($scope.order.receiveDate.replace(/-/g,'/'));
                        if(new Date().getTime() - receiveDate.getTime() > 15 * 24 * 60 * 60 * 1000){
                            $scope.order.isExpiredReceived = true;
                        }
                    }

                    $timeout(function () {
                        $('.ng-hide').remove();

                        //提示工具
                        $("[data-toggle='tooltip']").tooltip();
                    }, 500)
                }
                else {
                    $.message('error', response.data);
                    $timeout(function () {
                        location.href = "/member/order/index.html";
                    }, 3000);
                }
            });

        })
    });
});