define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('plugin/validate.el');
    require('placeholder');
    require('plugin/message');
    require('token');//令牌，POST时必须调用
    var getQueryString = require('plugin/getQueryString');
    var $commentFrom = $('#commentFrom');

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('OrderDetailCtrl', function ($scope, $http, $timeout) {

            $scope.order = {"isCommented": true};
            var orderId = parseInt(getQueryString('id'));
            if (isNaN(orderId)) {
                $.message('error', '订单信息有误！');
                $timeout(function () {
                    location.href = "/member/order/index.html";
                }, 3000);
                return;
            }

            //订单状态提示
            $scope.validateOrder = function (order) {
                if (order.paymentStatus == "paid" || order.paymentStatus == "partialRefunds" || order.paymentStatus == "drawBack") {
                    //if (!order.isCommented)
                    //    location.href = "confirm.html?id=" + orderId;
                }
                else
                    location.href = "/member/order/index.html";
            };


            //订单详情
            var url = '/member/order/getComment.json';
            if (location.host == 'localhost')
                url = '/member/order/json/getComment.json';
            $http.get(url + '?id=' + orderId).success(function (response) {
                if (response.success) {
                    $scope.order = response.data;
                    $scope.validateOrder($scope.order);

                    //已经评论
                    if ($scope.order.isCommented) {
                        $timeout(function () {
                            $('.comment .ng-hide').remove();
                        }, 100);
                    }

                    //没有商品列表
                    if(!$scope.order.items){
                        location.href = "/member/order/index.html";
                    }
                }
                else {
                    $.message('error', response.data);
                    $timeout(function () {
                        location.href = "/member/order/index.html";
                    }, 3000);
                }
            });

            $scope.send = function () {
                if ($('[name="scoreCount"][value="0"]')[0]) {
                    $.message('warn', '亲，给商品评个星吧！');
                    return;
                }

                $http({
                    method: 'POST',
                    url: '/member/order/comment',
                    data: $commentFrom.serialize(),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
                }).success(function (response) {
                    if (response.success) {
                        $.each($scope.order.items, function (n, x) {
                            x.commentDate = response.data;
                        });
                        $scope.order.isCommented = true;
                        $("html, body").animate({scrollTop: 0}, 200);
                    } else {
                        $.message('error', response.data);
                    }
                });
            }
        })
    });
});