define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('placeholder');
    require('plugin/message');
    require('token');//令牌，POST时必须调用
    require('bootstrap');
    var getQueryString = require('plugin/getQueryString');
    var $showAddress = $("#showAddress");
    var $addressForm = $("#addreeForm");
    var $close = $(".close");

    function checkTime(i) {
        if (i < 10 && i > -1) {
            i = "0" + i;
        }
        return i;
    }

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('OrderDetailCtrl', function ($scope, $http, $timeout) {

            var orderId = parseInt(getQueryString('id'));
            if (isNaN(orderId)) {
                $.message('error', '订单信息有误！');
                $timeout(function () {
                    location.href = "/member/order/index.html";
                }, 3000);
                return;
            }

            //订单状态验证
            $scope.validateOrder = function (order) {
                if (order.paymentStatus == "unpaid") {
                    if (order.orderStatus == "cancelled")
                        location.href = "cancel.html?id=" + orderId;
                }
                else if (order.paymentStatus == "paid") {
                    location.href = "sendGoods.html?id=" + orderId;
                }
                else {
                    location.href = "/member/order/index.html";
                }
            };

            //地址弹窗
            $showAddress.click(function () {
                //绑定收货地址列表
                $http.get('/member/receiver/getlist.json').success(function (response) {
                    if (response.success) {
                        $scope.addressList = response.data;
                        $addressForm.fadeIn(300);
                    }
                });
            });

            $close.click(function () {
                $('input:radio[name="receiverId"]:checked').attr("checked", false);
                $addressForm.fadeOut(300);
            });

            //修改保存收货地址
            $scope.saveAddress = function () {
                var receiverId = $('input:radio[name="receiverId"]:checked').val();
                if (receiverId == null) {
                    $.message('warn', '请选择要修改的地址！');
                    return false;
                }
                $http({
                    method: 'POST',
                    url: '/member/order/switchReceiver',
                    data: $addressForm.serialize(),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
                }).success(function (response) {
                    if (response.success) {
                        location.reload(true);
                    } else {
                        $.message("error", response.data);
                    }
                });
            }

            //取消订单
            $scope.deleteOrder = function () {
                if (confirm('您确定要取消订单吗？')) {
                    $.ajax({
                        url: '/member/order/cancel',
                        type: "POST",
                        dataType: "json",
                        data: {id: orderId},
                        success: function (response) {
                            $.message(response);
                            if (response.type == "success") {
                                $timeout(function () {
                                    location.href = "cancel.html?id=" + orderId;
                                }, 3000);
                            }
                        }
                    });
                }
            }

            //立即付款
            $scope.toPayment = function () {
                $.postForm('/payment/submit', {id: orderId});
            };

            //倒计时
            $scope.timer = function () {
                var obj = $('[data-timer]');
                var time = obj.attr('data-timer');
                var ts = (time) - (new Date());//计算剩余的毫秒数
                var dd = parseInt(ts / 1000 / 60 / 60 / 24, 10);//计算剩余的天数
                var hh = parseInt(ts / 1000 / 60 / 60 % 24, 10);//计算剩余的小时数
                var mm = parseInt(ts / 1000 / 60 % 60, 10);//计算剩余的分钟数
                var ss = parseInt(ts / 1000 % 60, 10);//计算剩余的秒数
                if(dd >= 0) {
                    dd = checkTime(dd);
                    hh = checkTime(hh);
                    mm = checkTime(mm);
                    ss = checkTime(ss);
                    $(obj).text(dd + "天" + hh + "时" + mm + "分" + ss + "秒");
                    setTimeout(function () {
                        $scope.timer();
                    }, 1000);
                }
                else{
                    $(obj).text('');
                }
            };

            //订单详情
            var url = '/member/order/getOrderDetail.json';
            if (location.host == 'localhost')
                url = '/member/order/json/getUnPaid.json';
            $http.get(url + '?id=' + orderId).success(function (response) {
                if (response.success) {
                    $scope.order = response.data;

                    $scope.order.expireDate = new Date($scope.order.expireDate.replace(/-/g,'/')).getTime();
                    $scope.validateOrder($scope.order);

                    $timeout(function () {
                        $scope.timer();

                        //提示工具
                        $("[data-toggle='tooltip']").tooltip();
                    }, 100);
                }
                else {
                    $.message('error', response.data);
                    $timeout(function () {
                        location.href = "/member/order/index.html";
                    }, 3000);
                }
            });

        })

    });
});