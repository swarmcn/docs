define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('plugin/validate.el');
    require('placeholder');
    require('plugin/message');
    require('token');//令牌，POST时必须调用
    var getQueryString = require('plugin/getQueryString');

    var timestamp = new Date().getTime();
    var returnedForm = $('#returnedForm');
    var itemId = parseInt(getQueryString('itemId'));

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('paymentCtrl', function ($scope, $http, $timeout) {

            //$scope.status = 2;
            $scope.quantity = 0;//退件数
            $scope.amount = 0;//总金额

            if (isNaN(itemId)) {
                $.message('error', '订单信息有误！');
                $timeout(function () {
                    location.href = "/member/order/index.html?ts=" + timestamp;
                }, 3000);
                return;
            }

            //订单状态提示
            $scope.validateOrder = function (order) {
                if (order.paymentStatus != 'unpaid' && order.paymentStatus != 'refunded') {
                    if (order.shippingStatus == "unshipped") {
                        $scope.status = 1;
                        document.title = '申请退款 - 订单详情';
                        $scope.title = "退款";
                    }
                    else {//已发货
                        $scope.status = 2;
                        document.title = '申请退货退款 - 订单详情';
                        $scope.title = "退货退款";
                    }
                }
                else {
                    location.href = "/member/order/index.html?ts=" + timestamp;
                }
            };

            //统计
            $scope.count = function (des) {
                if (des) {
                    $scope.quantity = Math.min($scope.quantity + des, $scope.item.maxQuantity);
                    if ($scope.quantity < 0)
                        $scope.quantity = 0;
                } else {
                    if (/^\d*[0-9]\d*$/.test($scope.quantity)) {
                        $scope.quantity = Math.min($scope.quantity, $scope.item.maxQuantity);
                    } else {
                        $scope.quantity = 0;
                    }
                    $scope.quantity = parseInt($scope.quantity) || 0;
                }
                $scope.amount = $scope.item.refundPrice * $scope.quantity;
            };

            //退货商品
            $http.get('/member/order/getRefundable.json?itemId=' + itemId).success(function (response) {
                if (!response.success) {
                    $.message('error', response.data || '退货信息有误！');
                    $timeout(function () {
                        location.href = "/member/order/index.html";
                    }, 3000);
                } else {
                    $scope.item = response.data;
                    $scope.validateOrder($scope.item);
                    $timeout(function () {
                        $('.ng-hide').remove();
                    }, 500);

                    $scope.reason = '';
                    if ($scope.item.shippingStatus == "unshipped") {
                        $scope.status = 1;
                        $scope.type = 1;
                    }
                    else {
                        $scope.status = 2;
                        $scope.type = null;
                    }
                }
            });


            //提交退款信息
            $scope.SubmitApply = function () {

                if($scope.quantity <= 0){
                    $scope.quantity = 0;
                    $.message('warn', '请选择商品件数！');
                    return;
                }

                if(!$scope.type) {
                    $('[name="type"]:eq(0)').focus();
                    return;
                }

                if(!$scope.reason) {
                    $('[name="reason"]').focus();
                    return;
                }

                var url;
                if ($scope.status == 1 || $scope.type == 1)
                    url = "/member/order/drawbackItem";
                else
                    url = "/member/order/applyReturnItem";

                $.ajax({
                    url: url,
                    type: "POST",
                    dataType: "json",
                    data: {
                        itemId:itemId,
                        quantity:$scope.quantity,
                        reason:$scope.reason,
                        desp:$scope.desp
                    },
                    success: function (response) {
                        if (response.success) {
                            $.message("success", response.data);
                            $timeout(function () {
                                if ($scope.item.shippingStatus == "unshipped")
                                    location.href = "/member/order/index.html?type=2";
                                    //location.href = "/member/order/detail/sendgoods.html?id=" + orderId;
                                else
                                    location.href = "/member/order/index.html";
                                    //location.href = "/member/order/detail/confirm.html?id=" + orderId;
                            }, 2000);
                        }
                        else {
                            $.message("error", response.data);
                        }
                    }
                });
            };
        });
    });
});