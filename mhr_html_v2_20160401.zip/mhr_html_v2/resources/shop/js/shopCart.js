define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('token');//令牌，POST时必须调用
    require('cookie');
    require('plugin/message');
    require('plugin/validate.el');
    require('plugin/icheck/icheck.sea');

    var $submit = $("#submit");
    var $effectivePrice = $('#effectivePrice');
    var $effectivePriceCNY = $('#effectivePriceCNY');
    var $effectivePoint = $('#effectivePoint');
    var $selectCount = $('#selectCount');
    var $submitOrderForm = $('#selectCount');
    var $checkAll = $('#checkAll');
    var $mj=$('#mj');
    var $priceTotal = $('.PriceTotal');

    //限购
    var LimitNum = 5;
    var isLimitBy = function (id) {
        var startTime = new Date('2015/08/15 00:00:00').getTime();
        var endTime = new Date('2015/08/16 23:59:59').getTime();
        var nowTime = new Date().getTime();
        var b = false;
        if(nowTime >= startTime && nowTime < endTime) {
            var limitBuy = ['773', '386', '440', '1058', '1053', '465', '464', '399', '463', '462', '878'];
            b = (limitBuy.indexOf(id.toString()) > -1);
        }
        return b;
    };

    //千位加逗号
    function addCommas(nStr) {
        nStr += '';
        x = nStr.split('.');
        x1 = x[0];
        x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        }
        return x1 + x2;
    }

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller("ShopCartCtrl", function($scope,$http,$timeout) {

            $scope.isLimitBy = function(id){
                return isLimitBy(id);
            };
            $scope.LimitNum = LimitNum;


            //满减
            var url = '/promotion/getFullSubtract.json';
            if (location.host == 'localhost')
                url = '/admin/marketing/getFullSubtract.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.fullCut = response.data;
                }
            })


            $timeout(function () {
                //不显示导航购物车
                $('.shop-cart').remove();
            },100);

            //编辑时，双击限制
            $scope.dblClick = function (x) {
                //800毫秒内连点只提交一次请求
                var timeId = 'pre_time' + x.itemId;
                var c_timeId = $.cookie(timeId)
                var cookietime = new Date();
                cookietime.setTime(cookietime.getTime() + 1000);
                if(c_timeId == null) {
                    $.cookie(timeId, x.quantity, { expires: cookietime, path: '/' });
                    setTimeout(function(){
                        if($.cookie(timeId) == null)
                            $scope.edit(x);//edit请求
                    }, 1000);
                }
            }

            //设置个数
            $scope.setQuantity = function (event, x, keyWay) {
                var key = event.keyCode ? event.keyCode : event.which;
                if (key == 39) {//右加
                    $scope.increase(x);
                }
                else if (key == 37) {
                    //左减
                    $scope.decrease(x);
                }
                else {
                    var quantity = $(event.target).val();
                    if(isLimitBy(x.productId)) {
                        quantity = x.quantity = LimitNum;
                        //return;
                    }
                    if (/^\d*[1-9]\d*$/.test(quantity)) {
                        x.quantity = Math.min(quantity, x.stock || 10000);
                    }
                    else {
                        x.quantity = 1;
                    }
                    $scope.dblClick(x);
                }
            };


            //增加个数
            $scope.increase = function (x) {
                var quantity = x.quantity;
                quantity =  parseInt(quantity) + 1;
                if(isLimitBy(x.productId)) {
                    if(quantity > LimitNum)
                    {
                        quantity = x.quantity = LimitNum;
                        return;
                    }

                }
                if (/^\d*[1-9]\d*$/.test(quantity)) {
                    x.quantity = Math.min(quantity, x.stock || 10000);
                } else {
                    x.quantity = 1;
                }
                $('#input'+ x.itemId).val(x.quantity);
                $scope.dblClick(x);
            };

            //减少个数
            $scope.decrease = function (x) {
                var quantity = x.quantity;
                if (/^\d*[1-9]\d*$/.test(quantity) && parseInt(quantity) > 1) {
                    x.quantity = parseInt(quantity) - 1;
                } else {
                    x.quantity = 1;
                }
                $('#input'+ x.itemId).val(x.quantity);
                $scope.dblClick(x);
            };

            //删除商品
            $scope.delete = function (event,x) {
                var id = x.itemId;
                var pt = $(event.target).parents('tr').eq(0);
                if(confirm('您确定要删除吗？')) {
                    $.post('/cart/delete',{
                        id:id
                    }, function (response) {
                        if (response.success) {
                            x.checked = false;
                            $scope.count();
                            pt.fadeOut(800, function () {
                                $(this).remove();
                                $scope.count();
                            });
                        }else{
                            $.message('error',response.data);
                        }
                    },'json').error(function (err) {
                        var msg = err.status || err;
                        $.message('error', '@'+msg);
                    });
                }
            };

            //统计总和
            $scope.count = function (){

                var count = 0;
                //var effectivePrice = 0.00;
                var effectivePriceCNY = 0.00;
                var cartItems = [];
                var cookie_cartItems = $.cookie('checked_cart_items') || '';
                var c_cartItems = cookie_cartItems.replace(/%2c/g,',');
                if(c_cartItems)
                    c_cartItems += ',';

                var i = 0,c = 0;
                var isFirst = false;

                //console.log(c_cartItems);
                if($scope.cartList && $scope.cartList.length > 0) {
                    $.each($scope.cartList, function (n, x) {
                        var chk = $('[value="'+n+'"]:checkbox');
                        x.checked = chk.attr('checked') == 'checked';
                        if($('.icheckbox_square-blue').length == 0) {
                            isFirst = true;
                            if (c_cartItems.length == 0 || c_cartItems.indexOf(x.itemId + ',') != -1)
                                x.checked = true;
                            else
                                x.checked = false;
                        }
                        else {
                            isFirst = false;
                        }
                        if (x.checked) {
                            count ++;
                            //effectivePrice += (x.price * x.quantity) || 0.00;
                            effectivePriceCNY += (x.price * x.quantity) || 0.00;

                            cartItems.push(x.itemId);
                            i++;
                            if (isFirst)
                                c++;

                            chk.attr('checked','checked');
                        }
                        else
                            chk.removeAttr('checked');

                        $('#input' + x.itemId).attr('data-value', x.quantity);
                    });
                    //$effectivePrice.text('$' + addCommas(effectivePrice.toFixed(2)));
                    var amount = effectivePriceCNY.toFixed(2);

                    //满减
                    $http.get('/promotion/getFullSubtract.json').success(function (response) {
                        if(response.success) {
                            $scope.fullCut = response.data;

                            var fullCutItems = $scope.fullCut;
                            //$mj.text("0.00");
                            $priceTotal.text(addCommas(amount));
                            $scope.subtractAmount=0.00;
                            for (var i = 0; i < fullCutItems.length; i++) {

                                var item = fullCutItems[i];
                                if (amount >= item.fullAmount) {
                                    //$mj.text(addCommas(item.subtractAmount.toFixed(2)));
                                    $scope.subtractAmount=item.subtractAmount.toFixed(2);
                                    amount = amount - item.subtractAmount.toFixed(2);
                                    $effectivePriceCNY.text(addCommas(amount.toFixed(2)));
                                    return;
                                }

                            }
                            $effectivePriceCNY.text(addCommas(amount));
                        }
                    })
                    $scope.amount = amount;
                    $scope.selectCount = count;


                    $selectCount.text(count);

                    //已选商品itemId,数组：12,13,15,30
                    if(cartItems)
                        $.cookie('checked_cart_items', cartItems, {path: '/'});
                    var $checks = $('.sp-list td :checkbox');
                    var chkLen = $('.sp-list td :checkbox:checked').length;
                    if (chkLen == $checks.length) {
                        $checkAll.attr('checked','checked');
                    }
                }
            };

            $scope.initCheck = function () {
                var $checks = $('.sp-list td :checkbox');
                var list = $scope.cartList;

                //单选
                $checks.on('ifChecked', function (event) {
                    var el = $(event.target);
                    el.prop("checked",true);
                    el.attr("checked","checked");

                    if($('.sp-list td :checkbox:checked').length == $('.sp-list td :checkbox').length){
                        $checkAll.prop("checked",true);
                        $checkAll.parent().addClass('checked');
                    }

                    $scope.count();
                });
                $checks.on('ifUnchecked', function(event){
                    var el = $(event.target);
                    el.prop("checked",false);
                    el.removeAttr("checked");

                    if($('.sp-list td :checkbox:checked').length != $('.sp-list td :checkbox').length){
                        $checkAll.prop("checked",false);
                        $checkAll.parent().removeClass('checked');
                    }

                    $scope.count();
                });
                $checks.iCheck({
                    checkboxClass: 'icheckbox_square-blue',
                    increaseArea: '30%' // optional
                });

                //全选、反选
                $checkAll.on('ifChecked', function(event){
                    $checks.iCheck('check');
                });
                $checkAll.on('ifUnchecked', function(event){
                    $checks.iCheck('uncheck');
                });
                $checkAll.iCheck({
                    checkboxClass: 'icheckbox_square-blue',
                    increaseArea: '30%' // optional
                });
            };

            //实时编辑
            $scope.edit = function (x) {
                var ipt = $('#input'+ x.itemId);
                var usd = $('#priceUSD'+ x.itemId);
                var cny = $('#priceCNY'+ x.itemId);
                var lowStock = $('#isLowStock'+ x.itemId);
                var newQuantity = x.quantity;
                var oldQuantity = ipt.attr('data-value');
                if((newQuantity == x.stock || newQuantity == 1) && oldQuantity == newQuantity){
                    //已到库存最大值或最小值，不提交
                    ipt.attr('data-value', newQuantity);
                    ipt.val(newQuantity);
                }else {
                    $submit.prop("disabled", true);
                    $.post('/cart/edit', {
                        id: x.itemId,
                        quantity: newQuantity,
                        stamp: new Date().getTime()
                    }, function (data) {
                        if (data.message.type == "success") {
                            ipt.attr('data-value', newQuantity);
                            ipt.val(newQuantity);

                            usd.text('$' + addCommas((x.price * x.quantity).toFixed(2)));
                            cny.text(addCommas((x.price * x.quantity).toFixed(2)));

                            $scope.count();
                            lowStock.addClass('ng-hide');
                            //$scope.updatePrice();
                        }
                        else {
                            $.message(data.message);
                            x.quantity = oldQuantity;
                            ipt.val(oldQuantity);
                        }
                        $submit.prop("disabled", false);
                    }, 'json').error(function (err) {
                        var msg = err.status || err;
                        $.message('error', '@' + msg);
                        $submit.prop("disabled", false);
                        x.quantity = oldQuantity;
                        ipt.val(oldQuantity);
                    })
                }
            };


            //提交订单
            $scope.submitOrder = function () {

                var cart_items = $.cookie('checked_cart_items');
                if(cart_items == null || cart_items == ""){
                    $.message('warn','请勾选商品');
                    return;
                }

                var isLimitTotal = false;
                var amount = parseFloat($('#effectivePriceCNY').text().replace(',',''));
                console.log(amount);
                if (amount > 1000){
                    if($scope.selectCount > 1)
                        isLimitTotal = true;
                    else {
                        var quantity =  parseInt($('.sp-list [name="quantity"]:eq(0)').val() || 1);
                        if(quantity > 1)
                            isLimitTotal = true;
                    }
                }
                if(isLimitTotal){
                    $('#limitTotalImg').removeClass('ng-hide');
                    $timeout(function () {
                        $('#limitTotalImg').addClass('ng-hide').fadeOut(1000);
                    },4000);
                    return;
                }


                if (!$.checkLogin()) {
                    $.redirectToLogin("/cart/index.html", "必须登录后才能去结算订单");
                    return false;
                }
                 else{
                    $scope.count();
                    location.href = '/member/order/info.html';
                }
            };

            //清空购物车
            $scope.clear = function () {
                if(confirm('您确定要清空吗？')){
                    $.post('/cart/clear', function () {
                        location.reload(true);
                    },'json');
                }
            };

            //绑定列表
            $http.get('/cart/getCartList.json?isPage=true&stamp='+new Date().getTime()).success(function (response) {
                if(response.success) {
                    $scope.cartList = response.items;
                    $scope.effectivePrice = response.effectivePrice;
                    $scope.effectivePriceCNY = response.effectivePriceCNY;

                    $scope.effectivePoint = response.effectivePoint;
                    $scope.isLogin = $.cookie('username') != null;//登录状态

                    $.each($scope.cartList,function (n,x) {
                        if(isLimitBy(x.productId) && x.quantity > LimitNum){
                            x.quantity = LimitNum;
                            $scope.edit(x);
                        }
                    });

                    $timeout(function () {
                        $.pageLoading('hide');
                        $scope.count();
                        //InitCartList();
                        $scope.initCheck();
                    },100);
                }
            });
        });
    });
});