define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    var getQueryString = require('plugin/getQueryString');
    var id = getQueryString('id');

    //判断手机端，重定向至微商城
    var uaRedirect = require('plugin/uaredirect');
    uaRedirect('/weixin/theme/detail.html?id=' + id);

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('themesDetailCtrl', function ($scope, $http, $timeout) {

            //相关主题
            $scope.getSiblingsTheme = function (typeId,callback) {
                $http({
                    method: 'get',
                    url: '/theme/getList.json',
                    params: {
                        typeId: typeId,
                        isHasProducts: false,
                        pageNumber: 1,
                        pageSize: 4,
                        stamp: $.timestamp()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.getThemList = response.data;

                        //剔除重复主题
                        var delIndex = -1;
                        for (var i = 0; i < $scope.getThemList.length; i++) {
                            if ($scope.getThemList[i].id == id) delIndex = i;
                        }
                        $scope.getThemList.splice(delIndex, 1);

                        //没有相关时，推荐其他主题
                        if($scope.getThemList.length == 0 && typeof callback == 'function'){
                            callback();
                        }
                    }
                })
            };

            //主题详情
            var url = '/theme/getDetail.json';
            if ($.isTest)
                url = '/theme/getDetail.json';
            $scope.t = {enabled: null};
            $http.get(url + '?id=' + id).success(function (response) {
                if (response.success) {
                    $scope.t = response.data;
                    $scope.t.enabled = true;
                    document.title = $scope.t.title + ' - 美日惠，家门口的海外药妆店！';

                    //有商品的时候
                    if ($scope.t.productItems && $scope.t.productItems.length > 0) {
                        //获取商品信息
                        function getProduct(id) {
                            var p = {};
                            $.each($scope.t.productItems, function (n, x) {
                                if (x.id == id) p = x;
                            });
                            return p;
                        }

                        //组装商品集合
                        var $temp = $('.temp-content').html($scope.t.content);
                        $('div.productItems', $temp).each(function () {
                            var el = $(this).addClass('recommend-product-list');
                            var pids = el.text().replace(/}{/g, ',').replace(/}|{/g, '').split(',');
                            el.html('<div class="recommend-boeder"></div><span class="recommend-txt">为你推荐</span><div class="product-list"><ul></ul>');
                            for (var i = 0; i < pids.length; i++) {
                                var x = getProduct(pids[i]);
                                var html = '<li><a href="/product/detail.html?id=' + x.id + '" target="_blank">' +
                                    '<img src="' + x.mediumUrl + '">' +
                                    '<div class="name">' + x.name + '</div>' +
                                    '<div class="price">¥' + x.price + '</div></a></li>'
                                el.find('ul').append(html);
                            }
                            el.prev('br').remove();
                            el.next('br').remove();
                        });
                        $scope.t.content = $temp.html();
                        $temp.remove()
                    }

                    $timeout(function () {
                        //统计主题点击数
                        $.get('/theme/hits/' + id);
                    },1000);

                    //相关主题
                    $scope.getSiblingsTheme($scope.t.typeId, function () {
                        $scope.getSiblingsTheme();
                    })
                }
                else{
                    $scope.t = {enabled: false};
                }
            });

        })
    })
})