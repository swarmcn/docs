define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('owl-carousel');
    require('plugin/unslider');
    var getQueryString = require('plugin/getQueryString');
    var typeId = getQueryString('typeId');


    function initFlexslider() {
        $('.unslider').fadeIn(300).each(function () {
            var unslider = $(this).unslider({
                speed: 500,               //  The speed to animate each slide (in milliseconds)
                delay: false,              //  The delay between slide animations (in milliseconds)
                keys: false,               //  Enable keyboard (left, right) arrow shortcuts
                dots: false,               //  Display dot navigation
                fluid: false
            });
            $('.unslider-arrow', unslider).click(function () {
                var fn = this.className.split(' ')[1];
                //  Either do unslider.data('unslider').next() or .prev() depending on the className
                unslider.data('unslider')[fn]();
            });
        })
    }

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller("themesCtrl", function ($scope, $http, $timeout) {
            $scope.typeId = typeId;

            //主题分类
            var url = ' /theme/type/getList.json';
            if ($.isTest)
                url = '/theme/typeList.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.themesTypeList = response.data;
                }
            });

            //更多推荐
            $scope.themeList = [];
            var isCanScroll = true;
            var $pageSize = 20;
            $scope.pageSize = $pageSize;
            $scope.currentPage = 0;
            var cookiePageNumber = parseInt(sessionStorage.getItem("pc-theme-page") || 0);
            var cookieTypeId = parseInt(sessionStorage.getItem("pc-theme-typeId") || $scope.typeId);
            $scope.getThemesList = function () {
                isCanScroll = false;
                var pageSize = $scope.pageSize;
                if ($scope.themeList.length == 0 && cookieTypeId == $scope.typeId) {
                    pageSize = $scope.pageSize * cookiePageNumber;
                }
                $http({
                    method: 'get',
                    url: '/theme/getList.json',
                    params: {
                        isHasProducts: true,
                        typeId: $scope.typeId,
                        pageNumber: $scope.currentPage + 1,
                        pageSize: pageSize,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    $scope.totalCount = response.totalCount;

                    if (response.success && response.data) {
                        $.each(response.data, function (n, x) {
                            $scope.themeList.push(x);
                        });
                        if ($scope.themeList.length >= response.totalCount)
                            isCanScroll = false;
                        else {
                            isCanScroll = true;
                            if (pageSize > $pageSize)
                                $scope.currentPage += pageSize / $pageSize;
                            else
                                $scope.currentPage++;
                        }

                        if (window.sessionStorage){
                            sessionStorage.setItem("pc-theme-page", $scope.currentPage);
                            sessionStorage.setItem("pc-theme-typeId", $scope.typeId);
                        }

                        $timeout(function () {
                            initFlexslider();
                        }, 100)
                    } else {
                        if (response.totalCount == 0) {
                            isCanScroll = false;
                        }
                    }
                })
            };
            $scope.getThemesList();

            //滚动加载
            $(window).scroll(function () {
                var ds = $(document).scrollTop();//滚动条到顶部的垂直高度
                var dh = $(document).height() - 350;//页面的文档高度
                var wh = $(window).height();//浏览器的高度
                if (ds + wh >= dh && isCanScroll)//当文档的高度小于或者等于总的高度的时候，开始动态加载数据
                {
                    $scope.getThemesList();
                    isCanScroll = false;
                }
            });
        })
    })

});