/**
 * Created by sg009 on 15/六月/26.
 */
define(function(require,exports,module) {
    require('angularJs');
    require('jquery');

    //调用myApp
   seajs.use('header', function (ex) {
        var myApp = ex.myApp;

       //replace
       myApp.filter(
           'replace', ['$sce', function ($sce) {
               return function (text, param1, param2) {
                   var re = new RegExp(param1, "g");
                   if(text)
                       return text.replace(re, param2);
                   else
                       return text;
               }
           }]
       );


       myApp.config(function($routeProvider){
            $routeProvider
                .when('/logistics/4',{
                    templateUrl:'logistics/4.html',
                    controller:'helpLogistics',
                    publicAccess: true
                })

                .when('/:type/:id',{
                    templateUrl:'help.html',
                    publicAccess: true,
                    controller:'helpCenterCtrl'
                })

                .otherwise({
                    redirectTo: '/school/1'
                });
        })


        myApp.controller('helpCenterCtrl', function ($scope,$http,$timeout,$routeParams) {
            $scope.content = '';
            $scope.type = $routeParams.type || 'school';
            $scope.id = $routeParams.id || 1;

            var li=$('.help_sidebar a[href="#/'+$scope.type +'/'+ $scope.id+'"]').parent();
            $('.help_sidebar li').removeClass('active');
            $('.helpTitle').text(li.text());

            li.addClass('active');
            $http.get('/help/' + $scope.type + '/' + $scope.id + '.html?stamp='+new Date().getTime()).success(function (response) {
                if(response.indexOf('404') == -1 && response.length>0) {
                    $scope.content = response;
                    $scope.random = new Date().getTime();
                }
                else{
                    $scope.content = "暂无";
                }
            }).error(function () {
                $scope.content = "暂无";
            });

            $("html, body").animate({scrollTop:199},200);

        });

       //运费列表
       myApp.controller('helpLogistics', function ($scope,$http,$timeout) {
           var li=$('.help_sidebar a[href="#/'+$scope.type +'/'+ $scope.id+'"]').parent();
           $('.help_sidebar li').removeClass('active');
           $('.help_sidebar a[href="#/logistics/4"]').parent().addClass('active');
           $('.helpTitle').text($('.help_sidebar a[href="#/logistics/4"]').parent().text());

           $http.get('/product/getFreight.json?ts=' + new Date().getTime()).success(function (response) {
               if (response.success) {
                   $scope.freightList = response.data;
                   $timeout(function(){
                       $('.tb-yunfei').show();
                   },300)

               }
           });
       });

    });
});