define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('pagination');
    var setUrlParam = require('plugin/setUrlParam');
    var getQueryString = require('plugin/getQueryString');
    var typeId = getQueryString('typeId');


    //初始化分页
    var pageSize = 20;

    function InitPagination(box, totalCount, callback) {
        if (!$('.pagination ul', box)[0]) {
            $('.pagination', box).pagination({
                currentPage: 1,
                items: totalCount || 0,
                itemsOnPage: pageSize,
                displayedPages: 3,
                prevText: '<',
                nextText: '>',
                cssStyle: 'default-theme',
                onPageClick: function (pageNumber) {
                    callback(pageNumber);
                }
            });
        }
    }

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller("productCtrl", function ($scope, $http, $timeout) {
            $scope.pageSize = pageSize;
            $scope.typeId = typeId;
            $scope.orderType = getQueryString('orderType') || 'dateDesc';
            $scope.startPrice = getQueryString('startPrice');
            $scope.endPrice = getQueryString('endPrice');

            //商品列表
            $scope.getProductList = function (pageNumber) {
                $scope.pageNumber = pageNumber;
                var url = '/product/getList.json';
                if ($.isTest)
                    url = '/product/getProductList.json';
                //绑定列表
                $http({
                    method: 'get',
                    url: url,
                    params: {
                        startPrice:$scope.startPrice,
                        endPrice:$scope.endPrice,
                        orderType: $scope.orderType,
                        typeId: typeId,
                        pageNumber: pageNumber,
                        pageSize: pageSize,
                        stamp: $.timestamp()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.productList = response.data;
                        $scope.totalCount = response.totalCount;
                        InitPagination('.product-pagination', $scope.totalCount, function (pageNumber) {
                            $scope.getProductList(pageNumber);
                        })
                    }
                });
            };
            $scope.getProductList(1);

            //排序
            $scope.setOrderType = function (orderType) {
                location.href = setUrlParam(location.href,'orderType',orderType);
            };

            //价格
            $scope.setPrice = function () {
                $scope.startPrice = $scope.startPrice || 0;
                if($scope.startPrice + ($scope.endPrice || 0) > 0 && $scope.startPrice < ($scope.endPrice || 10000000)) {
                    var url = location.href;
                    url = setUrlParam(url, 'startPrice', $scope.startPrice || 0);
                    location.href = setUrlParam(url, 'endPrice', $scope.endPrice);
                }
            };

            //商品分类
            var url = '/product_category/getList.json';
            if ($.isTest)
                url = '/theme/typeList.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.productTypeList = response.data;
                }
            });

            //加入购物车
            $scope.addCart = function (event, x) {
                $.post('/cart/add', {
                    id: x.id,
                    quantity: 1
                }, function (message) {
                    $.message(message);
                    if (message.type = "success") {
                        //飞入购物车
                        seajs.use('plugin/jquery/jquery.fly.min', function () {
                            var off_set = $("#sidebar .sb_shopCart  s").offset();//抛物体终点
                            var scroll_Top = $(window).scrollTop();
                            var flyer = $('<img class="flyer-img" src="' + $scope.productList[0].mediumUrl + '">');//抛物体对象//获取当前点击图片链接
                            flyer.fly({
                                start: {
                                    left: event.pageX, //抛物体起点横坐标
                                    top: event.pageY - scroll_Top////抛物体起点纵坐标
                                },
                                end: {
                                    left: off_set.left, //抛物体终点横坐标
                                    top: off_set.top - scroll_Top + 5 //抛物体终点纵坐标
                                },
                                onEnd: function () {
                                    this.destory();//销毁抛物体
                                }
                            });
                        });
                        $scope.$emit('countNavShopCart');
                    }
                });
            }

        })
    })
});
