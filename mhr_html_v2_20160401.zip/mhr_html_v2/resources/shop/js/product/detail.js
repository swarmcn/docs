define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('token');//令牌，POST时必须调用
    require('cookie');
    require('unveil');
    require('validate');
    require('plugin/message');
    require('pagination');

    var base64 = require('plugin/encrypt/base64');
    var getQueryString = require('plugin/getQueryString');

    //判断手机端，重定向至微商城
    var uaRedirect = require('plugin/uaredirect');
    uaRedirect('/weixin/product/detail.html?id=' + getQueryString('id'));

    var productId = getQueryString('id');
    var $quantity = $("#quantity");
    var $increase = $("#increase");
    var $decrease = $("#decrease");

    var $addBuy = $("#addBuy");
    var $addCart = $("#addCart");
    var $addFavorite = $(".addFavorite");
    var $deliveryArea = $('.deliveryArea');
    var $areaBox = $('.areaBox');

    //限购
    var LimitNum = 5;
    var isLimitBy = function () {
        var startTime = new Date('2015/08/15 00:00:00').getTime();
        var endTime = new Date('2015/08/16 23:59:59').getTime();
        var nowTime = new Date().getTime();
        var b = false;
        if (nowTime >= startTime && nowTime < endTime) {
            var limitBuy = ['773', '386', '440', '1058', '1053', '465', '464', '399', '463', '462', '878'];
            b = (limitBuy.indexOf(productId) > -1);
        }
        return b;
    };


    //增加购买数量
    $increase.click(function () {
        var quantityMax = parseInt($quantity.attr('max'));
        var quantity = $quantity.val();
        if (isLimitBy()) {
            quantityMax = LimitNum;
        }
        if (/^\d*[1-9]\d*$/.test(quantity)) {
            $quantity.val(Math.min(parseInt(quantity) + 1, quantityMax));
        } else {
            $quantity.val(1);
        }
    });

    //减少购买数量
    $decrease.click(function () {
        var quantity = $quantity.val();
        if (/^\d*[1-9]\d*$/.test(quantity) && parseInt(quantity) > 1) {
            $quantity.val(parseInt(quantity) - 1);
        } else {
            $quantity.val(1);
        }
    });

    //购买数量
    $quantity.keydown(function (event) {
        var key = event.keyCode ? event.keyCode : event.which;
        if (key == 39) {//右加
            $increase.click().addClass('active');
        } else if (key == 37) {//左减
            $decrease.click().addClass('active');
        }
    }).keyup(function (event) {
        var quantity = $(this).val();
        if (!/^\d*[1-9]\d*$/.test(quantity))
            quantity = 1;
        var key = event.keyCode ? event.keyCode : event.which;
        if (key == 39) {//右加
            $increase.removeClass('active');
        } else if (key == 37) {//左减
            $decrease.removeClass('active');
        } else {
            var quantityMax = parseInt($quantity.attr('max'));
            if (isLimitBy()) {
                quantityMax = LimitNum;
            }
            $(this).val(Math.min(parseInt(quantity), quantityMax));
        }
    });


    //初始化图片区域
    var InitProductImages = function () {
        //图片放大
        require('plugin/jquery/jquery.jqzoom-core.sea.js');
        $('#zoom').jqzoom({
            zoomType: 'standard',
            lens: true,
            alwaysOn: false,
            zoomWidth: 400,
            zoomHeight: 360,
            title: false
        });

        //宝贝页面大图下面小图滚动
        var simg_n = $(".detail-img-list li").length;
        $(".tb-thumb .arr-r").click(function () {
            $(".detail-img-list").animate({
                left: "-72px"
            }, 300, function () {
                $(".detail-img-list").css({
                    left: "0px"
                }).find("li:first").appendTo(".detail-img-list");
            });
        });
        $(".tb-thumb .arr-l").click(function () {
            $(".detail-img-list").animate({
                left: "72px"
            }, 300, function () {
                $(".detail-img-list").css({
                    left: "0px"
                }).find("li:first").appendTo(".detail-img-list");
            });
        });

        $('img').unveil(0, function () {
            $(this).load(function () {
                this.style.opacity = 1;
            })
        }, 100);
    };

    //商品详情选项卡
    jQuery.jqtab = function (tabtit, tab_conbox, shijian) {
        $(tab_conbox).find("li").hide();
        $(tabtit).find("li:first").addClass("current").show();
        $(tab_conbox).find("li:first").show();

        $(tabtit).find("li").bind(shijian, function () {
            $(this).addClass("current").siblings("li").removeClass("current");
            var activeindex = $(tabtit).find("li").index(this);
            $(tab_conbox).children().eq(activeindex).removeClass('hide');
            $(tab_conbox).children().eq(activeindex).show().siblings().hide();
        });
    };

    /*选项卡调用方法如下：*/
    $.jqtab("#shopXqTab", ".tab-content", "click");

    //微信二维码
    seajs.use('plugin/jquery/jquery.qrcode.min', function () {
        $(".scan-QR .qrcode").qrcode({
            //render: "table", //table方式
            width: 160, //宽度
            height: 160, //高度
            text: 'http://' + location.host.replace('www.','') + "/weixin/product/detail.html?id=" + productId,
            src: '/resources/images/mi.png',
            imgWidth: 32,
            imgHeight: 32
        });
    });


    //初始化分页
    var pageSize = 20;

    function InitPagination(box, totalCount, callback) {
        if (!$('.pagination ul', box)[0]) {
            $('.pagination', box).pagination({
                currentPage: 1,
                items: totalCount || 0,
                itemsOnPage: pageSize,
                displayedPages: 3,
                prevText: '<',
                nextText: '>',
                cssStyle: 'default-theme',
                onPageClick: function (pageNumber) {
                    callback(pageNumber);
                }
            });
        }
    }

    //点击其他区域关闭区域选择
    $(document).click(function () {
        $deliveryArea.removeClass('open').find('span > .fa').removeClass('fa-rotate-180');
        $('.areaBox').addClass('ng-hide');
    });
    $(document).delegate('.deliveryArea > span,.areaBox', 'click', function (event) {
        event.stopPropagation();
    });


    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        //replace
        myApp.filter(
            'replace', ['$sce', function ($sce) {
                return function (text, param1, param2) {
                    var re = new RegExp(param1, "g");
                    if (text)
                        return text.replace(re, param2);
                    else
                        return text;
                }
            }]
        );

        myApp.controller('productDetailCtrl', function ($scope, $http, $timeout) {

            //相关主题
            $scope.getTheme = function (x) {
                $http({
                    method: 'get',
                    url: '/theme/getList.json',
                    params: {
                        typeId: x.themeTypeId,
                        isHasProducts: true,
                        pageNumber: 1,
                        pageSize: 2,
                        stamp: $.timestamp()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.getThemList = response.data;
                    }
                });

                //推荐商品
                if (x.themeId) {
                    $http.get('/theme/getProducts.json?id=' + x.themeId).success(function (response) {
                        if (response.success) {
                            $scope.getProductList = response.data;

                            //剔除当前商品
                            var delIndex = -1;
                            $.each($scope.getProductList, function (n,x) {
                                if(x.id == productId)
                                    delIndex = n;
                            });
                            if(delIndex > -1)
                                $scope.getProductList.splice(delIndex,1);
                        }
                    });
                }
            };

            //运费列表
            $scope.getFreightList = function (callback) {
                if (!$scope.freightList) {
                    $http.get('/product/getFreight.json?ts=' + new Date().getTime()).success(function (response) {
                        if (response.success) {
                            $scope.freightList = response.data;
                            if (typeof callback == 'function')
                                callback();
                        }
                    });
                } else {
                    if (typeof callback == 'function')
                        callback();
                }
            };

            $scope.toggleAreaBox = function (isOpen) {
                if (isOpen != null)
                    $scope.areaBox = isOpen;
                else {
                    $deliveryArea.toggleClass('open').find('span > .fa').toggleClass('fa-rotate-180');
                    $('.areaBox').toggleClass('ng-hide');
                    $scope.areaBox = $deliveryArea.hasClass('open');
                }
            };

            //绑定地区
            var isLocal = (location.hostname == 'localhost');
            $scope.freight = 0;
            $scope.freeFreightAmount = 0;
            $scope.provinceId = 926;
            $scope.cityId = 927;
            $scope.deliveryProvince = remote_ip_info.province || '浙江';
            $scope.deliveryCity = remote_ip_info.city || '杭州';
            $scope.deliveryTo = (remote_ip_info.province || '浙江') + (remote_ip_info.city || '杭州');

            var url = '/common/areas/getList.json';
            if (isLocal)
                url = '/member/areas/getList.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.provinceList = response.data;
                    $.each($scope.provinceList, function (n, x) {
                        if (x.name.indexOf($scope.deliveryProvince) > -1) {
                            $scope.deliveryProvince = x.name;
                            $scope.provinceId = x.id;
                        }
                    });
                    if($scope.provinceId) {
                        //获取市
                        url = '/common/areas/getList.json?parentId=' + $scope.provinceId;
                        if (isLocal)
                            url = '/member/areas/getCity.json';
                        $http.get(url).success(function (response) {
                            if (response.success) {
                                $scope.cityList = response.data;
                                $.each($scope.cityList, function (n, x) {
                                    if (x.name.indexOf($scope.deliveryCity) > -1) {
                                        $scope.deliveryCity = x.name;
                                        $scope.cityId = x.id;
                                        $scope.deliveryTo = $scope.deliveryProvince + $scope.deliveryCity;
                                        $scope.getFreightList(function () {
                                            $scope.getFreightByList();
                                        });
                                    }
                                });
                            }
                        });
                    }
                }
            });
            //获取市列表
            $scope.getCityList = function (x) {
                $scope.deliveryProvince = x.name;
                $scope.provinceId = x.id;
                $scope.deliveryCity = null;
                url = '/common/areas/getList.json?parentId=' + x.id;
                if (isLocal)
                    url = '/member/areas/getCity.json';
                $http.get(url).success(function (response) {
                    if (response.success) {
                        $scope.cityList = response.data;
                        if($scope.cityList.length == 1){
                            $scope.getFreight($scope.cityList[0]);
                        }
                    }
                });
            };

            //通过列表筛选运费
            $scope.getFreightByList = function () {
                var isFocus = false;
                var isFocus2 = false;

                //获取运费
                $.each($scope.freightList.items, function (n, x) {
                    //市
                    if (!isFocus && x.deliveryAreaNames.indexOf($scope.deliveryCity) > -1) {
                        isFocus = true;
                        $scope.freight = (x.firstPrice / x.firstWeight) + $scope.freightList.sharePrice;
                    }
                });
                $.each($scope.freightList.items, function (n, x) {
                    //省
                    if (!isFocus && x.deliveryAreaNames.indexOf($scope.deliveryProvince) > -1) {
                        isFocus = true;
                        $scope.freight = (x.firstPrice / x.firstWeight) + $scope.freightList.sharePrice;
                    }
                });


                //获取包邮
                $scope.freeFreightAmount = 0;
                $.each($scope.freightList.freeItems, function (n, x) {
                    //市
                    if (!isFocus2 && x.freeAreaNames.indexOf($scope.deliveryCity) > -1 && x.freeType == 'amount') {
                        isFocus2 = true;
                        $scope.freeFreightAmount = x.freeAmount;
                    }
                });
                $.each($scope.freightList.freeItems, function (n, x) {
                    //省
                    if (!isFocus2 && x.freeAreaNames.indexOf($scope.deliveryProvince) > -1 && x.freeType == 'amount') {
                        isFocus2 = true;
                        $scope.freeFreightAmount = x.freeAmount;
                    }
                });

                if($scope.deliveryProvince.indexOf($scope.deliveryCity) > -1)
                    $scope.deliveryTo = $scope.deliveryProvince;
                else
                    $scope.deliveryTo = $scope.deliveryProvince + $scope.deliveryCity;
                $scope.areaBox = false;
            };

            //获取运费
            $scope.getFreight = function (x) {
                $scope.deliveryCity = x.name;
                $scope.cityId = x.id;
                $scope.getFreightList(function () {
                    $scope.getFreightByList();
                });
            };

            $scope.getFreightList();

            $scope.pageSize = pageSize;
            $scope.isLimitBy = isLimitBy();
            $scope.LimitNum = LimitNum;

            //满减
            var url = '/promotion/getFullSubtract.json';
            if (location.host == 'localhost:8080')
                url = '/admin/marketing/getFullSubtract.json';
            $http.get(url).success(function (response) {
                if (response.success) {
                    $scope.fullCut = response.data;

                    $scope.title = '';
                    if ($scope.fullCut) {
                        $.each($scope.fullCut, function (n, x) {
                            $scope.title += '满' + x.fullAmount + '元' + '减' + x.subtractAmount + '元' + '  ';
                        });
                    }

                }
            });


            //默认图片
            $scope.blankImgUrl = '//365meirihui.com/resources/images/blank.gif';
            $scope.defaultLargeUrl = "//365meirihui.com/resources/images/default_large.jpg";
            $scope.defaultMediumUrl = "//365meirihui.com/resources/images/default_medium.jpg";
            $scope.defaultThumbnailUrl = "//365meirihui.com/resources/images/default_thumbnail.jpg";

            //绑定数据
            $http.get('/product/getDetail.json?id=' + productId).success(function (response) {
                if (response.success) {
                    $scope.p = response.data;
                    $scope.p.id = productId;
                    $scope.p.scope = Math.ceil($scope.p.scope || 0);//向上取整,有小数就整数部分加1


                    //相关商品
                    $scope.getTheme($scope.p);


                    //商品简介
                    if ($scope.p.introduction && $scope.p.introduction.indexOf('img') != -1)
                        $scope.p.introduction = $scope.p.introduction.replace(/src=/g, 'src=\'' + $scope.blankImgUrl + '\' unveil-src=');
                    document.title = $scope.p.name + ' - 美日惠，家门口的海外药妆店！';
                    $timeout(function () {
                        //先加载第一张
                        $('.detail-xq img:eq(0)').attr('src', $('.detail-xq img:eq(0)').attr('unveil-src'));

                        InitProductImages();
                        $.pageLoading('hide');
                        if ($('.specification dd a').length == 1) {
                            $('.specification dd a').addClass('selected');
                        } else {
                            $('.specification [val=' + productId + ']').addClass('selected');
                        }

                        //格式化价格
                        $('.f-price').each(function () {
                            var el = $(this);
                            var text = el.text();
                            if (!el.children('font')[0] && text.indexOf('¥') > -1) {
                                if (text.indexOf('.') > -1) {
                                    text = text.split('.')[0] + '.' + '<font class="f-price-decimal">' + text.split('.')[1] + '</font>'
                                }
                                el.html('<font class="f-price-unit">¥</font>' + text.replace('¥', ''));
                            }
                        });
                    }, 10);


                    $timeout(function () {
                        //统计商品点击数
                        $.get('/product/hits/' + productId);
                    },1000);
                }
                else {
                    $timeout(function () {
                        alert(response.data || '商品不存在！');
                        if (document.referrer)
                            location.href = document.referrer;
                        else
                            location.href = '/index.html';
                    }, 0);
                }

                //若已登录，判断是否收藏
                $scope.isLogin = ($.cookie('username') != null);

                if ($scope.isLogin) {
                    $http.get("/member/favorite/isexist.json?id=" + productId).success(function (response) {
                        if (response.success) {
                            $addFavorite.addClass('selected');
                        }
                    })
                }
            });

            //立即购买
            $scope.addBuy = function () {

                var price = parseFloat($('#price').val());
                var total = price * parseInt($quantity.val());
                if (total > 1000 && parseInt($quantity.val()) > 1) {
                    $.message("warn", "[ 海关蜀黍说 ] 过关订单单笔最高金额不能超过1000元，否则将有扣留、退运风险！请拆单购买～", 5000);
                    return;
                }

                var str = base64.encode('{ "productId": ' + productId + ', "quantity": ' + $quantity.val() + ' }');
                var href = '/member/order/info.html?b=' + str;
                if (!$.checkLogin()) {
                    //需登录才能访问的页面
                    $.redirectToLogin(href);
                }
                else {
                    location.href = href;
                }
            };

            //加入购物车
            $scope.addCart = function (event) {
                var quantity = $quantity.val();
                if (/^\d*[1-9]\d*$/.test(quantity) && parseInt(quantity) > 0) {

                    var price = parseFloat($('#price').val());
                    var total = price * parseInt(quantity);
                    if (total > 1000) {
                        $.message("warn", "[ 海关蜀黍说 ] 过关订单单笔最高金额不能超过1000元，否则将有扣留、退运风险！请拆单购买～", 5000);
                        return;
                    }
                    $.post('/cart/add', {
                        id: productId,
                        quantity: quantity
                    }, function (message) {
                        $.message(message);
                        if (message.type == "success") {

                            //飞入购物车
                            seajs.use('plugin/jquery/jquery.fly.min', function () {
                                var off_set = $("#sidebar .sb_shopCart  s").offset();//抛物体终点
                                console.log(off_set)
                                var scrollTop = $(window).scrollTop();
                                var flyer = $('<img class="flyer-img" src="' + $scope.p.productImages[0].thumbnail + '">');//抛物体对象//获取当前点击图片链接
                                flyer.fly({
                                    start: {
                                        left: event.pageX, //抛物体起点横坐标
                                        top: event.pageY - scrollTop////抛物体起点纵坐标
                                    },
                                    end: {
                                        left: off_set.left, //抛物体终点横坐标
                                        top: off_set.top - scrollTop + 5 //抛物体终点纵坐标
                                    },
                                    onEnd: function () {
                                        this.destory();//销毁抛物体
                                    }
                                });
                            });

                            $scope.$emit('countNavShopCart');
                        }
                    });
                } else {
                    $.message("warn", "数量必须为正整数");
                }
            };


            //获取评论列表
            $scope.getEvaluationList = function (pageNumber) {
                $scope.pageNumber = pageNumber;

                //绑定列表
                $http({
                    method: 'get',
                    url: '/product/getCommentList.json?id=' + productId,
                    params: {
                        pageNumber: pageNumber,
                        pageSize: pageSize,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.EvaluationList = response;
                        $scope.commentTotalCount = response.totalCount

                        InitPagination('.detail-pingjia', response.totalCount, function (pageNumber) {
                            $scope.getEvaluationList(pageNumber);
                        })
                    }
                });
            };
            $scope.getEvaluationList(1);


            //获取交易记录
            $scope.getEvaRecordList = function (pageNumber) {
                $scope.pageNumber = pageNumber;

                //绑定列表
                $http({
                    method: 'get',
                    url: '/product/getOrderItemList.json?id=' + productId,
                    params: {
                        pageNumber: pageNumber,
                        pageSize: pageSize,
                        stamp: new Date().getTime()
                    }
                }).success(function (response) {
                    if (response.success) {
                        $scope.EvaRecordList = response;
                        $scope.EvaRecordTotalCount = response.totalCount;

                        //$('.EvaRecordCount').text(response.totalCount);
                        InitPagination('.detail-chengjiao', response.totalCount, function (pageNumber) {
                            $scope.getEvaRecordList(pageNumber);
                        })
                    }
                });
            }
            $scope.getEvaRecordList(1);


            //加入收藏
            $scope.addFavorite = function (event) {
                if ($addFavorite.hasClass('selected')) {
                    $.post('/member/favorite/del.json?id=' + productId,
                        function (response) {
                            if (response.success) {
                                $.message('success', response.data);
                                $addFavorite.removeClass('selected');
                            }
                            else {
                                $.message('error', response.data);
                            }

                        }, 'json');
                }
                else {
                    $.ajax({
                        url: "/member/favorite/add.json?id=" + productId,
                        type: "POST",
                        dataType: "json",
                        cache: false,
                        success: function (response) {
                            if (response.success) {
                                $.message('success', response.data);
                                $addFavorite.addClass('selected');
                            }
                            else {
                                $.message('error', response.data);
                            }

                        }
                    });
                }
            };
        });
    });
});