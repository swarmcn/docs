/**
 * Created by mrh001 on 15/6/30.
 */
define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('token');//令牌，POST时必须调用
    require('header');
    require('validate');
    require('unveil');
    require('pagination');
    require('plugin/validate.el');

    var getQueryString = require('plugin/getQueryString');
    var setUrlParam = require('plugin/setUrlParam');
    var $delegate = require('plugin/delegateEvent');

    var $searchOrderForm = $('#searchOrderForm');
    var $keyword = $searchOrderForm.find('[name="key"]');
    var $orderList = $('#orderList');
    var $orderEmptyTip = $('#orderEmptyTip').hide();
    var $beginDate = $('#createDate1').prop('readOnly', true).val(getQueryString('beginDate'));
    var $endDate = $('#createDate2').prop('readOnly', true).val(getQueryString('endDate'));


    //筛选下拉框
    var $orderSelect = $("#orderSelect");
    $orderSelect.mouseover(function () {
        var $this = $(this);
        var offset = $this.offset();
        var $menuWrap = $this.closest("div.orderSelect");
        var $popupMenu = $menuWrap.children("div.popupMenu");
        $popupMenu.show();
        $menuWrap.mouseleave(function () {
            $popupMenu.hide();
        });
    });


    //查看物流、查看退款
    $(document).click(function () {
        $('#orderList div.pop').removeClass('open');
    });
    $delegate('#orderList div.pop', {
        'click': function (event) {
            event.stopPropagation();//排除自己
            $(this).toggleClass('open');
        }
    });

    //初始化分页
    var pageSize = 10;
    var pageNumber = getQueryString('page') || 1;
    var keyword = unescape(getQueryString('key'));
    var type = getQueryString('type');
    $keyword.val(keyword);


    //搜索表单，内容为空不提交
    $searchOrderForm.submit(function () {
        event.preventDefault();
        if ($keyword.val().length > 0)
            type = '';
        location.href = 'index.html?type=' + type + '&beginDate=' + $beginDate.val() + '&endDate=' + $endDate.val() + '&key=' + encodeURI($keyword.val());
    });

    ////订单状态
    //var OrderStatus = {
    //    //"unconfirmed":"",
    //    //"confirmed":"",
    //    "completed": "已完成",
    //    "cancelled": "已取消"
    //};
    //
    ////订单状态
    //var PaymentStatus = {
    //    //"unpaid":"",
    //    //"paid":"",
    //    //"refunded": "已退款",
    //    //"drawBack": "已申请退款"
    //};
    //
    ////发货状态
    //var ShippingStatus = {
    //    //"unshipped":"未发货",
    //    //"partialShipment":"部分发货",
    //    "applyReturn": "已申请退货",//
    //    "shipped": "已发货",
    //    //"partialReturns":"部分退货",//
    //    "returned": "已退货"
    //};

    require('plugin/jquery-ui/jquery-ui.css');
    seajs.use('plugin/jquery-ui/jquery-ui-1.11.4', function () {
        $beginDate.datepicker({
            changeYear: true,
            changeMonth: true,
            showOtherMonths: true,
            selectOtherMonths: true,
            dateFormat: "yy-mm-dd",
            onClose: function (selectedDate) {
                $endDate.datepicker("option", "minDate", selectedDate);
            }
        });
        $endDate.datepicker({
            changeYear: true,
            changeMonth: true,
            showOtherMonths: true,
            selectOtherMonths: true,
            dateFormat: "yy-mm-dd",
            onClose: function (selectedDate) {
                $beginDate.datepicker("option", "maxDate", selectedDate);
            }
        });
    });

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller("orderListCtrl", function ($scope, $http, $timeout) {
            $scope.orderType = type;

            //设置状态
            $scope.setOrderStats = function (order) {
                if (order.expired)
                    order.statusContent = '已过期';
                else {
                    if (order.orderStatus == "cancelled")
                        order.statusContent = '已取消';
                    else if (order.paymentStatus == "unpaid") {
                        order.statusContent = '<span class="f-red">等待付款</span>';
                    }
                    else {
                        order.statusContent = '交易成功';
                        if (order.shippingStatus == "unshipped")
                            order.statusContent = '等待发货';
                        if (['shipped','applyReturn','partialReturns'].indexOf(order.shippingStatus) > -1 && !order.receiveDate)
                            order.statusContent = '已发货';
                        if (order.isCommented)
                            order.statusContent = '交易完成';//已评价
                    }
                }
            };

            //设置按钮url
            $scope.setOrderBtn = function (order) {
                order.pathName = 'cancel';
                if (!order.expired && order.orderStatus != "cancelled") {
                    if (order.paymentStatus == "unpaid")
                        order.pathName = 'unpaid';//未支付，拍下商品页
                    else if (['paid','partialRefunds','drawBack'].indexOf(order.paymentStatus) > -1) {
                        order.pathName = 'sendgoods';//付款页
                        if (['shipped','applyReturn','partialReturns'].indexOf(order.shippingStatus) > -1 && !order.receiveDate)
                            order.pathName = 'shipped';//卖家发货
                        if (['received','applyReturn','partialReturns'].indexOf(order.shippingStatus) > -1 && order.receiveDate)
                            order.pathName = 'confirm';//确认收货完，去评价
                        if (order.shippingStatus == "returned")
                            order.pathName = 'cancel';
                    }
                    else if (order.paymentStatus == "refunded" || order.shippingStatus == "returned") {
                        order.pathName = 'cancel';
                    }
                } else {
                    order.pathName = 'cancel';
                }
            };

            //立即付款
            $scope.toPayment = function (orderId) {
                $.postForm('/payment/submit', {id: orderId}, '_blank');
            };

            //确认收货
            $scope.confirm = function (orderId) {
                if (confirm('您确定要收货吗？\r\n请收到货后，再确认收货！')) {
                    $.post('/member/order/receive', {
                        id: orderId
                    }, function (response) {
                        if (response.success) {
                            //$.message('success', response.data);
                            setTimeout(function () {
                                location.reload(true);
                            }, 1500);
                        } else {
                            $.message('error', response.data);
                        }
                    }, 'json');
                }
            };

            //取消订单
            $scope.cancel = function (id) {
                if (confirm('您确定要取消订单吗？')) {
                    $.ajax({
                        url: '/member/order/cancel',
                        type: "POST",
                        dataType: "json",
                        data: {id: id},
                        success: function (response) {
                            $.message(response);
                            if (response.type = "success") {
                                $timeout(function () {
                                    window.location.reload(true);
                                }, 1500);
                            }
                        }
                    })
                }
            };

            //绑定列表
            $http.get('/member/order/getOrderList.json', {
                params: {
                    type: getQueryString('type'),
                    beginDate: getQueryString('beginDate'),
                    endDate: getQueryString('endDate'),
                    keyword: keyword,
                    pageNumber: pageNumber,
                    pageSize: pageSize,
                    stamp: new Date().getTime()
                }
            }).success(function (response) {
                if (response.success) {
                    $scope.orderList = response.orders;
                    if (response.totalCount == 0) {
                        if (location.search != '?type=' + getQueryString('type'))
                            $orderEmptyTip.show();
                    }
                    else {
                        $.each($scope.orderList, function (n, order) {
                            $scope.setOrderBtn(order);
                            $scope.setOrderStats(order);

                            order.isExpiredReceived = false;
                            if (order.receiveDate) {
                                var receiveDate = new Date(order.receiveDate.replace(/-/g, '/'));
                                if (new Date().getTime() - receiveDate.getTime() > 15 * 86400000) {
                                    order.isExpiredReceived = true;
                                }
                            }
                            if (order.createDate) {
                                order.createDate = new Date(order.createDate).getTime();
                            }
                        });

                        //图片延迟加载
                        $timeout(function () {
                            $('img').unveil(0, function () {
                                $(this).load(function () {
                                    this.style.opacity = 1;
                                });
                            }, 100);

                            if (response.totalCount > pageSize) {
                                $('.pagination').pagination({
                                    currentPage: pageNumber,
                                    items: response.totalCount,
                                    itemsOnPage: pageSize,
                                    displayedPages: 3,
                                    prevText: '<',
                                    nextText: '>',
                                    cssStyle: 'default-theme',
                                    onPageClick: function (pageNumber) {
                                        location.href = setUrlParam(location.href, 'page', pageNumber);
                                    }
                                });
                            }
                        }, 100);

                        $timeout(function () {
                            $('#orderList .ng-hide').remove();
                        }, 500);
                    }
                }
                else {
                    $orderEmptyTip.show();
                }
            });


            //填充已保存的运单信息
            $scope.changeTrackingNo = function () {
                $scope.deliveryCorp = '';
                $scope.trackingNo = '';
                $.each($scope.applyReturnList, function (n, x) {
                    if (x.id == $scope.returnId) {
                        $scope.deliveryCorp = x.deliveryCorp;
                        $scope.trackingNo = x.trackingNo;
                    }
                });
            };

            //弹出层
            var $waybill = $('.waybill_box');
            $scope.showWaybill = function (itemId) {
                //$scope.itemId = itemId;
                $scope.returnId = '';
                $scope.deliveryCorp = '';
                $scope.trackingNo = '';
                $http.get('/member/order/getApplyReturnList.json?itemId=' + itemId).success(function (response) {
                    if (response.success) {
                        $scope.applyReturnList = response.data;
                        if ($scope.applyReturnList.length == 1) {
                            $scope.returnId = $scope.applyReturnList[0].id;
                            $scope.changeTrackingNo();
                        } else {
                            $('[name="returnId"]').attr('autofocus', 'autofocus');
                            $('[name="deliveryCorp"]').removeAttr('autofocus');
                        }
                        $waybill.fadeIn(300);
                    }
                });
            };

            //保存运单
            $scope.saveWaybill = function (b) {
                if (b) {
                    var data = $waybill.serializeObject();
                    if (!data.returnId) {
                        $('[name="returnId"]').focus();
                        return;
                    }
                    if (!data.deliveryCorp) {
                        $('[name="deliveryCorp"]').focus();
                        return;
                    }
                    if (!data.trackingNo) {
                        $('[name="trackingNo"]').focus();
                        return;
                    }
                    $.post('/member/order/addTrackingNo', data, function (response) {
                        if (response.success) {
                            $.message('success', response.data || '提交成功！');
                            $waybill.fadeOut(300);
                        }
                        else
                            $.message('error', response.data);
                    }, 'json');
                } else
                    $waybill.fadeOut(300);
            };
        })

    })
});