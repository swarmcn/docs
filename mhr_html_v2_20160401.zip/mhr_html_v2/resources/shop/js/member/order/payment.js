/**
 * Created by sg009 on 15/七月/8.
 */

define(function(require,exports,module) {
    require('angularJs');
    require('jquery');
    require('header');
    require('validate');
    require('plugin/message');
    require('token');//令牌，POST时必须调用

    var getQueryString = require('plugin/getQueryString');

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller("orderPaymentCtrl",function($scope,$http,$timeout){

            var ordeSN = getQueryString('SN');
            if(ordeSN == '')
            {
                $.message('error','订单号有误！');
                $timeout(function () {
                    location.href = "/member/order/index.html";
                },3000);
            }
            else
            {
                $.post('/member/order/checkOrder', {
                    sn: ordeSN
                }, function (response) {
                    if (response.success) {
                        $scope.ordeSN = ordeSN;
                        $scope.orderId = response.data;
                    }
                    else {
                        //$.message('error', response.data);
                        $scope.orderMsg = response.data;
                    }
                },'json').error(function (err) {
                    $scope.orderMsg = err.status;
                });
            }
        })
    })
});
