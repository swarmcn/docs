/**
 * Created by mrh001 on 15/6/30.
 */
define(function(require,exports,module) {
    require('angularJs');
    require('jquery');
    require('token');//令牌，POST时必须调用
    require('header');
    require('validate');
    require('plugin/message');


    var $inputForm = $("#inputForm");
    var $submit = $(":submit",$inputForm);
    $(function () {
        $("#currentPassword").focus();
    });

    // 表单验证
    $inputForm.validate({
        rules: {
            currentPassword: {
                required: true,
                remote: {
                    url: "/member/password/check_current_password",
                    cache: false
                }
            },
            password: {
                required: true,
                pattern: /^[^\s&\"<>]+$/,
                minlength:6,
                maxlength:20
            },
            rePassword: {
                required: true,
                equalTo: "#password"
            }
        },
        messages: {
            password: {
                pattern: "非法字符"
            }
        },
        submitHandler: function(form) {
            $.ajax({
                url: '/member/password/update',
                type: "POST",
                data: $inputForm.serialize(),
                dataType: "json",
                cache: false,
                beforeSend: function() {
                    $submit.prop("disabled", true);
                },
                success: function(response) {
                    $submit.prop("disabled", false);
                    if(response.success){
                        $.message('success',response.data);
                        setTimeout(function () {
                            location.reload();
                        },2500);
                    }
                    else{
                        $.message('warn',response.data);
                    }
                }
            });
        }
    });
});