/**
 * Created by mrh001 on 15/6/30.
 */
define(function(require,exports,module) {
    require('angularJs');
    require('jquery');
    require('unveil');

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller("favoriteListCtrl",function($scope,$http,$timeout){
            $http.get("/member/favorite/getlist.json").success(function(response){
                if(response.success)
                    $scope.favoriteList = response.data;

                //图片延迟加载
                $timeout(function () {
                    $('.mc-fav-list img').unveil(0, function () {
                        $(this).load(function () {
                            this.style.opacity = 1;
                        })
                    }, 100);
                },0);


            });

            $scope.serachFavorite = function () {
                $timeout(function () {
                    $('.mc-fav-list img').unveil(0, function () {
                        $(this).load(function () {
                            this.style.opacity = 1;
                        })
                    }, 100);
                },100);
            };

            //删除收藏商品
            $scope.delete = function (el,id) {
                el = el.target;
                var pt = $(el).parents('li').eq(0);
                if(confirm('您确定要删除吗？')) {
                    $.post('/member/favorite/del.json',{
                        id:id
                    }, function (data) {
                        if(data.success)
                        {
                            pt.fadeOut(500, function () {
                            $(this).remove();
                            });
                        }

                        //if (data.message.type == "success") {
                        //    pt.fadeOut(500, function () {
                        //        $(this).remove();
                        //    });
                        //}else{
                        //    $.message(data.message);
                        //}
                    },'json').error(function (err) {
                        var msg = err.status || err;
                        $.message('error',msg);
                    });
                }
            }

            //加入购物车
            $scope.addCart = function (el,x) {

                $.post('/cart/add', {
                    id: x.id,
                    quantity: 1
                }, function (response) {
                    $.message(response);
                    if (response.type == "success") {

                        //飞入购物车
                        seajs.use('plugin/jquery/jquery.fly.min', function () {
                            var offset = $("#sidebar .shopCart > i").offset();//抛物体终点
                            var scrollTop = $(window).scrollTop();
                            var flyer = $('<img class="flyer-img" src="' + x.thumbnailUrl + '">');//抛物体对象//获取当前点击图片链接
                            flyer.fly({
                                start: {
                                    left: el.pageX, //抛物体起点横坐标
                                    top: el.pageY - scrollTop////抛物体起点纵坐标
                                },
                                end: {
                                    left: offset.left, //抛物体终点横坐标
                                    top: offset.top - scrollTop + 5 //抛物体终点纵坐标
                                },
                                onEnd: function() {
                                    this.destory();//销毁抛物体
                                }
                            });
                        });

                        //统计购物车
                        $scope.$emit('countNavShopCart');
                    }
                }, 'json');
            };
        })

    })

});