/**
 * Created by mrh001 on 15/6/30.
 */
define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('plugin/validate.el');
    require('placeholder');
    require('plugin/message');
    require('token');//令牌，POST时必须调用

    var $select = $('.selectArea select');
    var areaSelect = require('share/js/addrSelect');
    var Validate = require('plugin/validate.el');
    var $addressForm = $('#addressForm');
    var $addressList = $('#addressList');

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        //登录状态
        myApp.controller("AddressCtrl", function ($scope, $http, $timeout) {
            $scope.areaCode1 = '';
            $scope.areaCode2 = '';
            $scope.areaCode3 = '';
            $scope.isDefault = false;
            $scope.address = '';
            $scope.idCard = '';
            $scope.phone = '';
            $scope.zipCode = '';//邮编
            $scope.consignee = '';//收货人
            $scope.incomplete = false;

            $scope.getList = function () {
                //绑定列表
                var stamp = new Date().getTime();
                $http.get('/member/receiver/getlist.json?stamp=' + stamp).success(function (response) {
                    if (response.success) {
                        $scope.addressList = response.data;

                        $timeout(function () {
                            areaSelect($select);
                            $.pageLoading('hide');
                        }, 100);
                    }
                });
            };
            $scope.getList();

            //监听变动
            $scope.test = function () {
                $scope.incomplete = false;
                if (!$scope.address.length || !$scope.phone.length || !$scope.idCard.length || !$scope.zipCode.length || !$scope.consignee.length) {
                    $scope.incomplete = true;
                }
            };

            $scope.$watch('address', function () {
                $scope.test();
            });
            $scope.$watch('idCard', function () {
                $scope.test();
            });
            $scope.$watch('phone', function () {
                $scope.test();
            });
            $scope.$watch('zipCode', function () {
                $scope.test();
            });
            $scope.$watch('consignee', function () {
                $scope.test();
            });

            //编辑
            $scope.editAddr = function (index) {
                $scope.incomplete = false;
                var o = $scope.addressList[index];
                $scope.id = o.id;
                $scope.areaCode1 = o.areaCode1;
                $scope.areaCode2 = o.areaCode2;
                $scope.areaCode3 = o.areaCode3;
                $scope.address = o.address;
                $scope.idCard = o.idCard;
                $scope.phone = o.phone;
                $scope.zipCode = o.zipCode;
                $scope.consignee = o.consignee;
                $scope.isDefault = o.isDefault;
                if($scope.areaCode3 != $select.last().val()) {
                    $timeout(function () {
                        areaSelect($select);
                    }, 100);
                }
                $("html, body").animate({scrollTop: 0}, 200);
            };

            //保存
            $scope.saveAddr = function () {
                var len = $('tbody tr', $addressList).length;
                if (len == 20) {
                    $.message('warn', '收货地址数量已到上限');
                    return;
                }

                var resIdCard = Validate.checkformat('.idCard');
                if (!resIdCard.res) {
                    $.message('warn', resIdCard.msg + '不正确');
                    return false;
                }

                var resPhone = Validate.checkformat('.phone');
                if (!resPhone.res) {
                    $.message('warn', resPhone.msg + '不正确');
                    return false;
                }

                var url = '/member/receiver/update.json';//更新
                var data = $addressForm.serializeObject();
                data.isDefault = $scope.isDefault ? true : false;
                data.areaCode3 = $('[name="areaCode3"]').val() || 0;
                $.post(url, data, function (response) {
                    if (response.success) {
                        $.message('success', '保存成功');
                        //if (sessionStorage.getItem('WXDebug'))
                        //    return;
                        $timeout(function () {
                            window.location.reload();
                        }, 1500);
                    }
                    else
                        $.message('error', response.data);
                }, 'json');
            };

            //设为默认
            $scope.setDefault = function (el, sn) {
                sn = parseInt(sn);
                var $this = $scope.addressList[sn];
                $.ajax({
                    url: '/member/receiver/setdefault.json',
                    type: "POST",
                    dataType: "json",
                    data: {id: $this.id},
                    success: function (response) {
                        if (response.success) {
                            //设为默认
                            $.message('success', response.data);
                            $scope.getList();
                        }
                        else {
                            $.message("error", response.data);
                        }
                    }
                });

            };

            //删除
            $scope.deleteAddr = function (el, id) {
                el = $(el.target);
                var pt = el.parents('tr').eq(0);
                var iptId = $('[name="id"]', $addressForm);
                if (confirm('您确定要删除吗？')) {
                    $.ajax({
                        url: '/member/receiver/del.json',
                        type: "POST",
                        dataType: "json",
                        data: {id: id},
                        success: function (response) {
                            if (response.success) {
                                $.message("success", response.data);
                                pt.fadeOut(800, function () {
                                    $(this).remove();

                                    var len = $('tbody tr', $addressList).length;
                                    $addressList.prev('h3').text('已保存' + len + '条地址，还能保存' + (20 - len) + '条地址');

                                    //若编辑区的内容已删除，则清空ID
                                    if (iptId.val() == id) {
                                        iptId.val('');
                                    }
                                });
                            }
                            else {
                                $.message("error", response.data);
                            }
                        }
                    });
                }
            }

        });
    });
});