define(function (require, exports, module) {
    require('angularJs');
    require('jquery');
    require('placeholder');

    //调用myApp
    seajs.use('header', function (ex) {
        var myApp = ex.myApp;

        myApp.controller('couponCtrl', function ($scope, $http, $timeout) {
            $scope.endDate = new Date();
            $scope.getList = function () {
                $scope.couponList = [];
                var url = '/member/voucher/getList.json';
                if ($.isTest)
                    url = '/weixin/member/getCouponList.json';
                $http({
                    method: 'get',
                    url: url
                }).success(function (response) {
                    $scope.couponList =  response.data;
                })
            };
            $scope.getList();
        });

    });
});
