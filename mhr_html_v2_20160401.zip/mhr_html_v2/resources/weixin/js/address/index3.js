define(function (require, exports, module) {


    seajs.use('weiXin2', function (ex) {
        require('token');//令牌，POST时必须调用
        require('weixin/js/checkbox');
        var Validate = require('plugin/validate.el');
        var addr = require('app/share/js/addr');
        var $addressList = $('.addressList');
        var $addressAdd = $('.addressAdd');
        var $addressSave = $('.addressSave');
        var $addressForm = $('#addressForm');
        var $txt_area = $('#txt_area');
        var $hd_area = $('#hd_area');
        var $mtree_demo = $('.mtree-demo');
        var $mtree = $('ul.mtree');

        //提示高亮
        $('input', $addressAdd).focus(function () {
            $(this).siblings('p.title').hide();
        }).blur(function () {
            if ($(this).val().length > 0) {
                $(this).siblings('p.title').show();
                $(this).siblings('p.tip').removeClass('open');
            }
        });
        var isSingleton = false;//是否单个区域


        //点箭头，获取焦点
        $('.fa', $addressAdd).click(function () {
            $(this).siblings('input').focus();
        });


        var myApp = ex.myApp;
        //输出的html
        myApp.filter(
            //格式化html标签
            'to_trusted', ['$sce', function ($sce) {
                return function (text) {
                    return $sce.trustAsHtml(text);
                }
            }]
        );

        var id = $.getQueryString('id');
        if (!id) {//新增
            $('.title', $addressAdd).hide();
        }

        myApp.controller("addressCtrl", function ($scope, $http, $timeout) {
            $scope.id = null;
            $scope.isFirst = null;
            $scope.timestamp = new Date().getTime();
            $scope.receiverId = $.getQueryString('receiverId');

            //index.html
            if ($addressList[0]) {
                //绑定列表
                $http.get('/member/receiver/getlist.json').success(function (response) {
                    $('.addressEmpty').show();
                    if (response.success && response.data.length > 0) {
                        $scope.addressList = response.data;
                        $('.addressEmpty').hide();
                    }
                });

                //选择收货地址
                $scope.choice = function (id) {
                    var buyUrl = $.getQueryString('b');
                    var orderId = $.getQueryString('orderId');
                    if (orderId) {
                        //更改收货地址
                        $http({
                            method: 'POST',
                            url: '/member/order/switchReceiver',
                            data: $.param({
                                orderId: orderId,
                                receiverId: id
                            }),
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                            }
                        }).success(function (response) {
                            if (response.success) {
                                $.smallAlert(response.data);
                                location.href = "/weixin/order/detail.html?id=" + orderId;
                            } else {
                                $.smallAlert(response.data);
                            }
                        });

                    }
                    else {
                        location.href = '/weixin/order/info.html?showwxpaytitle=1&receiverId=' + id + '&b=' + buyUrl;
                    }

                };
            }
            else {

                //获取区域JSON
                $scope.jsonArea = null;
                $scope.isAreaShow = false;

                $scope.areaFullname = '';
                $scope.areaCode1 = '';
                $scope.areaCode2 = '';
                $scope.areaCode3 = '';
                $scope.isDefault = false;
                $scope.address = '';
                $scope.idCard = '';
                $scope.phone = '';
                $scope.zipCode = '';//邮编
                $scope.consignee = '';//收货人

                //绑定省列表
                var url = '/common/areas/getList.json';
                if (location.host.indexOf('localhost') > -1)
                    url = '/member/areas/getList.json';
                $http.get(url).success(function (response) {
                    if (response.success) {
                        $scope.jsonArea = response.data;
                        $timeout(function () {
                            $(document.body).addClass('ok');//显示保存按钮
                        }, 100);
                    }
                });

                //开关省
                $scope.toggleProvince = function (pid, callback) {
                    var el = $('#p' + pid);
                    var ul = el.children('ul');

                    //设定省
                    function setProvince() {
                        el.toggleClass('open');
                        el.siblings('.province').addClass('mtree-close');

                        isSingleton = false;
                        if (el.find('.city').length == 1)
                            isSingleton = true;

                        ul.slideToggle('fast', function () {
                            ul.toggleClass('mtree-open');
                            if (!ul.hasClass('mtree-open')) {
                                el.find('.city').removeClass('open').removeClass('mtree-close');
                                el.find('.city ul').removeClass('mtree-open').hide();
                                el.siblings('.province').removeClass('mtree-close').show();
                            }
                            //一个时自动展开
                            if (isSingleton) {
                                el.find('.city > a').click();
                            }
                        });
                        document.body.scrollTop = el.position().top;
                    }

                    if (ul.children().length == 0) {
                        var url = '/common/areas/getList.json?parentId=' + pid;
                        if (location.host.indexOf('localhost') > -1)
                            url = '/member/areas/getCity.json';
                        $http.get(url).success(function (response) {
                            if (response.success) {
                                var html = '';
                                $.each(response.data, function (n, city) {
                                    html += '<li id="c' + city.id + '" class="city">' +
                                        '<a data-areas="' + city.fullname + '" data-areaid="' + pid + ',' + city.id + ',0' + '"' +
                                        '>' + city.name + '<i class="fa fa-chevron-down fa-fw"></i></a>' +
                                        '<ul></ul>' +
                                        '</li>';
                                });
                                ul.append(html);
                                setProvince();
                                if (typeof callback == 'function')
                                    callback();
                            } else {
                                setProvince();
                                if (typeof callback == 'function')
                                    callback();
                            }
                        });
                    }
                    else {
                        setProvince();
                        if (typeof callback == 'function')
                            callback();
                    }
                };

                //开关市
                $.delegate('ul.mtree li.city > a', {
                    'click': function () {
                        var el = $(this).parent();
                        var cid = parseInt(el[0].id.replace('c', ''));
                        var pid = parseInt(el.parents('.province')[0].id.replace('p', ''));
                        var ul = el.children('ul');
                        var a = $(this);

                        //设定市
                        function setCity() {
                            el.toggleClass('open');
                            el.siblings('.city').addClass('mtree-close');
                            ul.slideToggle('fast', function () {
                                ul.toggleClass('mtree-open');
                                if (ul.children().length > 0) {
                                    if (!ul.hasClass('mtree-open')) {
                                        if (el.siblings('.city').length == 0)
                                            $('#p' + pid + ' > a').click();//收起直辖市时，收起省级
                                        else
                                            el.siblings('.city').removeClass('mtree-close');//显示同级市
                                    }
                                }
                                else {
                                    $txt_area.text(a.attr('data-areas'));
                                    var areaIds = eval('([' + a.attr('data-areaId') + '])');
                                    $('[name="areaCode1"]').val(areaIds[0]);
                                    $('[name="areaCode2"]').val(areaIds[1]);
                                    $('[name="areaCode3"]').val(0);
                                    $mtree_demo.hide();
                                }
                            });
                        }

                        if (ul.children().length == 0) {
                            var url = '/common/areas/getList.json?parentId=' + cid;
                            if (location.host.indexOf('localhost') > -1)
                                url = '/member/areas/getDistrict.json';
                            $http.get(url).success(function (response) {
                                if (response.success) {
                                    var html = '';
                                    $.each(response.data, function (n, district) {
                                        html += '<li id="d' + district.id + '" class="district">' +
                                            '<a data-areas="' + district.fullname + '" data-areaid="' + pid + ',' + cid + ',' + district.id + '"' +
                                            '>' + district.name + '</i></a>' +
                                            '</li>';
                                    });
                                    ul.append(html);
                                    setCity();
                                }
                                else
                                    setCity();
                            });
                        } else {
                            setCity();
                        }
                    }
                });

                //选择区县
                $.delegate('ul.mtree li.district > a', {
                    'click': function () {
                        var a = $(this);
                        $txt_area.text(a.attr('data-areas'));
                        var areaIds = eval('([' + a.attr('data-areaId') + '])');
                        $('[name="areaCode1"]').val(areaIds[0]);
                        $('[name="areaCode2"]').val(areaIds[1]);
                        $('[name="areaCode3"]').val(areaIds[2]);
                        $mtree_demo.hide();
                    }
                });

                //获取区县
                $scope.getArea = function () {
                    $mtree.find('ul').removeClass('mtree-open').slideUp('fast');
                    $mtree.find('ul').removeClass('mtree-close');
                    $mtree.find('li').removeClass('open');

                    $scope.areaCode1 = parseInt($('[name="areaCode1"]').val());
                    $scope.areaCode2 = parseInt($('[name="areaCode2"]').val());
                    $scope.areaCode3 = parseInt($('[name="areaCode3"]').val());
                    if ($scope.areaCode1) {
                        $scope.toggleProvince($scope.areaCode1, function () {
                            var $city = $('#c' + $scope.areaCode2);
                            if ($scope.areaCode3 && $scope.areaCode3 > 0 && !isSingleton) {
                                $city.children('a').click();
                            }
                            $mtree_demo.show();
                        });
                    }
                };

                //最小高度
                $mtree_demo.css('min-height', $(window).height());

                //add.html
                if (id) {
                    document.title = '编辑收货地址 - 美日惠，家门口的海外药妆店！';

                    //编辑
                    $http.get('/member/receiver/getlist.json').success(function (response) {
                        if (response.success) {
                            $.each(response.data, function (n, addr) {
                                if (id == addr.id) {
                                    $scope.id = addr.id;
                                    $scope.areaCode1 = addr.areaCode1;
                                    $scope.areaCode2 = addr.areaCode2;
                                    $scope.areaCode3 = addr.areaCode3;
                                    $scope.areaFullname = addr.areaFullname;//地区全名
                                    $scope.isDefault = addr.isDefault;
                                    $scope.address = addr.address;
                                    $scope.idCard = addr.idCard;
                                    $scope.phone = addr.phone;
                                    $scope.zipCode = addr.zipCode;
                                    $scope.consignee = addr.consignee;
                                }
                            });
                            $scope.areaCode3 = $scope.areaCode3 || 0;
                            $timeout(function () {
                                $(document.body).addClass('ok');//显示保存按钮
                            }, 100);
                        }
                        if ($scope.id == null)
                            location.replace('index.html');
                    });

                    //删除
                    $scope.delete = function () {
                        $.ajax({
                            url: '/member/receiver/del.json',
                            type: "POST",
                            dataType: "json",
                            data: {id: id},
                            success: function (response) {
                                if (response.success) {
                                    location.replace('index.html');
                                }
                                else {
                                    $.smallAlert(response.data);
                                }
                            }
                        });
                    }
                } else {
                    if (sessionStorage.getItem('WXDebug'))
                        alert(2);
                    $mtree_demo.show();
                    document.title = '新增收货地址 - 美日惠，家门口的海外药妆店！';
                }

                //保存
                $scope.save = function () {
                    $scope.incomplete = false;
                    if ($scope.address.length < 5) {
                        $('[name="address"]').siblings('.tip').addClass('open');
                        $scope.incomplete = true;
                    }
                    var resIdCard = Validate.checkformat('[name="idCard"]');
                    if (!resIdCard.res) {
                        $('[name="idCard"]').siblings('.tip').addClass('open');
                        $scope.incomplete = true;
                    }
                    var resPhone = Validate.checkformat('[name="phone"]');
                    if (!resPhone.res) {
                        $('[name="phone"]').siblings('.tip').addClass('open');
                        $scope.incomplete = true;
                    }
                    if ($scope.zipCode.length != 6) {
                        $('[name="zipCode"]').siblings('.tip').addClass('open');
                        $scope.incomplete = true;
                    }
                    if ($scope.consignee.length < 2) {
                        $('[name="consignee"]').siblings('.tip').addClass('open');
                        $scope.incomplete = true;
                    }

                    if (!$scope.incomplete) {
                        var data = $addressForm.serializeObject();
                        $.ajax({
                            url: '/member/receiver/update.json',
                            type: "post",
                            dataType: "json",
                            data: data,
                            success: function (response) {
                                if (response.success) {
                                    if (document.referrer && document.referrer.indexOf('/order/info') > -1)
                                    {
                                        if (sessionStorage.getItem('WXDebug'))
                                            alert(1);
                                        location.href = document.referrer;
                                    }
                                    else
                                    {
                                        if (sessionStorage.getItem('WXDebug'))
                                            alert(2);
                                        location.replace('index.html');
                                    }

                                }
                                else {
                                    $.smallAlert(response.data);
                                }
                            }
                        })
                    }
                }
            }
        });
    });
});