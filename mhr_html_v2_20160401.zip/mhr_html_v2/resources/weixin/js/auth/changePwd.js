define(function (require, exports, module) {
    var form_action = require('plugin/form_action');
    require('weiXin');
    require('token');//令牌，POST时必须调用

    var smallAlert = require('plugin/small-alert');
    var getQueryString = require('plugin/getQueryString');

    var $rocket = $('.rocket');
    var $shuttle = $('.shuttle');
    var $form = $('.form');
    var $winWidth = $(window).width();
    var $winHeight = $(window).height();
    var $rocketWidth = $rocket.width();
    var $submit = $(":submit");
    var $currentPassword = $('#currentPassword');

    function initRocket() {
        //烟雾居中
        if ($winWidth < $rocketWidth) {
            $rocket.css('left', ($winWidth - $rocketWidth) / 2);
        }

        //飞机定位
        $shuttle.css('left', ($rocketWidth - $shuttle.width()) / 2);

        //烟雾定高
        $rocket.height($winHeight - $form.position().top - $form.height() - 30);

        setTimeout(function () {
            initRocket();
        }, 100);
    }

    $(function () {
        initRocket();
        //完成后显示
        $(document.body).addClass('ok');
    });

    //提交按钮
    $submit.click(function () {
        var jsonData = [];
        form_action(this, function (data) {
            jsonData = data;
            if (jsonData.password != jsonData.rePassword) {
                smallAlert('两次密码不相同');
                return false;
            }
            $submit.prop("disabled", true);
            return true;
        }, function (response) {

            if (sessionStorage.getItem('WXDebug'))
                alert('@@success@@\r\n' + JSON.stringify(response));

            $submit.prop("disabled", false);
            if (response.success) {

                smallAlert(response.data, null, function () {
                    var redirectUrl = decodeURIComponent(getQueryString('redirectUrl', null, true));
                    if (redirectUrl)
                        location.href = redirectUrl;
                    else
                        location.href = "/weixin/index.html";
                });

            } else {
                smallAlert(response.data);
            }

        }, function (err) {
            if (sessionStorage.getItem('WXDebug'))
                alert('@@error@@\r\n' + JSON.stringify(err));

            $submit.prop("disabled", false);
            var msg = err.status || err;
            smallAlert(msg);
        });
    });
});