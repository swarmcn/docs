define(function (require, exports, module) {
    var form_action = require('plugin/form_action');
    require('weiXin');

    var smallAlert = require('plugin/small-alert');
    var circle = require('plugin/circle');
    var getQueryString = require('plugin/getQueryString');
    var Guid = require('plugin/guid');

    var $username = $("#username").focus();
    var $sendRandomCode = $("#sendRandomCode");
    var $submit = $(":submit");
    var $captcha = $("#captcha");
    var captchaId = Guid();//验证码标识
    var $captchaId = $('#captchaId').val(captchaId);
    var $captchaImage = $("#captchaImage");

    ////更换验证码
    //$captchaImage.click(function () {
    //    $(this).removeClass('hide').attr("src", "/common/captcha?captchaId=" + captchaId + "&timestamp=" + new Date().getTime());
    //}).click();//初始化

    //完成后显示
    $(document.body).addClass('ok');

    //发送验证码
    $sendRandomCode.click(function () {
        var el = $(this);
        var mobile = $username.val();
        var isMob = /^((\+?86)|(\(\+86\)))?(1[3-8][0-9]{9})$/;
        if (!isMob.test(mobile)) {
            smallAlert('请输入有效的手机号码！');
            $username.focus();
            return false;
        }

        if (!el.hasClass('gray_btn')) {
            el.addClass('gray_btn');
            $.post('/password/saveRandomCode', {
                username: mobile
            }, function (message) {
                if (message.type == 'success') {
                    smallAlert(message.content);
                    circle({
                        'times': 60,
                        'fn': function () {
                            el.text('(' + this.times + ')秒后重试');
                        },
                        'afterfn': function () {
                            el.removeClass('gray_btn');
                            el.text('获取验证码');
                        }
                    });
                }
                else {
                    el.removeClass('gray_btn');
                    smallAlert(message.content);
                }
            }, 'json');
        }
    });

    //提交按钮
    $submit.click(function () {
        var jsonData = [];
        form_action(this, function (data) {
            jsonData = data;
            var isMob = /^((\+?86)|(\(\+86\)))?(1[3-8][0-9]{9})$/;
            if (!isMob.test(jsonData.username)) {
                smallAlert('请输入有效的手机号码');
                return false;
            }
            if (jsonData.newPassword != jsonData.rePassword) {
                smallAlert('两次密码不相同');
                return false;
            }
            $submit.prop("disabled", true);
            return true;
        }, function (message) {

            if (sessionStorage.getItem('WXDebug'))
                alert('@@success@@\r\n' + JSON.stringify(message));

            $submit.prop("disabled", false);
            if (message.type == "success") {

                smallAlert(message.content, null, function () {
                    var redirectUrl = decodeURIComponent(getQueryString('redirectUrl', null, true));
                    if (redirectUrl)
                        location.href = redirectUrl;
                    else
                        location.href = "/weixin/index.html";
                });

            } else {
                //$captcha.val("");
                //$captchaImage.click();
                smallAlert(message.content);
            }

        }, function (err) {
            if (sessionStorage.getItem('WXDebug'))
                alert('@@success@@\r\n' + JSON.stringify(err));

            //$captcha.val('');
            //$captchaImage.click();
            $submit.prop("disabled", false);
            var msg = err.status || err;
            smallAlert(msg);
        });
    });
});