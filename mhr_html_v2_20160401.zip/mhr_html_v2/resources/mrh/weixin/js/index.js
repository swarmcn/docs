define(function (require, exports, module) {
    require('weiXin');
    require('unveil');
    require('owl-carousel');

    var smallAlert = require('plugin/small-alert');
    var winWidth = $(window).width();
    $('.fl_list .pic').css({
        width: winWidth * 0.4,
        height: winWidth * 0.4
    });

    //禁止滚动
    document.addEventListener('touchmove', function (event) {
        if ($('.search-bar.focus').length > 0) {
            event.preventDefault();
        }
    }, false);

    //搜索获取焦点
    $('.search-bar input').focus(function () {
        var pt = $(this).parent();
        pt.addClass('focus');
        $(window).scrollTop(0);
    }).blur(function () {
        $(this).parent().removeClass('focus');
    });
    //搜索失去焦点
    $('.search-bar').submit(function () {
        $('.search-bar input').blur();
    });

    function imgUnveil() {
        $('img[unveil-src]:lt(9)').each(function () {
            this.src = $(this).attr('unveil-src');
            $(this).removeAttr('unveil-src');
        });

        $('img').unveil(0, function () {
            $(this).load(function () {
                this.style.opacity = 1;
            });
        });
    }

    //myApp
    var myApp = angular.module("myApp", []);

    //ajax请求全局配置
    myApp.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.defaults.headers.common['token'] = $.cookie('token') || 0;
        $httpProvider.defaults.headers.common['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
        $httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
    }]);

    myApp.controller("IndexCtrl", function ($scope, $http, $timeout) {

        var url = '/common/getBanner.json?typeId=2';
        if (location.hostname == 'localhost' || location.hostname.indexOf('192.168.2') > -1)
            url = '/admin/operate/getBanner.json';
        $http.get(url).success(function (response) {
            if (response.success) {
                $scope.BannerList = response.data;

                $timeout(function () {
                    if ($('.owl-carousel img').length > 1) {
                        $('.owl-carousel').owlCarousel({
                            margin: 0,
                            center: true,
                            items: 1,
                            loop: true,
                            lazyLoad: true,
                            autoplay: true,
                            autoplayTimeout: 5000,
                            autoplayHoverPause: true
                        });
                    } else {
                        $('.owl-carousel').owlCarousel({
                            margin: 0,
                            center: true,
                            items: 1,
                            loop: false,
                            dots: false,
                            lazyLoad: true
                        });
                    }
                }, 100)
            }
        });

        //列表
        $scope.getFlashList = function (isFirst) {
            $http.get("/product/getFlashList.json").success(function (response) {
                if (response.success) {
                    $scope.FlashList = response.data;

                    $('.floor_1 > h1,.floor_2 > h1,.floor_3 > h1').addClass('ng-hide');
                    $scope.nowDate = new Date().getTime();
                    $timeout(function () {
                        imgUnveil();

                        //$scope.timer();

                        $('#flashList').removeClass('ng-hide');
                        //自动定位
                        document.body.scrollTop = sessionStorage.getItem("wx-index-top") || 0;
                    }, 100);
                }
            });

            //过滤关键字
            $scope.filterKey = function (x) {
                $scope.keyword = $scope.keyword || '';
                return (x.brief.indexOf($scope.keyword) > -1 || x.name.indexOf($scope.keyword) > -1 || (x.barcode && x.barcode.toString().indexOf($scope.keyword) > -1 ));
            }
        };
        $scope.getFlashList(true);

        //搜索后执行
        $scope.searchKey = function () {
            $timeout(function () {
                imgUnveil();
            }, 100);
        };

        //倒计时
        $scope.timer = function () {
            $('[timer]').each(function () {
                var obj = $(this);
                var time = obj.attr('timer');
                var ts = parseInt(time) - (new Date().getTime());//计算剩余的毫秒数
                var dd = parseInt(ts / 1000 / 60 / 60 / 24, 10);//计算剩余的天数
                var hh = parseInt(ts / 1000 / 60 / 60 % 24, 10);//计算剩余的小时数
                var mm = parseInt(ts / 1000 / 60 % 60, 10);//计算剩余的分钟数
                var ss = parseInt(ts / 1000 % 60, 10);//计算剩余的秒数
                if (ss >= 0) {
                    $(obj).html('<i>&nbsp;</i>' + dd + "天" + hh + "时" + mm + "分" + ss + "秒");
                }
                else {
                    $scope.getFlashList();//时间到了,刷新数据
                    $(obj).text('');
                }
            });
            setTimeout(function () {
                $scope.timer();
            }, 1000);
        };

        //跳转详情页
        $scope.goDetail = function (x, b) {
            if (x.stock > 0 || b)
                location.href = '/weixin/product/detail.html?id=' + x.productId;
        };

        //加入购物车
        $scope.addCart = function (productId) {
            $.post('/cart/add', {
                id: productId,
                quantity: 1
            }, function (message) {
                if (message.type = "success") {
                    smallAlert(message.content);
                    $.get('/cart/getCount.json?stamp=' + new Date().getTime(), function (response) {
                        if (response.success && response.data != "0") {
                            $('.navbar .cartNum').removeClass('ng-hide').text(response.data);
                        }
                    });
                }
                else {
                    smallAlert(message.content);
                }
            }, 'json');
        };

        //加入收藏
        $scope.addFavorite = function (productId) {

            //登录状态
            $.checkWXLogin(function (response) {
                $.WXUserInfo = response;
                if ($.WXUserInfo && $.WXUserInfo.register) {
                    $.post("/member/favorite/add.json", {
                        id: productId
                    }, function (response) {
                        if (response.success) {
                            smallAlert(response.data);
                        }
                        else {
                            smallAlert(response.data);
                        }
                    }, 'json');

                } else {
                    smallAlert('请登录后再进行操作');
                }
            });
        };
    });

    $(window).scroll(function () {
        //session存储
        if (window.sessionStorage) {
            sessionStorage.setItem("wx-index-top", document.body.scrollTop);
        }

        //var $wt = $(window).scrollTop();
        //$('.search-bar').css('top',$wt);
    });
});