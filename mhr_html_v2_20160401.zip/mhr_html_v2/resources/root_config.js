//css/js/less版本号
var version = 2015122901;
function setCookie(name, value) {
    var Days = 30;
    var exp = new Date();
    exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
    document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString();
}
setCookie('version', version);

seajs.config({
    'debug': false,
    'base': '/resources/',
    'alias': {
        'angularJs': 'plugin/angular/angular-1.5.0-beta.1.sea.js',
        'angularRoute': 'plugin/angular/angular-route.sea.js',
        'jquery': 'plugin/jquery/jquery-1.11.3.sea',
        'cookie': 'plugin/jquery/jquery.cookie.sea',
        'validate': 'plugin/jquery/jquery.validate.sea',
        'placeholder': 'plugin/jquery/jquery.placeholder.sea',
        'unveil': 'plugin/jquery/jquery.unveil.sea',
        'pagination': 'plugin/jquery/jquery.simplePagination.sea',
        'ionic': 'plugin/ionic/js/ionic.bundle.sea',

        'bootstrap': 'plugin/bootstrap/js/bootstrap.sea',
        'angularStrap': 'plugin/angular/strap/ui-bootstrap-0.13.0.sea',
        'owl-carousel': 'plugin/owlcarousel/owl.carousel.sea',
        'sweet-alert': 'plugin/sweetAlert/js/sweet-alert.sea',

        'header': 'shop/js/header.js',
        'token': 'share/js/jquery.token.js',
        'admin': 'admin/js/header',
        'date': 'share/js/date.js',
        'highlight': 'share/js/highlight.js',
        'weiXin': 'weixin/js/common',
        'weiXin2': 'weixin/js/weixin',
        'store': 'store/js/header',
        'storewx': 'storewx/js/common'
    },
    'map': [
        [/^(.*\/weixin\/.*\.(?:css|js|less))(?:.*)$/i, '$1?v=1' + version],
        [/^(.*\/storewx\/.*\.(?:css|js|less))(?:.*)$/i, '$1?v=' + version],
        [/^(.*\/shop\/.*\.(?:css|js|less))(?:.*)$/i, '$1?v=' + version],
        [/^(.*\/store\/.*\.(?:css|js|less))(?:.*)$/i, '$1?v=' + version],
        [/^(.*\/plugin\/.*\.(?:css|js|less))(?:.*)$/i, '$1?v=' + version]
    ]
});

//IE9以下检测
if(!window.b_version) {
    window.b_version = navigator.appVersion.split(";");
    if (b_version.length > 1) {
        var trim_Version = parseInt(b_version[1].replace(/[ ]/g, "").replace(/MSIE/g, ""));
        if (parseInt(trim_Version) < 9) {
            window.location.href = "version.html";
        }
    }
}

//百度统计，外网才监测
window.onload = function() {
    if (location.hostname.toLowerCase().indexOf('.com') > -1 && location.pathname.indexOf('/admin') == -1) {
        var _bdhmProtocol = (("https:" == document.location.protocol) ? "https://" : "http://");
        var baiduJS = document.createElement('script');
        baiduJS.src = _bdhmProtocol + "hm.baidu.com/h.js?8b3a669173298d3e688c5769731043a3";
        baiduJS.type = 'text/javascript';
        document.body.appendChild(baiduJS);
    }
};